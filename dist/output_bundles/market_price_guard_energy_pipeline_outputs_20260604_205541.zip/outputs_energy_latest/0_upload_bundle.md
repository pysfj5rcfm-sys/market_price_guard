# market_price_guard 上传包

## 基本信息
- generated_at: 2026-06-04T11:11:15.048587+00:00
- profile: energy
- provider_mode: live
- provider_policy: fast
- quote_purpose: operation
- reconcile_mode: default
- strict: true
- exit_code: 2
- output_dir: outputs_energy_latest
- universe_name: energy_core
- universe_type: core_holdings
- core_count: 4
- watchlist_count: 0
- scan_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: energy_core
- config_source_path: config/universes/energy_core.yaml
- config_source_hash_sha256: 3f40bc0703a0
- configured_symbol_count: 4
- loaded_symbol_count: 4
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## 本轮结论
- 可用于快速参考：否
- 可用于具体操作建议：否
- 当前用途级别：operation-blocked
- confirmation_required 数量: 4
- blocking records 数量: 4

## 数据完整度摘要
- strict/exit_code: 2
- provider_error 数量: 0
- stale 数量: 4
- quote_time_missing 数量: 0
- invalid_price 数量: 0
- mock fallback not usable 数量: 4
- run_time_budget_exceeded: False

### Blocking records 摘要
- project=energy, symbol=00883.HK, name=中海油H, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=energy, symbol=601899.SH, name=紫金矿业A, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=energy, symbol=601985.SH, name=中国核电, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=energy, symbol=003816.SZ, name=中国广核, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=

## Quote Trust Tier 摘要
- operation-grade records 数量: 0
- reference-grade records 数量: 0
- development-grade records 数量: 4
- usable_for_reference=true 数量: 0
- usable_for_operation=true 数量: 0
- confirmation_required=true 数量: 4

## 基础行情快照 / Base Quote Snapshot
| symbol | name | last | chg% | open | high | low | prev | volume | amount | base | provider | tier | op? | stale? |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|
| 00883.HK | 中海油H | 21.35 | — | — | — | — | — | — | — | price_only | mock | development | False | True |
| 601899.SH | 紫金矿业A | 18.42 | — | — | — | — | — | — | — | price_only | mock | development | False | True |
| 601985.SH | 中国核电 | 10.91 | — | — | — | — | — | — | — | price_only | mock | development | False | True |
| 003816.SZ | 中国广核 | 4.27 | — | — | — | — | — | — | — | price_only | mock | development | False | True |
- base_quote_completeness is shown in the compact `base` column.

- volume/amount follow provider raw units unless unit normalization is explicitly available.
- 成交量/成交额暂按 provider 原始单位展示；未统一单位前不得直接跨 provider 排名。

## 字段质量提示 / Field Quality Notes
- volume/amount are shown in provider raw units unless explicitly validated.
- cross-provider volume/amount comparison is unsafe in this version.
- bid/ask, turnover_rate, minute_bars, VWAP and QDII premium are not validated or not implemented.
- See debug_bundle.md and provider_capability_report.md for details.

## Reconciliation Summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=3
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 项目核心内容
### 能源账户核心价格

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 00883.HK | 中海油H | 21.35 | HKD | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 601899.SH | 紫金矿业A | 18.42 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 601985.SH | 中国核电 | 10.91 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 003816.SZ | 中国广核 | 4.27 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

## Universe isolation
- universe_name: energy_core
- universe_type: core_holdings
- candidate/watchlist/scan symbols keep required_for_operation=false unless promoted to core_holdings.

## Reference / Operation 使用提示
- 本轮为 operation 模式。
- 如果 strict=2 或 blocking records 存在，不得给高精度执行价位。
- 可根据数据完整度要求补充数据或降级为事实核对。

## Debug 提示
- 如出现 strict=2、blocking records、provider_error、quote_time_missing、invalid_price、stale、selected_provider=mock、fallback_used 异常、run_time_budget_exceeded、slow_provider_attempts、quote_time 可疑或报告冲突，请补充 debug_bundle.md。
- 本上传包只汇总数据状态、可用性和阻断原因。
