# 能源账户价格事实块

仅为价格事实和新鲜度记录，不包含具体操作建议。

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 00883.HK | 中海油H | 21.35 | HKD | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 601899.SH | 紫金矿业A | 18.42 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 601985.SH | 中国核电 | 10.91 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 003816.SZ | 中国广核 | 4.27 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

## 基础行情字段 / Base Quote Fields
| symbol | name | last | chg% | open | high | low | prev | volume | amount | base | missing_fields |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| 00883.HK | 中海油H | 21.35 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 601899.SH | 紫金矿业A | 18.42 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 601985.SH | 中国核电 | 10.91 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 003816.SZ | 中国广核 | 4.27 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |

- volume/amount follow provider raw units unless unit normalization is explicitly available.
- 成交量/成交额暂按 provider 原始单位展示；未统一单位前不得直接跨 provider 排名。
