# Runtime Diagnostics

- run_start_time_utc: 2026-06-04T11:11:05.118756+00:00
- run_end_time_utc: 2026-06-04T11:11:15.048587+00:00
- total_elapsed_seconds: 9.93
- profile: energy
- provider_mode: live
- provider_policy: fast
- strict: True
- quote_purpose: operation
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.148
- yfinance_attempted_count: 1
- yfinance_success_count: 0
- yfinance_error_count: 1
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: invalid_price,assumed_currency_hkd,quote_time_missing
- provider_timeout_count: 3
- provider_skipped_by_runtime_budget_count: 4
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 2
- provider_runtime_budget_summary: akshare:attempts=1,elapsed=9.679,slow=1,failed=1; eastmoney_direct:attempts=3,elapsed=0.036,slow=0,failed=3; mock:attempts=4,elapsed=0.013,slow=0,failed=0; yfinance:attempts=1,elapsed=0.148,slow=0,failed=1
- quote_cache_hit_count: 32
- quote_cache_miss_count: 45
- quote_cache_failure_hit_count: 28
- quote_cache_success_hit_count: 4
- repeated_provider_call_prevented_count: 32
- universe_name: energy_core
- universe_type: core_holdings
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319175.049
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-20T12:45:00+08:00

## Provider Runtime Summary
- account: energy
- layer: energy_core
- total_elapsed_seconds: 9.93
- run_time_budget_exceeded: False
- slow_provider_attempts: 2
- provider_timeout_count: 5
- provider_skipped_by_runtime_budget_count: 4
- provider_circuit_open_count: 4

## per_provider_elapsed_seconds
- yfinance: 0.148
- akshare: 19.358
- mock: 0.013
- eastmoney_direct: 0.036

## Config Source / Layer Manifest
- layer_name: energy_core
- config_source_path: config/universes/energy_core.yaml
- config_source_hash_sha256: 3f40bc0703a0
- configured_symbol_count: 4
- loaded_symbol_count: 4
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 00883.HK: 0.15
- 601899.SH: 19.373
- 601985.SH: 0.019
- 003816.SZ: 0.013

## slow_provider_attempts
- symbol=601899.SH, provider=akshare, function_name=stock_zh_a_spot_em, elapsed_seconds=9.679, timeout_seconds=8.0, reason=provider_timeout
- symbol=601899.SH, provider=akshare, function_name=stock_sh_a_spot_em, elapsed_seconds=9.679, timeout_seconds=8.0, reason=provider_timeout

## provider_call_cache
- total_provider_calls: 2
- cache_hits: 0
- provider_call_count_by_function:
  - stock_sh_a_spot_em: 1
  - stock_zh_a_spot_em: 1

## Cache / Reuse Summary
- quote_cache_hit_count: 32
- quote_cache_miss_count: 45
- quote_cache_failure_hit_count: 28
- quote_cache_success_hit_count: 4
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 32
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 4
- cache_hit_by_layer: none
- cache_hit_by_provider: none

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 4
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 2
- provider_budget_account: energy
- provider_budget_run_id: 2026-06-04T11:11:05.118756+00:00
- provider_circuit_open: {'akshare': 'skipped_by_provider_circuit', 'eastmoney_direct': 'skipped_by_provider_circuit'}
- provider_budget_by_provider:
  - akshare: attempts=1, elapsed_seconds=9.679, slow_attempts=1, failed_attempts=1
  - eastmoney_direct: attempts=3, elapsed_seconds=0.036, slow_attempts=0, failed_attempts=3
  - mock: attempts=4, elapsed_seconds=0.013, slow_attempts=0, failed_attempts=0
  - yfinance: attempts=1, elapsed_seconds=0.148, slow_attempts=0, failed_attempts=1
