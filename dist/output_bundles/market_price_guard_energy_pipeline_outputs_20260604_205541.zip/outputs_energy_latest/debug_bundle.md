# market_price_guard 排障包

## 基本信息
- generated_at: 2026-06-04T11:11:15.048587+00:00
- profile: energy
- provider_mode: live
- provider_policy: fast
- quote_purpose: operation
- reconcile_mode: default
- strict: true
- exit_code: 2
- output_dir: outputs_energy_latest
- universe_name: energy_core
- universe_type: core_holdings

## Symbol Registry Resolution 摘要
- registry_enabled: true
- registry_path: /Users/chenyulin/Documents/AIProjects/market_price_guard/config/symbol_registry.yaml
- universe_name: energy_core
- universe_type: core_holdings
- core_count: 4
- watchlist_count: 0
- scan_count: 0
- operation_candidate_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: energy_core
- config_source_path: config/universes/energy_core.yaml
- config_source_hash_sha256: 3f40bc0703a0
- configured_symbol_count: 4
- loaded_symbol_count: 4
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Provider Health 摘要
- provider_policy: fast
- provider_mode: live
- function_name=akshare, call_count=0, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=, failed=True, exception_type=, exception_message=
- function_name=stock_sh_a_spot_em, call_count=1, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=5.2, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A1+t%3A2%2Cm%3A1+t%3A23&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
- function_name=stock_zh_a_spot_em, call_count=1, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=4.412, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A0+t%3A6%2Cm%3A0+t%3A80%2Cm%3A1+t%3A2%2Cm%3A1+t%3A23%2Cm%3A0+t%3A81+s%3A2048&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))

### Provider attempts
### 00883.HK
- provider_policy: fast
- configured_provider_priority: akshare, yfinance, mock
- provider_planned_chain: yfinance, akshare, mock
- effective_provider_chain: yfinance, akshare, mock
- actual_provider_attempted: yfinance, mock
- provider_skip_reasons: akshare=hk_akshare_skipped_after_fast_provider_failure_budget
- normalized_symbol: 00883.HK
- route_reason: account_generic_hk_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: hk_reference_unavailable
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=yfinance, function_name=yfinance.Ticker, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.148, slow_provider_attempt=False, reason=invalid_price,assumed_currency_hkd,quote_time_missing, exception_type=, exception_message=
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=hk_akshare_skipped_after_fast_provider_failure_budget, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=21.35, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.002, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 601899.SH
- provider_policy: fast
- configured_provider_priority: akshare, yfinance, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: eastmoney_direct, akshare, mock
- provider_skip_reasons: yfinance=provider_skipped_by_runtime_budget
- normalized_symbol: 601899.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=1.601899, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.009, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=yfinance, function_name=yfinance, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_skipped_by_runtime_budget, exception_type=, exception_message=
  - provider=akshare, function_name=stock_zh_a_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=9.679, slow_provider_attempt=True, reason=provider_timeout, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A0+t%3A6%2Cm%3A0+t%3A80%2Cm%3A1+t%3A2%2Cm%3A1+t%3A23%2Cm%3A0+t%3A81+s%3A2048&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=akshare, function_name=stock_sh_a_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=9.679, slow_provider_attempt=True, reason=provider_timeout, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A1+t%3A2%2Cm%3A1+t%3A23&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=18.42, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.006, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 601985.SH
- provider_policy: fast
- configured_provider_priority: akshare, yfinance, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: eastmoney_direct, mock
- provider_skip_reasons: yfinance=provider_skipped_by_runtime_budget, akshare=skipped_by_provider_circuit
- normalized_symbol: 601985.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=1.601985, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.017, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=yfinance, function_name=yfinance, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_skipped_by_runtime_budget, exception_type=, exception_message=
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=10.91, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.002, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 003816.SZ
- provider_policy: fast
- configured_provider_priority: akshare, yfinance, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: eastmoney_direct, mock
- provider_skip_reasons: yfinance=provider_skipped_by_runtime_budget, akshare=skipped_by_provider_circuit
- normalized_symbol: 003816.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=0.003816, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.01, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=yfinance, function_name=yfinance, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_skipped_by_runtime_budget, exception_type=, exception_message=
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=4.27, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=

## Runtime Diagnostics 摘要
- run_start_time_utc: 2026-06-04T11:11:05.118756+00:00
- run_end_time_utc: 2026-06-04T11:11:15.048587+00:00
- total_elapsed_seconds: 9.93
- profile: energy
- provider_mode: live
- provider_policy: fast
- strict: True
- quote_purpose: operation
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.148
- yfinance_attempted_count: 1
- yfinance_success_count: 0
- yfinance_error_count: 1
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: invalid_price,assumed_currency_hkd,quote_time_missing
- provider_timeout_count: 3
- provider_skipped_by_runtime_budget_count: 4
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 2
- provider_runtime_budget_summary: akshare:attempts=1,elapsed=9.679,slow=1,failed=1; eastmoney_direct:attempts=3,elapsed=0.036,slow=0,failed=3; mock:attempts=4,elapsed=0.013,slow=0,failed=0; yfinance:attempts=1,elapsed=0.148,slow=0,failed=1
- quote_cache_hit_count: 32
- quote_cache_miss_count: 45
- quote_cache_failure_hit_count: 28
- quote_cache_success_hit_count: 4
- repeated_provider_call_prevented_count: 32
- universe_name: energy_core
- universe_type: core_holdings
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319175.049
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-20T12:45:00+08:00

## Provider Runtime Summary
- account: energy
- layer: energy_core
- total_elapsed_seconds: 9.93
- run_time_budget_exceeded: False
- slow_provider_attempts: 2
- provider_timeout_count: 5
- provider_skipped_by_runtime_budget_count: 4
- provider_circuit_open_count: 4

## per_provider_elapsed_seconds
- yfinance: 0.148
- akshare: 19.358
- mock: 0.013
- eastmoney_direct: 0.036

## Config Source / Layer Manifest
- layer_name: energy_core
- config_source_path: config/universes/energy_core.yaml
- config_source_hash_sha256: 3f40bc0703a0
- configured_symbol_count: 4
- loaded_symbol_count: 4
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 00883.HK: 0.15
- 601899.SH: 19.373
- 601985.SH: 0.019
- 003816.SZ: 0.013

## slow_provider_attempts
- symbol=601899.SH, provider=akshare, function_name=stock_zh_a_spot_em, elapsed_seconds=9.679, timeout_seconds=8.0, reason=provider_timeout
- symbol=601899.SH, provider=akshare, function_name=stock_sh_a_spot_em, elapsed_seconds=9.679, timeout_seconds=8.0, reason=provider_timeout

## provider_call_cache
- total_provider_calls: 2
- cache_hits: 0
- provider_call_count_by_function:
  - stock_sh_a_spot_em: 1
  - stock_zh_a_spot_em: 1

## Cache / Reuse Summary
- quote_cache_hit_count: 32
- quote_cache_miss_count: 45
- quote_cache_failure_hit_count: 28
- quote_cache_success_hit_count: 4
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 32
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 4
- cache_hit_by_layer: none
- cache_hit_by_provider: none

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 4
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 2
- provider_budget_account: energy
- provider_budget_run_id: 2026-06-04T11:11:05.118756+00:00
- provider_circuit_open: {'akshare': 'skipped_by_provider_circuit', 'eastmoney_direct': 'skipped_by_provider_circuit'}
- provider_budget_by_provider:
  - akshare: attempts=1, elapsed_seconds=9.679, slow_attempts=1, failed_attempts=1
  - eastmoney_direct: attempts=3, elapsed_seconds=0.036, slow_attempts=0, failed_attempts=3
  - mock: attempts=4, elapsed_seconds=0.013, slow_attempts=0, failed_attempts=0
  - yfinance: attempts=1, elapsed_seconds=0.148, slow_attempts=0, failed_attempts=1

## Price Reconciliation 摘要
- full report: price_reconciliation_report.md
- 601899.SH: compared_sources=eastmoney_direct, yfinance, akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 601985.SH: compared_sources=eastmoney_direct, yfinance, akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 003816.SZ: compared_sources=eastmoney_direct, yfinance, akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes

## Base Quote Fields Summary
| symbol | last | prev_close | open | high | low | volume | amount | change | change_pct | amplitude_pct | completeness | missing_fields | field_sources | exchange | country_market | trading_calendar |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|
| 00883.HK | 21.35 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | HK | HK | HK |
| 601899.SH | 18.42 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 601985.SH | 10.91 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 003816.SZ | 4.27 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |

## Base Quote Field Sources
| symbol | last_source | prev_source | open_source | high_source | low_source | volume_source | amount_source | chg_source | completeness | missing_fields |
|---|---|---|---|---|---|---|---|---|---|---|
| 00883.HK | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 601899.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 601985.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 003816.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |

## Provider Capability Summary
- full report: provider_capability_report.md
| provider | function_name | asset_type | base_price_fields | volume_amount_status | bid_ask_status | turnover_status | minute_status | operation_fit | notes |
|---|---|---|---|---|---|---|---|---|---|
| akshare | fund_etf_spot_em | ETF, QDII_ETF, A_SHARE_ETF | supported_or_calculable | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | Operation fit still depends on quote_trust_tier, strict, freshness, and provider health. |
| akshare | stock_spot_em | A_SHARE, HK_STOCK | mixed:missing,supported | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | A/H stock endpoint availability is environment-dependent. |
| akshare | fund_etf_hist_min_em | ETF, QDII_ETF, A_SHARE_ETF | missing | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | supported_if_endpoint_succeeds | diagnostic_only | ETF minute bars probe via AKShare; does not upgrade operation readiness. |
| eastmoney_direct | stock_get | ETF, A_SHARE_ETF, A_SHARE | mixed:calculable,supported_when_endpoint_succeeds | volume=supported_raw_unit; amount=supported_raw_unit | bid1=not_validated; ask1=not_validated | not_validated | attempted_provider_dependent | False | Reference / operation-candidate only; endpoint stability is not guaranteed. |
| yfinance | ticker_quote | ETF, HK_STOCK, A_SHARE, A_SHARE_ETF, INDEX | mixed:missing,provider_dependent,supported | volume=supported_raw_unit; amount=missing | bid1=missing_or_not_validated; ask1=missing_or_not_validated | missing | attempted_reference_fallback | reference_only | Open-source Yahoo Finance wrapper; not an official exchange feed. |
| manual | manual_price | MANUAL, GOLD | mixed:missing,supported | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | not_supported | conditional | Manual reference price; no market depth fields. |
| mock | mock_quote | TEST | mixed:missing,supported_for_tests | volume=supported_for_tests; amount=supported_for_tests | bid1=not_applicable; ask1=not_applicable | not_applicable | supported_for_tests | False | Development/testing only. |

### Current field quality risks
- raw_provider_unit records: 0
- unit_unknown records: 0
- volume_comparable_across_providers=false records: 4
- amount_comparable_across_providers=false records: 4
- bid/ask not validated; turnover_rate not validated; minute_bars/VWAP/QDII premium not implemented.

## Provider Capability Notes
AKShare:
- base quote fields: supported/partially supported through current normalized fields where provider raw fields are available.
- volume: raw provider unit.
- amount: raw provider unit or unit_unknown.
- bid/ask: not validated.
- turnover_rate: not validated.
- minute_bars: available through minute_probe when supported; reference-only and not operation-grade.

Eastmoney Direct:
- base quote fields: available only when endpoint succeeds.
- trust tier: reference / operation-candidate only.
- stability: unstable in current environment.
- bid/ask: not validated.
- minute_bars: available through minute_probe fallback when supported; reference-only and not operation-grade.

yfinance:
- base quote fields: reference-only for current ETF/watchlist usage.
- volume: raw provider unit.
- not operation-grade for A-share ETF operation path.
- timestamp/precision may differ from local exchange feeds.
- minute_bars: available as reference fallback through minute_probe when supported; provider_dependent and not operation-grade.

Capability label note:
- diagnostic_only in provider capability means capability label only; actual fallback behavior is controlled by minute_mode.

manual:
- GOLD_CNY price only.
- base_quote_completeness usually price_only.
- minute_bars: not supported.

mock:
- development/testing only.
- mock minute bars can be generated for tests when minute probe is enabled.
- not valid for real market decisions.

## Scan Ranking Trace
| symbol | rankable | exclusion_reason | data_quality_inputs | momentum_inputs | field_quality_inputs | liquidity_inputs | reconciliation_inputs | final_score | priority | notes |
|---|---|---|---|---|---|---|---|---:|---|---|
|  | false | not_applicable |  |  |  |  |  |  | not_rankable | scan ranking not applicable for operation profile |

## prices_snapshot 关键明细摘要
| symbol | name | selected_provider/source | quote_purpose | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | price | currency | quote_time | is_stale | stale_reason | required_for_operation | operation_blocking_reason | reference_note |
|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|
| 00883.HK | 中海油H | mock | operation | development | False | False | True | 21.35 | HKD | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 601899.SH | 紫金矿业A | mock | operation | development | False | False | True | 18.42 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 601985.SH | 中国核电 | mock | operation | development | False | False | True | 10.91 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 003816.SZ | 中国广核 | mock | operation | development | False | False | True | 4.27 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |

## Blocking / Error 摘要
### Blocking records
- project=energy, symbol=00883.HK, name=中海油H, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=energy, symbol=601899.SH, name=紫金矿业A, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=energy, symbol=601985.SH, name=中国核电, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=energy, symbol=003816.SZ, name=中国广核, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=

### provider_error
- 无

### quote_time_missing
- 无

### invalid_price
- 无

### stale
- energy 00883.HK 中海油H: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 601899.SH 紫金矿业A: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 601985.SH 中国核电: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 003816.SZ 中国广核: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

### mock fallback not usable
- mock_fallback_not_allowed: energy 00883.HK 中海油H: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: energy 601899.SH 紫金矿业A: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: energy 601985.SH 中国核电: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: energy 003816.SZ 中国广核: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

### reference-only but operation requested
- 无

本排障包只用于定位 provider、runtime、freshness 和 blocking 问题。
