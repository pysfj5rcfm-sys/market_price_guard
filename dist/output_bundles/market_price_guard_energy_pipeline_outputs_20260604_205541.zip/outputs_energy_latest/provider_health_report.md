# Provider Health Report

行情源健康报告仅用于解释价格事实、接口状态和数据完整度，不提供具体操作建议，不做自动交易。

- provider_policy=fast
- quote_purpose=operation

## AKShare ETF
- provider: akshare
- market_category: ETF
- affected_symbols: 
- quote_time_status: not_available
- usable_for_operation: no
- status: not_called
- function_name=fund_etf_spot_em, status=not_called

## AKShare Minute Bars
- provider: akshare
- function_name=fund_etf_hist_min_em
- affected_symbols: 
- status: not_called

## AKShare A股
- provider: akshare
- market_category: A_SHARE
- affected_symbols: 601899.SH
- quote_time_status: stale
- usable_for_operation: no
- function_name=stock_zh_a_spot_em, status=failed, returned_rows=, matched_symbols=, affected_symbols=601899.SH, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A0+t%3A6%2Cm%3A0+t%3A80%2Cm%3A1+t%3A2%2Cm%3A1+t%3A23%2Cm%3A0+t%3A81+s%3A2048&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
- function_name=stock_sh_a_spot_em, status=failed, returned_rows=, matched_symbols=, affected_symbols=601899.SH, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A1+t%3A2%2Cm%3A1+t%3A23&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
- function_name=stock_sz_a_spot_em, status=not_called

## AKShare 港股
- provider: akshare
- market_category: HK
- affected_symbols: 
- quote_time_status: not_available
- usable_for_operation: no
- status: not_called
- function_name=stock_hk_spot_em, status=not_called
- function_name=stock_hk_main_board_spot_em, status=not_called
- function_name=stock_hsgt_sh_hk_spot_em, status=not_called

## YFinance 港股 / A股
- provider: yfinance
- market_category: HK/A_SHARE
- affected_symbols: 00883.HK, 601899.SH, 601985.SH, 003816.SZ
- quote_time_status: stale
- usable_for_operation: no
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_attempted_count: 1
- yfinance_skipped_by_circuit_count: 0
- yfinance_total_elapsed_seconds: 0.148
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- source_limit_note: yfinance is an open-source Yahoo Finance public API wrapper for research/educational use; not an official exchange feed
- function_name=yfinance.Ticker, status=failed, returned_rows=, matched_symbols=00883.HK, affected_symbols=00883.HK, exception_type=, exception_message=
- function_name=yfinance.Ticker, status=unknown, returned_rows=, matched_symbols=601899.SH, affected_symbols=601899.SH, exception_type=, exception_message=
- function_name=yfinance.Ticker, status=unknown, returned_rows=, matched_symbols=601985.SH, affected_symbols=601985.SH, exception_type=, exception_message=
- function_name=yfinance.Ticker, status=unknown, returned_rows=, matched_symbols=003816.SZ, affected_symbols=003816.SZ, exception_type=, exception_message=

## Eastmoney Direct
- provider: eastmoney_direct
- market_category: ETF/A_SHARE
- affected_symbols: 601899.SH, 601985.SH, 003816.SZ
- quote_time_status: stale
- usable_for_operation: no
- source_limit_note: Eastmoney Direct uses Eastmoney public web quote endpoint; not an official exchange real-time feed; first version is reference-grade / operation-candidate only.
- function_name=eastmoney_direct.stock_get, status=failed, secid=1.601899, endpoint=http://push2.eastmoney.com/api/qt/stock/get, matched_symbols=601899.SH, affected_symbols=601899.SH, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>, quote_trust_tier=development, usable_for_operation=False, confirmation_required=True
- function_name=eastmoney_direct.stock_get, status=failed, secid=1.601985, endpoint=http://push2.eastmoney.com/api/qt/stock/get, matched_symbols=601985.SH, affected_symbols=601985.SH, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>, quote_trust_tier=development, usable_for_operation=False, confirmation_required=True
- function_name=eastmoney_direct.stock_get, status=failed, secid=0.003816, endpoint=http://push2.eastmoney.com/api/qt/stock/get, matched_symbols=003816.SZ, affected_symbols=003816.SZ, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>, quote_trust_tier=development, usable_for_operation=False, confirmation_required=True

## Manual
- provider: manual
- status: not_called

## Provider call summary
- function_name=akshare, call_count=0, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=, failed=True, exception_type=, exception_message=
- function_name=stock_sh_a_spot_em, call_count=1, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=5.2, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A1+t%3A2%2Cm%3A1+t%3A23&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
- function_name=stock_zh_a_spot_em, call_count=1, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=4.412, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A0+t%3A6%2Cm%3A0+t%3A80%2Cm%3A1+t%3A2%2Cm%3A1+t%3A23%2Cm%3A0+t%3A81+s%3A2048&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))

## Provider Health Summary
| provider | planned_count | actual_attempt_count | success_count | failure_count | timeout_count | skipped_count | elapsed_seconds | slow_attempt_count | cache_hit_count | cache_miss_count | failure_cached_count | circuit_open_count | repeated_call_prevented_count | top_failure_reasons |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| akshare | 4 | 2 | 0 | 2 | 2 | 3 | 19.358 | 2 | 0 | 4 | 0 | 2 | 0 | provider_timeout:2, skipped_by_provider_circuit:2, hk_akshare_skipped_after_fast_provider_failure_budget:1 |
| eastmoney_direct | 3 | 3 | 0 | 3 | 3 | 0 | 0.036 | 0 | 0 | 3 | 0 | 0 | 0 | provider_timeout:3 |
| mock | 4 | 4 | 4 | 0 | 0 | 0 | 0.013 | 0 | 0 | 4 | 0 | 0 | 0 | none |
| yfinance | 4 | 1 | 0 | 1 | 0 | 3 | 0.148 | 0 | 0 | 4 | 0 | 0 | 0 | provider_skipped_by_runtime_budget:3, invalid_price,assumed_currency_hkd,quote_time_missing:1 |

## Provider attempts by symbol
### 00883.HK
- provider_policy: fast
- configured_provider_priority: akshare, yfinance, mock
- provider_planned_chain: yfinance, akshare, mock
- effective_provider_chain: yfinance, akshare, mock
- actual_provider_attempted: yfinance, mock
- provider_skip_reasons: akshare=hk_akshare_skipped_after_fast_provider_failure_budget
- normalized_symbol: 00883.HK
- route_reason: account_generic_hk_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: hk_reference_unavailable
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=yfinance, function_name=yfinance.Ticker, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.148, slow_provider_attempt=False, reason=invalid_price,assumed_currency_hkd,quote_time_missing, exception_type=, exception_message=
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=hk_akshare_skipped_after_fast_provider_failure_budget, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=21.35, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.002, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 601899.SH
- provider_policy: fast
- configured_provider_priority: akshare, yfinance, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: eastmoney_direct, akshare, mock
- provider_skip_reasons: yfinance=provider_skipped_by_runtime_budget
- normalized_symbol: 601899.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=1.601899, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.009, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=yfinance, function_name=yfinance, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_skipped_by_runtime_budget, exception_type=, exception_message=
  - provider=akshare, function_name=stock_zh_a_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=9.679, slow_provider_attempt=True, reason=provider_timeout, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A0+t%3A6%2Cm%3A0+t%3A80%2Cm%3A1+t%3A2%2Cm%3A1+t%3A23%2Cm%3A0+t%3A81+s%3A2048&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=akshare, function_name=stock_sh_a_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=9.679, slow_provider_attempt=True, reason=provider_timeout, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='82.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A1+t%3A2%2Cm%3A1+t%3A23&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='82.push2.eastmoney.com', port=443): Failed to resolve '82.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=18.42, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.006, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 601985.SH
- provider_policy: fast
- configured_provider_priority: akshare, yfinance, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: eastmoney_direct, mock
- provider_skip_reasons: yfinance=provider_skipped_by_runtime_budget, akshare=skipped_by_provider_circuit
- normalized_symbol: 601985.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=1.601985, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.017, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=yfinance, function_name=yfinance, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_skipped_by_runtime_budget, exception_type=, exception_message=
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=10.91, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.002, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 003816.SZ
- provider_policy: fast
- configured_provider_priority: akshare, yfinance, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: eastmoney_direct, mock
- provider_skip_reasons: yfinance=provider_skipped_by_runtime_budget, akshare=skipped_by_provider_circuit
- normalized_symbol: 003816.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=0.003816, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.01, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=yfinance, function_name=yfinance, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_skipped_by_runtime_budget, exception_type=, exception_message=
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=4.27, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=
