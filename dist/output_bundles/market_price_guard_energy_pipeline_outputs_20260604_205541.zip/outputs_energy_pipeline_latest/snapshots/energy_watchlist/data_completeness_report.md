# 数据完整度报告

quote_purpose: reference
reconcile_mode: default
可用于具体操作建议：否

本工具不做自动交易，不输出具体操作建议，只输出价格事实、数据源、时间戳、市场状态和数据完整度。

行情源健康状态详见 provider_health_report.md。

## Config Source / Layer Manifest
- layer_name: energy_watchlist
- config_source_path: config/universes/energy_watchlist.yaml
- config_source_hash_sha256: 6d48fe4a705d
- configured_symbol_count: 24
- loaded_symbol_count: 24
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Strict blocking records

## Reference mode warning
- 本轮为 reference 模式，可用于快速参考，不可用于具体操作建议。
- operation confirmation required: 如需具体执行动作或盘中价位，必须运行 operation-grade / strict 输出。
- 无

## Provider diagnostics
- 无 AKShare 记录

## Provider routing notes
- 00883.HK: provider_policy=fast
- 00883.HK: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 00883.HK: mock fallback 不可用于具体操作建议
- 601899.SH: provider_policy=fast
- 601899.SH: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 601899.SH: mock fallback 不可用于具体操作建议
- 601985.SH: provider_policy=fast
- 601985.SH: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 601985.SH: mock fallback 不可用于具体操作建议
- 003816.SZ: provider_policy=fast
- 003816.SZ: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 003816.SZ: mock fallback 不可用于具体操作建议
- 600938.SH: provider_policy=fast
- 600900.SH: provider_policy=fast
- 601088.SH: provider_policy=fast
- 600489.SH: provider_policy=fast
- 600547.SH: provider_policy=fast
- 603993.SH: provider_policy=fast
- 600188.SH: provider_policy=fast
- 600795.SH: provider_policy=fast
- 600028.SH: provider_policy=fast
- 601857.SH: provider_policy=fast
- 601225.SH: provider_policy=fast
- 600011.SH: provider_policy=fast
- 600027.SH: provider_policy=fast
- 600905.SH: provider_policy=fast
- 600886.SH: provider_policy=fast
- 000975.SZ: provider_policy=fast
- 000630.SZ: provider_policy=fast
- 000878.SZ: provider_policy=fast
- 600362.SH: provider_policy=fast
- 601600.SH: provider_policy=fast

## Quote trust tier diagnostics
- quote_purpose: reference
- quote_trust_tier summary: operation=0, reference=0, development=24
- operation-grade records: 
- reference-grade records: 
- development-grade records: 00883.HK, 601899.SH, 601985.SH, 003816.SZ, 600938.SH, 600900.SH, 601088.SH, 600489.SH, 600547.SH, 603993.SH, 600188.SH, 600795.SH, 600028.SH, 601857.SH, 601225.SH, 600011.SH, 600027.SH, 600905.SH, 600886.SH, 000975.SZ, 000630.SZ, 000878.SZ, 600362.SH, 601600.SH
- confirmation_required records: 00883.HK, 601899.SH, 601985.SH, 003816.SZ, 600938.SH, 600900.SH, 601088.SH, 600489.SH, 600547.SH, 603993.SH, 600188.SH, 600795.SH, 600028.SH, 601857.SH, 601225.SH, 600011.SH, 600027.SH, 600905.SH, 600886.SH, 000975.SZ, 000630.SZ, 000878.SZ, 600362.SH, 601600.SH
- operation confirmation required: reference-grade records are not operation-grade permission.

## Source agreement diagnostics
- full report: price_reconciliation_report.md
- 601899.SH: compared_sources=eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 601985.SH: compared_sources=eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 003816.SZ: compared_sources=eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes

## Base quote completeness summary
- base_quote_completeness counts:
- missing: 20
- price_only: 4
- missing fields top: amount:24, high_price:24, low_price:24, open_price:24, prev_close:24, volume:24, last_price:20
- base quote fields are auxiliary diagnostics; missing fields do not change existing strict in this version.

| symbol | base_quote_completeness | available | missing | missing_fields |
|---|---|---:|---:|---|
| 00883.HK | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 601899.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 601985.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 003816.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 600938.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600900.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601088.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600489.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600547.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603993.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600188.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600795.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600028.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601857.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601225.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600011.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600027.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600905.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600886.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000975.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000630.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000878.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600362.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601600.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |

### Base quote caveats
- volume/amount follow provider raw units unless unit normalization is explicitly available.
- cross-provider volume/amount comparison is not reliable until provider field validation is completed.
- base quote missing does not change existing strict; base quote and field capability issues do not change existing strict in v0.7.1.6.
- operation still depends on quote_trust_tier / usable_for_operation / strict / freshness.
- field completeness is a diagnostic aid, not operation guidance.

## Field Quality / Provider Capability
- volume_comparable_across_providers=true records: 0
- amount_comparable_across_providers=true records: 0
- unit_unknown records: 0
- raw_provider_unit records: 0
- field_validation_status counts: development_only:24
- not_validated fields: bid1_price, ask1_price, turnover_rate
- not_implemented fields: minute_bars, intraday_vwap, iopv, premium_pct
- field validation issues do not change existing strict in v0.7.1.6.
- operation still depends on quote_trust_tier / usable_for_operation / strict / freshness.
- capability data is diagnostic, not operation guidance.

## Minute Bars Completeness
- include_minute_bars: False
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- minute_bars_available count: 0
- operation_candidate_symbols_count: 0
- operation_candidate_minute_available_count: 0
- operation_candidate_minute_missing_count: 0
- unavailable count: 0
- not_supported count: 0
- provider_error count: 0
- symbol_not_found count: 0
- stale count: 0
- akshare_attempted_count: 0
- akshare_success_count: 0
- akshare_error_count: 0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_empty_response_count: 0
- yfinance_parse_error_count: 0
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- fallback_skipped_yfinance_circuit_open_count: 0
- yfinance_last_error: 
- eastmoney_attempted_count: 0
- eastmoney_success_count: 0
- eastmoney_error_count: 0
- eastmoney_empty_response_count: 0
- eastmoney_parse_error_count: 0
- empty_response count: 0
- after_close_possible_count: 0
- retry_during_trading_hours_count: 0
- current session summary: missing:24
- upload bundle uses compact minute notes; full provider diagnostics remain in debug_bundle.md.
- status counts:
  - not_attempted: 24
- by provider:
  - missing: 24
- minute bars missing does not change existing strict in v0.7.3.
- Eastmoney minute bars are diagnostic/reference only.
- minute fallback behavior depends on minute_mode; balanced skips Eastmoney minute fallback by default.
- minute bars are diagnostic only.

## Scan Ranking Summary
- total_symbols: 24
- rankable_count: 0
- not_rankable_count: 24
- high_priority_count: 0
- medium_priority_count: 0
- low_priority_count: 0
- symbol_not_found_count: 0
- provider_issue_count: 20
- data_insufficient_count: 0
- exclusion reasons: development_only:4, provider_error:20
- ranking does not affect strict.
- See price_reconciliation_report.md for full multi-source comparison details.

## Runtime freshness diagnostics
- 详见 runtime_diagnostics.md
- provider_policy: fast
- total_elapsed_seconds: 0.05
- run_time_budget_exceeded: False
- max_quote_lag_seconds: 1319164.438
- max_data_lag_seconds: 300.0

## AKShare price records
- 无

## AKShare quote freshness details
- 无

## AKShare / 数据质量问题
- 无

## 黄金手工价说明
黄金持仓参考价为用户手工录入价，不等同于国际现货金价；用于科技账户防守仓/潜在转科技资金的参考，实际操作前需核对账户内可卖价、手续费、点差和到账规则。

## 如果为否，原因
- 存在价格缺失
- 存在 stale 价格
- 存在 quote_time_missing，无法证明价格新鲜

## 缺失价格列表
- energy 600938.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600900.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 601088.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600489.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600547.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 603993.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600188.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600795.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600028.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 601857.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 601225.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600011.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600027.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600905.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600886.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 000975.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 000630.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 000878.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600362.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 601600.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

## stale 价格列表
- energy 00883.HK 中海油H: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 601899.SH 紫金矿业A: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 601985.SH 中国核电: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 003816.SZ 中国广核: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

## quote_time 缺失列表
- quote_time_missing: energy 600938.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600900.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601088.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600489.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600547.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 603993.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600188.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600795.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600028.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601857.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601225.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600011.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600027.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600905.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600886.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000975.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000630.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000878.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600362.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601600.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

## manual price records
- 无

## warning
- energy 00883.HK 中海油H: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 601899.SH 紫金矿业A: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 601985.SH 中国核电: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 003816.SZ 中国广核: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 600938.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600900.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 601088.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600489.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600547.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 603993.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600188.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600795.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600028.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 601857.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 601225.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600011.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600027.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600905.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600886.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 000975.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 000630.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 000878.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 600362.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- energy 601600.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

## 不确定性
- 手续费、点差、赎回到账规则未自动计算。
- GOLD_CNY 需以后续实际账户可卖价为准。

## 允许使用范围
- 可用于价格事实同步、数据源核对、时间戳核对、市场状态核对和数据完整度检查。
- 收盘后价格仅可作为收盘/最后成交参考。
- GOLD_CNY 仅可作为科技账户防守仓/潜在转科技资金参考。

## 禁止使用范围
- 不可用于自动交易。
- 不输出具体操作建议。
- 若 required_for_operation 指标缺失、stale、quote_time 缺失或无效，不可用于具体操作建议。
- 收盘/最后成交参考价不可用于盘中盘中高频判断。
