# market_price_guard 上传包

## 基本信息
- generated_at: 2026-06-04T11:11:04.437706+00:00
- profile: energy
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_energy_watchlist_latest
- universe_name: energy_watchlist
- universe_type: candidate_watchlist
- core_count: 0
- watchlist_count: 24
- scan_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: energy_watchlist
- config_source_path: config/universes/energy_watchlist.yaml
- config_source_hash_sha256: 6d48fe4a705d
- configured_symbol_count: 24
- loaded_symbol_count: 24
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## 本轮结论
- 可用于快速参考：否
- 可用于具体操作建议：否
- 当前用途级别：reference-only
- confirmation_required 数量: 24
- blocking records 数量: 0

## 数据完整度摘要
- strict/exit_code: 0
- provider_error 数量: 20
- stale 数量: 4
- quote_time_missing 数量: 20
- invalid_price 数量: 20
- mock fallback not usable 数量: 4
- run_time_budget_exceeded: False

### Blocking records 摘要
- 无

## Quote Trust Tier 摘要
- operation-grade records 数量: 0
- reference-grade records 数量: 0
- development-grade records 数量: 24
- usable_for_reference=true 数量: 0
- usable_for_operation=true 数量: 0
- confirmation_required=true 数量: 24

## 基础行情快照 / Base Quote Snapshot
| symbol | name | last | chg% | high | low | amount | base | data_status | provider | required_for_operation |
|---|---|---:|---:|---:|---:|---:|---|---|---|---|
| 00883.HK | 中海油H | 21.35 | — | — | — | — | price_only | price_only | mock | False |
| 601899.SH | 紫金矿业A | 18.42 | — | — | — | — | price_only | price_only | mock | False |
| 601985.SH | 中国核电 | 10.91 | — | — | — | — | price_only | price_only | mock | False |
| 003816.SZ | 中国广核 | 4.27 | — | — | — | — | price_only | price_only | mock | False |
| 600938.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600900.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601088.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600489.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600547.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 603993.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600188.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600795.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600028.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601857.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601225.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600011.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600027.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600905.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600886.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000975.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000630.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000878.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600362.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601600.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
- candidate/watchlist/scan records do not affect core strict.
- symbol_not_found in candidate or scan output is a data coverage status, not a system failure.
- not usable for concrete operation recommendations.

## 字段质量提示 / Field Quality Notes
- volume/amount are shown in provider raw units unless explicitly validated.
- cross-provider volume/amount comparison is unsafe in this version.
- bid/ask, turnover_rate, minute_bars, VWAP and QDII premium are not validated or not implemented.
- See debug_bundle.md and provider_capability_report.md for details.

## 扫描优先级摘要 / Scan Priority Summary
| priority | count | note |
|---|---:|---|
| high | 0 | review candidates only |
| medium | 0 | reference candidates |
| low | 0 | weak or incomplete |
| not_rankable | 24 | data unavailable / provider issue |

## Top Scan Candidates
| rank | symbol | name | score | priority | chg% | base | provider | note |
|---:|---|---|---:|---|---:|---|---|---|
|  |  |  |  | not_rankable |  | missing |  | no rankable records |

- Scan ranking is not operation guidance.
- Reference-only does not mean operation-ready.
- Operation decisions require operation-grade guard output.
- Candidate/watchlist/scan records do not affect core strict.
- volume/amount unit normalization is not complete.
- minute bars / VWAP / QDII premium are not implemented.

## Reconciliation Summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=3
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 项目核心内容
### Candidate watchlist

Candidate watchlist records are reference/conditional observations. They do not affect core operation strict.

- universe_name: energy_watchlist
- universe_type: candidate_watchlist

| symbol | name | role | report_group | price | source | quote_time | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | source_agreement_status | data_status | note |
|---|---|---|---|---:|---|---|---|---|---|---|---|---|---|
| 00883.HK | 中海油H | energy_core_equity | 能源账户核心价格 | 21.35 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True |  | check_required |  |
| 601899.SH | 紫金矿业A | energy_core_equity | 能源账户核心价格 | 18.42 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 601985.SH | 中国核电 | energy_core_equity | 能源账户核心价格 | 10.91 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 003816.SZ | 中国广核 | energy_core_equity | 能源账户核心价格 | 4.27 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 600938.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600900.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 601088.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600489.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600547.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 603993.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600188.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600795.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600028.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601857.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601225.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600011.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600027.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600905.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600886.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000975.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000630.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000878.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600362.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601600.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |

## Watchlist Review Priority
| priority | symbol | name | score | status | last | chg% | base | provider | note |
|---|---|---|---:|---|---:|---:|---|---|---|
| not_rankable | 000630.SZ | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 000878.SZ | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 000975.SZ | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 003816.SZ | 中国广核 | — | development_only | 4.27 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 00883.HK | 中海油H | — | development_only | 21.35 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600011.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600027.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600028.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600188.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600362.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600489.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600547.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600795.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600886.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600900.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600905.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600938.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601088.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601225.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601600.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601857.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601899.SH | 紫金矿业A | — | development_only | 18.42 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601985.SH | 中国核电 | — | development_only | 10.91 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 603993.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |

## Compact Base Quote Table
| symbol | name | last | chg% | high | low | amount | base | data_status | provider | required_for_operation |
|---|---|---:|---:|---:|---:|---:|---|---|---|---|
| 00883.HK | 中海油H | 21.35 | — | — | — | — | price_only | price_only | mock | False |
| 601899.SH | 紫金矿业A | 18.42 | — | — | — | — | price_only | price_only | mock | False |
| 601985.SH | 中国核电 | 10.91 | — | — | — | — | price_only | price_only | mock | False |
| 003816.SZ | 中国广核 | 4.27 | — | — | — | — | price_only | price_only | mock | False |
| 600938.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600900.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601088.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600489.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600547.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 603993.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600188.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600795.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600028.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601857.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601225.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600011.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600027.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600905.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600886.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000975.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000630.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000878.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600362.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601600.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |

## Base Quote Summary
- base_quote_completeness counts:
- missing: 20
- price_only: 4
- missing fields top: amount:24, high_price:24, low_price:24, open_price:24, prev_close:24, volume:24, last_price:20
- base quote fields are auxiliary diagnostics; missing fields do not change existing strict in this version.

| symbol | base_quote_completeness | available | missing | missing_fields |
|---|---|---:|---:|---|
| 00883.HK | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 601899.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 601985.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 003816.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 600938.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600900.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601088.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600489.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600547.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603993.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600188.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600795.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600028.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601857.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601225.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600011.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600027.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600905.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600886.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000975.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000630.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000878.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600362.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601600.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |

## Provider Coverage / Failure Reasons
| symbol | registry_found | provider_attempted | provider_status | data_status | likely_reason | suggested_next_step |
|---|---|---|---|---|---|---|
| 00883.HK | True | mock | success | price_only | unsupported_hk_provider | keep as candidate; does not affect core strict |
| 601899.SH | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 601985.SH | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 003816.SZ | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 600938.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600900.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601088.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600489.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600547.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 603993.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600188.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600795.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600028.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601857.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601225.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600011.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600027.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600905.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600886.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000975.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000630.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000878.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600362.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601600.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |

## Safety Notes

- Scan ranking is not operation guidance.
- Reference-only does not mean operation-ready.
- Operation decisions require operation-grade guard output.
- Candidate/watchlist/scan records do not affect core strict.
- volume/amount unit normalization is not complete.
- minute bars / VWAP / QDII premium are not implemented.

## Universe isolation
- universe_name: energy_watchlist
- universe_type: candidate_watchlist
- core strict pollution isolation: enabled
- this universe is not used for core operation strict blocking.
- not usable for concrete operation recommendations.

## Reference / Operation 使用提示
- 本轮为快速参考模式。
- 可以用于快速参考。
- 不可用于具体操作建议。
- 不可给出具体执行动作、盘中高频判断或执行参数参数。
- 如需具体操作，请运行 operation 输出或补充有效盘口信息。

## Debug 提示
- 如出现 strict=2、blocking records、provider_error、quote_time_missing、invalid_price、stale、selected_provider=mock、fallback_used 异常、run_time_budget_exceeded、slow_provider_attempts、quote_time 可疑或报告冲突，请补充 debug_bundle.md。
- 本上传包只汇总数据状态、可用性和阻断原因。
