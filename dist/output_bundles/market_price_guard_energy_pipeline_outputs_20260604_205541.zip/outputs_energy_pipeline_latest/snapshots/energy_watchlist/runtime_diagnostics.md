# Runtime Diagnostics

- run_start_time_utc: 2026-06-04T11:11:04.387739+00:00
- run_end_time_utc: 2026-06-04T11:11:04.437706+00:00
- total_elapsed_seconds: 0.05
- profile: energy
- provider_mode: live
- provider_policy: fast
- strict: False
- quote_purpose: reference
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: 
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 0
- provider_runtime_budget_summary: none
- quote_cache_hit_count: 24
- quote_cache_miss_count: 41
- quote_cache_failure_hit_count: 20
- quote_cache_success_hit_count: 4
- repeated_provider_call_prevented_count: 24
- universe_name: energy_watchlist
- universe_type: candidate_watchlist
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319164.438
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-20T12:45:00+08:00

## Provider Runtime Summary
- account: energy
- layer: energy_watchlist
- total_elapsed_seconds: 0.05
- run_time_budget_exceeded: False
- slow_provider_attempts: 0
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 0

## per_provider_elapsed_seconds
- yfinance: 0.0

## Config Source / Layer Manifest
- layer_name: energy_watchlist
- config_source_path: config/universes/energy_watchlist.yaml
- config_source_hash_sha256: 6d48fe4a705d
- configured_symbol_count: 24
- loaded_symbol_count: 24
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 00883.HK: 0.0
- 601899.SH: 0.0
- 601985.SH: 0.0
- 003816.SZ: 0.0
- 600938.SH: 0.0
- 600900.SH: 0.0
- 601088.SH: 0.0
- 600489.SH: 0.0
- 600547.SH: 0.0
- 603993.SH: 0.0
- 600188.SH: 0.0
- 600795.SH: 0.0
- 600028.SH: 0.0
- 601857.SH: 0.0
- 601225.SH: 0.0
- 600011.SH: 0.0
- 600027.SH: 0.0
- 600905.SH: 0.0
- 600886.SH: 0.0
- 000975.SZ: 0.0
- 000630.SZ: 0.0
- 000878.SZ: 0.0
- 600362.SH: 0.0
- 601600.SH: 0.0

## slow_provider_attempts
- 无

## provider_call_cache
- total_provider_calls: 0
- cache_hits: 0
- provider_call_count_by_function: 无

## Cache / Reuse Summary
- quote_cache_hit_count: 24
- quote_cache_miss_count: 41
- quote_cache_failure_hit_count: 20
- quote_cache_success_hit_count: 4
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 24
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 0
- cache_hit_by_layer: energy_watchlist:24
- cache_hit_by_provider: mock:24

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 0
- provider_budget_account: energy
- provider_budget_run_id: 2026-06-04T11:11:04.387739+00:00
- provider_circuit_open: {}
- provider_budget_by_provider: none
