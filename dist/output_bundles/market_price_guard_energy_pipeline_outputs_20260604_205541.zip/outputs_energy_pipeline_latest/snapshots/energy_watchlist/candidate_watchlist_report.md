# Candidate Watchlist Report

Candidate watchlist records are reference/conditional observations. They do not affect core operation strict.

- universe_name: energy_watchlist
- universe_type: candidate_watchlist

| symbol | name | role | report_group | price | source | quote_time | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | source_agreement_status | data_status | note |
|---|---|---|---|---:|---|---|---|---|---|---|---|---|---|
| 00883.HK | 中海油H | energy_core_equity | 能源账户核心价格 | 21.35 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True |  | check_required |  |
| 601899.SH | 紫金矿业A | energy_core_equity | 能源账户核心价格 | 18.42 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 601985.SH | 中国核电 | energy_core_equity | 能源账户核心价格 | 10.91 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 003816.SZ | 中国广核 | energy_core_equity | 能源账户核心价格 | 4.27 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 600938.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600900.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 601088.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600489.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600547.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 603993.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600188.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600795.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600028.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601857.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601225.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600011.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600027.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600905.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600886.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000975.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000630.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000878.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600362.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601600.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |

## Watchlist Review Priority
| priority | symbol | name | score | status | last | chg% | base | provider | note |
|---|---|---|---:|---|---:|---:|---|---|---|
| not_rankable | 000630.SZ | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 000878.SZ | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 000975.SZ | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 003816.SZ | 中国广核 | — | development_only | 4.27 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 00883.HK | 中海油H | — | development_only | 21.35 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600011.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600027.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600028.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600188.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600362.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600489.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600547.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600795.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600886.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600900.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600905.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600938.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601088.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601225.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601600.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601857.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601899.SH | 紫金矿业A | — | development_only | 18.42 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 601985.SH | 中国核电 | — | development_only | 10.91 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 603993.SH | unknown | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |

## Compact Base Quote Table
| symbol | name | last | chg% | high | low | amount | base | data_status | provider | required_for_operation |
|---|---|---:|---:|---:|---:|---:|---|---|---|---|
| 00883.HK | 中海油H | 21.35 | — | — | — | — | price_only | price_only | mock | False |
| 601899.SH | 紫金矿业A | 18.42 | — | — | — | — | price_only | price_only | mock | False |
| 601985.SH | 中国核电 | 10.91 | — | — | — | — | price_only | price_only | mock | False |
| 003816.SZ | 中国广核 | 4.27 | — | — | — | — | price_only | price_only | mock | False |
| 600938.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600900.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601088.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600489.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600547.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 603993.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600188.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600795.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600028.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601857.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601225.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600011.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600027.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600905.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600886.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000975.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000630.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 000878.SZ | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 600362.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |
| 601600.SH | unknown | — | — | — | — | — | missing | provider_error | mock | False |

## Base Quote Summary
- base_quote_completeness counts:
- missing: 20
- price_only: 4
- missing fields top: amount:24, high_price:24, low_price:24, open_price:24, prev_close:24, volume:24, last_price:20
- base quote fields are auxiliary diagnostics; missing fields do not change existing strict in this version.

| symbol | base_quote_completeness | available | missing | missing_fields |
|---|---|---:|---:|---|
| 00883.HK | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 601899.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 601985.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 003816.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 600938.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600900.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601088.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600489.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600547.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603993.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600188.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600795.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600028.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601857.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601225.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600011.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600027.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600905.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600886.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000975.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000630.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000878.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600362.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601600.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |

## Provider Coverage / Failure Reasons
| symbol | registry_found | provider_attempted | provider_status | data_status | likely_reason | suggested_next_step |
|---|---|---|---|---|---|---|
| 00883.HK | True | mock | success | price_only | unsupported_hk_provider | keep as candidate; does not affect core strict |
| 601899.SH | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 601985.SH | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 003816.SZ | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 600938.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600900.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601088.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600489.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600547.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 603993.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600188.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600795.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600028.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601857.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601225.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600011.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600027.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600905.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600886.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000975.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000630.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000878.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600362.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601600.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |

## Safety Notes

- Scan ranking is not operation guidance.
- Reference-only does not mean operation-ready.
- Operation decisions require operation-grade guard output.
- Candidate/watchlist/scan records do not affect core strict.
- volume/amount unit normalization is not complete.
- minute bars / VWAP / QDII premium are not implemented.
