# market_price_guard 排障包

## 基本信息
- generated_at: 2026-06-04T11:11:03.927104+00:00
- profile: energy
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_energy_scan_latest
- universe_name: energy_scan
- universe_type: scan_universe

## Symbol Registry Resolution 摘要
- registry_enabled: true
- registry_path: /Users/chenyulin/Documents/AIProjects/market_price_guard/config/symbol_registry.yaml
- universe_name: energy_scan
- universe_type: scan_universe
- core_count: 0
- watchlist_count: 0
- scan_count: 41
- operation_candidate_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: energy_scan
- config_source_path: config/universes/energy_scan.yaml
- config_source_hash_sha256: b55884e1846c
- configured_symbol_count: 41
- loaded_symbol_count: 41
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Provider Health 摘要
- provider_policy: fast
- provider_mode: live
- function_name=stock_hk_main_board_spot_em, call_count=1, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=4.573, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='81.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A128+t%3A3&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='81.push2.eastmoney.com', port=443): Failed to resolve '81.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
- function_name=stock_hk_spot_em, call_count=1, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=4.897, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='72.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A128+t%3A3%2Cm%3A128+t%3A4%2Cm%3A128+t%3A1%2Cm%3A128+t%3A2&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='72.push2.eastmoney.com', port=443): Failed to resolve '72.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
- function_name=stock_hsgt_sh_hk_spot_em, call_count=1, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=4.781, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?np=1&fltt=1&invt=2&fs=b%3ADLMK0144&fields=f12%2Cf13%2Cf14%2Cf19%2Cf1%2Cf2%2Cf4%2Cf3%2Cf152%2Cf17%2Cf18%2Cf15%2Cf16%2Cf5%2Cf6&fid=f12&pn=1&pz=100&po=1&dect=1&wbp2u=%7C0%7C0%7C0%7Cweb (Caused by NameResolutionError("HTTPSConnection(host='push2.eastmoney.com', port=443): Failed to resolve 'push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))

### Provider attempts
### 00883.HK
- provider_policy: fast
- configured_provider_priority: yfinance, akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: akshare, mock
- provider_skip_reasons: none
- normalized_symbol: 00883.HK
- route_reason: account_generic_hk_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=stock_hk_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=14.354, slow_provider_attempt=True, reason=provider_timeout, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='72.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A128+t%3A3%2Cm%3A128+t%3A4%2Cm%3A128+t%3A1%2Cm%3A128+t%3A2&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='72.push2.eastmoney.com', port=443): Failed to resolve '72.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=akshare, function_name=stock_hk_main_board_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=14.354, slow_provider_attempt=True, reason=provider_timeout, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='81.push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f12&fs=m%3A128+t%3A3&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf62%2Cf128%2Cf136%2Cf115%2Cf152 (Caused by NameResolutionError("HTTPSConnection(host='81.push2.eastmoney.com', port=443): Failed to resolve '81.push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=akshare, function_name=stock_hsgt_sh_hk_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=14.354, slow_provider_attempt=True, reason=provider_timeout, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?np=1&fltt=1&invt=2&fs=b%3ADLMK0144&fields=f12%2Cf13%2Cf14%2Cf19%2Cf1%2Cf2%2Cf4%2Cf3%2Cf152%2Cf17%2Cf18%2Cf15%2Cf16%2Cf5%2Cf6&fid=f12&pn=1&pz=100&po=1&dect=1&wbp2u=%7C0%7C0%7C0%7Cweb (Caused by NameResolutionError("HTTPSConnection(host='push2.eastmoney.com', port=443): Failed to resolve 'push2.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=21.35, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.009, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 601899.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: eastmoney_direct, mock
- provider_skip_reasons: none
- normalized_symbol: 601899.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=1.601899, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.022, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=18.42, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.004, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 601985.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: eastmoney_direct, mock
- provider_skip_reasons: none
- normalized_symbol: 601985.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=1.601985, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.012, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=10.91, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 003816.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: eastmoney_direct, mock
- provider_skip_reasons: none
- normalized_symbol: 003816.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: provider_timeout
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct.stock_get, status=failed, secid=0.003816, endpoint=http://push2.eastmoney.com/api/qt/stock/get, request_status=failed, retry_count=0, final_status=failed, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.009, slow_provider_attempt=False, reason=provider_timeout, exception_type=URLError, exception_message=<urlopen error [Errno 8] nodename nor servname provided, or not known>
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=4.27, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.002, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 600938.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: mock
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit
- normalized_symbol: 600938.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.002, slow_provider_attempt=False, reason=symbol_not_found, exception_type=, exception_message=
### 600900.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: mock
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit
- normalized_symbol: 600900.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.002, slow_provider_attempt=False, reason=symbol_not_found, exception_type=, exception_message=
### 601088.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: mock
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit
- normalized_symbol: 601088.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.002, slow_provider_attempt=False, reason=symbol_not_found, exception_type=, exception_message=
### 600489.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600489.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600547.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600547.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 603993.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 603993.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600188.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600188.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600795.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600795.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600028.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600028.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 601857.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 601857.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 601225.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 601225.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600011.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600011.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600027.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600027.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600905.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600905.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600886.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600886.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 000975.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 000975.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 000630.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 000630.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 000878.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 000878.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600362.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600362.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 601600.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 601600.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 601808.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 601808.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600583.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600583.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600256.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600256.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 002128.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 002128.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 000983.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 000983.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600348.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600348.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 601001.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 601001.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600985.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600985.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 000933.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 000933.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600988.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600988.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 603979.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 603979.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600497.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600497.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 000807.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 000807.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 002155.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 002155.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600021.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600021.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 600642.SH
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600642.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
### 000027.SZ
- provider_policy: fast
- configured_provider_priority: mock
- provider_planned_chain: eastmoney_direct, mock
- effective_provider_chain: eastmoney_direct, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 000027.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=eastmoney_direct, function_name=eastmoney_direct, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=

## Runtime Diagnostics 摘要
- run_start_time_utc: 2026-06-04T11:10:49.446730+00:00
- run_end_time_utc: 2026-06-04T11:11:03.927104+00:00
- total_elapsed_seconds: 14.48
- profile: energy
- provider_mode: live
- provider_policy: fast
- strict: False
- quote_purpose: reference
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: disabled_in_fast_mode
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: 
- provider_timeout_count: 4
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 3
- provider_runtime_budget_summary: akshare:attempts=1,elapsed=14.354,slow=1,failed=1; eastmoney_direct:attempts=3,elapsed=0.043,slow=0,failed=3; mock:attempts=7,elapsed=0.024,slow=0,failed=3
- quote_cache_hit_count: 0
- quote_cache_miss_count: 41
- quote_cache_failure_hit_count: 0
- quote_cache_success_hit_count: 0
- repeated_provider_call_prevented_count: 0
- universe_name: energy_scan
- universe_type: scan_universe
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319163.927
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-20T12:45:00+08:00

## Provider Runtime Summary
- account: energy
- layer: energy_scan
- total_elapsed_seconds: 14.48
- run_time_budget_exceeded: False
- slow_provider_attempts: 3
- provider_timeout_count: 6
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 74

## per_provider_elapsed_seconds
- akshare: 43.062
- mock: 0.024
- eastmoney_direct: 0.043
- yfinance: 0.0

## Config Source / Layer Manifest
- layer_name: energy_scan
- config_source_path: config/universes/energy_scan.yaml
- config_source_hash_sha256: b55884e1846c
- configured_symbol_count: 41
- loaded_symbol_count: 41
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 00883.HK: 43.071
- 601899.SH: 0.026
- 601985.SH: 0.015
- 003816.SZ: 0.011
- 600938.SH: 0.002
- 600900.SH: 0.002
- 601088.SH: 0.002
- 600489.SH: 0.0
- 600547.SH: 0.0
- 603993.SH: 0.0
- 600188.SH: 0.0
- 600795.SH: 0.0
- 600028.SH: 0.0
- 601857.SH: 0.0
- 601225.SH: 0.0
- 600011.SH: 0.0
- 600027.SH: 0.0
- 600905.SH: 0.0
- 600886.SH: 0.0
- 000975.SZ: 0.0
- 000630.SZ: 0.0
- 000878.SZ: 0.0
- 600362.SH: 0.0
- 601600.SH: 0.0
- 601808.SH: 0.0
- 600583.SH: 0.0
- 600256.SH: 0.0
- 002128.SZ: 0.0
- 000983.SZ: 0.0
- 600348.SH: 0.0
- 601001.SH: 0.0
- 600985.SH: 0.0
- 000933.SZ: 0.0
- 600988.SH: 0.0
- 603979.SH: 0.0
- 600497.SH: 0.0
- 000807.SZ: 0.0
- 002155.SZ: 0.0
- 600021.SH: 0.0
- 600642.SH: 0.0
- 000027.SZ: 0.0

## slow_provider_attempts
- symbol=00883.HK, provider=akshare, function_name=stock_hk_spot_em, elapsed_seconds=14.354, timeout_seconds=8.0, reason=provider_timeout
- symbol=00883.HK, provider=akshare, function_name=stock_hk_main_board_spot_em, elapsed_seconds=14.354, timeout_seconds=8.0, reason=provider_timeout
- symbol=00883.HK, provider=akshare, function_name=stock_hsgt_sh_hk_spot_em, elapsed_seconds=14.354, timeout_seconds=8.0, reason=provider_timeout

## provider_call_cache
- total_provider_calls: 3
- cache_hits: 0
- provider_call_count_by_function:
  - stock_hk_main_board_spot_em: 1
  - stock_hk_spot_em: 1
  - stock_hsgt_sh_hk_spot_em: 1

## Cache / Reuse Summary
- quote_cache_hit_count: 0
- quote_cache_miss_count: 41
- quote_cache_failure_hit_count: 0
- quote_cache_success_hit_count: 0
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 0
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 0
- cache_hit_by_layer: none
- cache_hit_by_provider: none

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 71
- provider_budget_account: energy
- provider_budget_run_id: 2026-06-04T11:10:49.446730+00:00
- provider_circuit_open: {'akshare': 'skipped_by_provider_circuit', 'eastmoney_direct': 'skipped_by_provider_circuit', 'mock': 'skipped_by_provider_circuit'}
- provider_budget_by_provider:
  - akshare: attempts=1, elapsed_seconds=14.354, slow_attempts=1, failed_attempts=1
  - eastmoney_direct: attempts=3, elapsed_seconds=0.043, slow_attempts=0, failed_attempts=3
  - mock: attempts=7, elapsed_seconds=0.024, slow_attempts=0, failed_attempts=3

## Price Reconciliation 摘要
- full report: price_reconciliation_report.md
- 601899.SH: compared_sources=eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 601985.SH: compared_sources=eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 003816.SZ: compared_sources=eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes

## Base Quote Fields Summary
| symbol | last | prev_close | open | high | low | volume | amount | change | change_pct | amplitude_pct | completeness | missing_fields | field_sources | exchange | country_market | trading_calendar |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|
| 00883.HK | 21.35 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | HK | HK | HK |
| 601899.SH | 18.42 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 601985.SH | 10.91 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 003816.SZ | 4.27 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 600938.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600900.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 601088.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600489.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600547.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 603993.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600188.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600795.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600028.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 601857.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 601225.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600011.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600027.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600905.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600886.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 000975.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 000630.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 000878.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 600362.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 601600.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 601808.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600583.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600256.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 002128.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 000983.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 600348.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 601001.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600985.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 000933.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 600988.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 603979.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600497.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 000807.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 002155.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 600021.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 600642.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 000027.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |

## Base Quote Field Sources
| symbol | last_source | prev_source | open_source | high_source | low_source | volume_source | amount_source | chg_source | completeness | missing_fields |
|---|---|---|---|---|---|---|---|---|---|---|
| 00883.HK | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 601899.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 601985.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 003816.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 600938.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600900.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601088.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600489.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600547.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603993.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600188.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600795.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600028.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601857.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601225.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600011.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600027.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600905.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600886.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000975.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000630.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000878.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600362.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601600.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601808.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600583.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600256.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002128.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000983.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600348.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601001.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600985.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000933.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600988.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603979.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600497.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000807.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002155.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600021.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600642.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000027.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |

## Provider Capability Summary
- full report: provider_capability_report.md
| provider | function_name | asset_type | base_price_fields | volume_amount_status | bid_ask_status | turnover_status | minute_status | operation_fit | notes |
|---|---|---|---|---|---|---|---|---|---|
| akshare | fund_etf_spot_em | ETF, QDII_ETF, A_SHARE_ETF | supported_or_calculable | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | Operation fit still depends on quote_trust_tier, strict, freshness, and provider health. |
| akshare | stock_spot_em | A_SHARE, HK_STOCK | mixed:missing,supported | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | A/H stock endpoint availability is environment-dependent. |
| akshare | fund_etf_hist_min_em | ETF, QDII_ETF, A_SHARE_ETF | missing | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | supported_if_endpoint_succeeds | diagnostic_only | ETF minute bars probe via AKShare; does not upgrade operation readiness. |
| eastmoney_direct | stock_get | ETF, A_SHARE_ETF, A_SHARE | mixed:calculable,supported_when_endpoint_succeeds | volume=supported_raw_unit; amount=supported_raw_unit | bid1=not_validated; ask1=not_validated | not_validated | attempted_provider_dependent | False | Reference / operation-candidate only; endpoint stability is not guaranteed. |
| yfinance | ticker_quote | ETF, HK_STOCK, A_SHARE, A_SHARE_ETF, INDEX | mixed:missing,provider_dependent,supported | volume=supported_raw_unit; amount=missing | bid1=missing_or_not_validated; ask1=missing_or_not_validated | missing | attempted_reference_fallback | reference_only | Open-source Yahoo Finance wrapper; not an official exchange feed. |
| manual | manual_price | MANUAL, GOLD | mixed:missing,supported | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | not_supported | conditional | Manual reference price; no market depth fields. |
| mock | mock_quote | TEST | mixed:missing,supported_for_tests | volume=supported_for_tests; amount=supported_for_tests | bid1=not_applicable; ask1=not_applicable | not_applicable | supported_for_tests | False | Development/testing only. |

### Current field quality risks
- raw_provider_unit records: 0
- unit_unknown records: 0
- volume_comparable_across_providers=false records: 41
- amount_comparable_across_providers=false records: 41
- bid/ask not validated; turnover_rate not validated; minute_bars/VWAP/QDII premium not implemented.

## Provider Capability Notes
AKShare:
- base quote fields: supported/partially supported through current normalized fields where provider raw fields are available.
- volume: raw provider unit.
- amount: raw provider unit or unit_unknown.
- bid/ask: not validated.
- turnover_rate: not validated.
- minute_bars: available through minute_probe when supported; reference-only and not operation-grade.

Eastmoney Direct:
- base quote fields: available only when endpoint succeeds.
- trust tier: reference / operation-candidate only.
- stability: unstable in current environment.
- bid/ask: not validated.
- minute_bars: available through minute_probe fallback when supported; reference-only and not operation-grade.

yfinance:
- base quote fields: reference-only for current ETF/watchlist usage.
- volume: raw provider unit.
- not operation-grade for A-share ETF operation path.
- timestamp/precision may differ from local exchange feeds.
- minute_bars: available as reference fallback through minute_probe when supported; provider_dependent and not operation-grade.

Capability label note:
- diagnostic_only in provider capability means capability label only; actual fallback behavior is controlled by minute_mode.

manual:
- GOLD_CNY price only.
- base_quote_completeness usually price_only.
- minute_bars: not supported.

mock:
- development/testing only.
- mock minute bars can be generated for tests when minute probe is enabled.
- not valid for real market decisions.

## Scan Ranking Trace
| symbol | rankable | exclusion_reason | data_quality_inputs | momentum_inputs | field_quality_inputs | liquidity_inputs | reconciliation_inputs | final_score | priority | notes |
|---|---|---|---|---|---|---|---|---:|---|---|
| 00883.HK | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 601899.SH | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement=provider_error | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 601985.SH | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement=provider_error | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 003816.SZ | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement=provider_error | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600938.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600900.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 601088.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600489.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600547.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 603993.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600188.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600795.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600028.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 601857.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 601225.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600011.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600027.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600905.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600886.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 000975.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 000630.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 000878.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600362.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 601600.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 601808.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600583.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600256.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 002128.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 000983.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600348.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 601001.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600985.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 000933.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600988.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 603979.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600497.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 000807.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 002155.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600021.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600642.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 000027.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |

## prices_snapshot 关键明细摘要
| symbol | name | selected_provider/source | quote_purpose | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | price | currency | quote_time | is_stale | stale_reason | required_for_operation | operation_blocking_reason | reference_note |
|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|
| 00883.HK | 中海油H | mock | reference | development | False | False | True | 21.35 | HKD | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 601899.SH | 紫金矿业A | mock | reference | development | False | False | True | 18.42 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 601985.SH | 中国核电 | mock | reference | development | False | False | True | 10.91 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 003816.SZ | 中国广核 | mock | reference | development | False | False | True | 4.27 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 600938.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600900.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 601088.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600489.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600547.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 603993.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600188.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600795.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600028.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 601857.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 601225.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600011.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600027.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600905.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600886.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 000975.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 000630.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 000878.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600362.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 601600.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 601808.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600583.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600256.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 002128.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 000983.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600348.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 601001.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600985.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 000933.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600988.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 603979.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600497.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 000807.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 002155.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600021.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600642.SH | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 000027.SZ | unknown | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |

## Blocking / Error 摘要
### Blocking records
- 无

### provider_error
- provider_error: energy 600938.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600900.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 601088.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600489.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600547.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 603993.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600188.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600795.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600028.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 601857.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 601225.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600011.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600027.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600905.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600886.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 000975.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 000630.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 000878.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600362.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 601600.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 601808.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600583.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600256.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 002128.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 000983.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600348.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 601001.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600985.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 000933.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600988.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 603979.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600497.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 000807.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 002155.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600021.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 600642.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: energy 000027.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

### quote_time_missing
- quote_time_missing: energy 600938.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600900.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601088.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600489.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600547.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 603993.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600188.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600795.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600028.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601857.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601225.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600011.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600027.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600905.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600886.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000975.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000630.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000878.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600362.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601600.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601808.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600583.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600256.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 002128.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000983.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600348.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 601001.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600985.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000933.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600988.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 603979.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600497.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000807.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 002155.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600021.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 600642.SH unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: energy 000027.SZ unknown: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

### invalid_price
- 无

### stale
- energy 00883.HK 中海油H: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 601899.SH 紫金矿业A: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 601985.SH 中国核电: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- energy 003816.SZ 中国广核: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

### mock fallback not usable
- mock_fallback_not_allowed: energy 00883.HK 中海油H: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: energy 601899.SH 紫金矿业A: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: energy 601985.SH 中国核电: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: energy 003816.SZ 中国广核: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

### reference-only but operation requested
- 无

本排障包只用于定位 provider、runtime、freshness 和 blocking 问题。
