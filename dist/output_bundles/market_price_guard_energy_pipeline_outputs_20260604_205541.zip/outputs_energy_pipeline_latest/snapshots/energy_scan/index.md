# market_price_guard 本轮刷新索引

## 基本信息
- generated_at: 2026-06-04T11:11:03.927104+00:00
- profile: energy
- provider_mode: live
- provider_policy: fast
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_energy_scan_latest
- quote_purpose: reference
- reconcile_mode: default
- universe_name: energy_scan
- universe_type: scan_universe

## 本轮结论
- 可用于具体操作建议：否
- 本轮为快速参考模式。
- 可用于快速参考：是
- 不可用于具体操作建议。
- 如需具体执行动作或盘中价位，必须运行 operation-grade / strict 输出。

## Blocking Records 摘要
- 无

## 核心价格覆盖摘要
- 能源账户核心价格：本轮未刷新
- 科技账户核心价格：本轮未刷新
- 黄金参考价：本轮未刷新
- 非科技宽基：本轮未刷新

## Quote trust summary
- current quote_purpose: reference
- operation-grade records 数量: 0
- reference-grade records 数量: 0
- development-grade records 数量: 41
- confirmation_required 数量: 41
- 可用于快速参考: 否
- 可用于具体操作建议: 否

## Reconciliation summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=3
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 运行时效摘要
- total_elapsed_seconds: 14.48
- max_quote_lag_seconds: 1319163.927
- run_time_budget_exceeded: False
- slow_provider_attempts 数量: 3
- provider calls: 3
- cache hits: 0
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-20T12:45:00+08:00

## Provider 摘要
- mock: 41
- fallback_used 数量: 4
- mock fallback not usable 数量: 4

## 推荐复制给项目的文件
- 0_upload_bundle.md
- debug_bundle.md if blocking/provider_error/stale/quote_time_missing/major_diff/runtime issues appear

## 报告入口
- data_completeness_report.md
- provider_health_report.md
- runtime_diagnostics.md

本索引只汇总数据状态、可用性、阻断原因和建议查看的报告文件。
