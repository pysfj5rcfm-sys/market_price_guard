# Runtime Diagnostics

- run_start_time_utc: 2026-06-04T11:10:49.446730+00:00
- run_end_time_utc: 2026-06-04T11:11:03.927104+00:00
- total_elapsed_seconds: 14.48
- profile: energy
- provider_mode: live
- provider_policy: fast
- strict: False
- quote_purpose: reference
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: disabled_in_fast_mode
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: 
- provider_timeout_count: 4
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 3
- provider_runtime_budget_summary: akshare:attempts=1,elapsed=14.354,slow=1,failed=1; eastmoney_direct:attempts=3,elapsed=0.043,slow=0,failed=3; mock:attempts=7,elapsed=0.024,slow=0,failed=3
- quote_cache_hit_count: 0
- quote_cache_miss_count: 41
- quote_cache_failure_hit_count: 0
- quote_cache_success_hit_count: 0
- repeated_provider_call_prevented_count: 0
- universe_name: energy_scan
- universe_type: scan_universe
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319163.927
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-20T12:45:00+08:00

## Provider Runtime Summary
- account: energy
- layer: energy_scan
- total_elapsed_seconds: 14.48
- run_time_budget_exceeded: False
- slow_provider_attempts: 3
- provider_timeout_count: 6
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 74

## per_provider_elapsed_seconds
- akshare: 43.062
- mock: 0.024
- eastmoney_direct: 0.043
- yfinance: 0.0

## Config Source / Layer Manifest
- layer_name: energy_scan
- config_source_path: config/universes/energy_scan.yaml
- config_source_hash_sha256: b55884e1846c
- configured_symbol_count: 41
- loaded_symbol_count: 41
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 00883.HK: 43.071
- 601899.SH: 0.026
- 601985.SH: 0.015
- 003816.SZ: 0.011
- 600938.SH: 0.002
- 600900.SH: 0.002
- 601088.SH: 0.002
- 600489.SH: 0.0
- 600547.SH: 0.0
- 603993.SH: 0.0
- 600188.SH: 0.0
- 600795.SH: 0.0
- 600028.SH: 0.0
- 601857.SH: 0.0
- 601225.SH: 0.0
- 600011.SH: 0.0
- 600027.SH: 0.0
- 600905.SH: 0.0
- 600886.SH: 0.0
- 000975.SZ: 0.0
- 000630.SZ: 0.0
- 000878.SZ: 0.0
- 600362.SH: 0.0
- 601600.SH: 0.0
- 601808.SH: 0.0
- 600583.SH: 0.0
- 600256.SH: 0.0
- 002128.SZ: 0.0
- 000983.SZ: 0.0
- 600348.SH: 0.0
- 601001.SH: 0.0
- 600985.SH: 0.0
- 000933.SZ: 0.0
- 600988.SH: 0.0
- 603979.SH: 0.0
- 600497.SH: 0.0
- 000807.SZ: 0.0
- 002155.SZ: 0.0
- 600021.SH: 0.0
- 600642.SH: 0.0
- 000027.SZ: 0.0

## slow_provider_attempts
- symbol=00883.HK, provider=akshare, function_name=stock_hk_spot_em, elapsed_seconds=14.354, timeout_seconds=8.0, reason=provider_timeout
- symbol=00883.HK, provider=akshare, function_name=stock_hk_main_board_spot_em, elapsed_seconds=14.354, timeout_seconds=8.0, reason=provider_timeout
- symbol=00883.HK, provider=akshare, function_name=stock_hsgt_sh_hk_spot_em, elapsed_seconds=14.354, timeout_seconds=8.0, reason=provider_timeout

## provider_call_cache
- total_provider_calls: 3
- cache_hits: 0
- provider_call_count_by_function:
  - stock_hk_main_board_spot_em: 1
  - stock_hk_spot_em: 1
  - stock_hsgt_sh_hk_spot_em: 1

## Cache / Reuse Summary
- quote_cache_hit_count: 0
- quote_cache_miss_count: 41
- quote_cache_failure_hit_count: 0
- quote_cache_success_hit_count: 0
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 0
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 0
- cache_hit_by_layer: none
- cache_hit_by_provider: none

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 71
- provider_budget_account: energy
- provider_budget_run_id: 2026-06-04T11:10:49.446730+00:00
- provider_circuit_open: {'akshare': 'skipped_by_provider_circuit', 'eastmoney_direct': 'skipped_by_provider_circuit', 'mock': 'skipped_by_provider_circuit'}
- provider_budget_by_provider:
  - akshare: attempts=1, elapsed_seconds=14.354, slow_attempts=1, failed_attempts=1
  - eastmoney_direct: attempts=3, elapsed_seconds=0.043, slow_attempts=0, failed_attempts=3
  - mock: attempts=7, elapsed_seconds=0.024, slow_attempts=0, failed_attempts=3
