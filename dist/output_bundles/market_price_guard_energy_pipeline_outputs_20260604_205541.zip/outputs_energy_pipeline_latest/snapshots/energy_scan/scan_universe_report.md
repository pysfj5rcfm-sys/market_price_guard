# Scan Universe Report

Scan universe records are for opportunity observation and data completeness checks only. They do not affect core operation strict.

- universe_name: energy_scan
- universe_type: scan_universe
- scan_mode: fast
- stock_fast_path_enabled: true
- stock_fast_provider: eastmoney_direct
- data_status: price_change_pct/amount/volume may be missing in this version.

- scan_mode: fast
- stock_fast_path_enabled: true
- stock_fast_provider: eastmoney_direct
- yfinance_fallback_policy: disabled_in_fast_mode
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- eastmoney_direct_stock_attempted_count: 40
- eastmoney_direct_stock_success_count: 0
- eastmoney_direct_stock_error_count: 40
- stock_reference_coverage_count: 0
- stock_reference_missing_count: 41
- provider_timeout_count: 4
- fallback_skipped_fast_mode_count: 40
- slow_symbol_count: 0
- run_time_budget_exceeded: False

| symbol | name | role | report_group | price | source | quote_time | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | source_agreement_status | data_status | note |
|---|---|---|---|---:|---|---|---|---|---|---|---|---|---|
| 00883.HK | 中海油H | energy_core_equity | 能源账户核心价格 | 21.35 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True |  | check_required |  |
| 601899.SH | 紫金矿业A | energy_core_equity | 能源账户核心价格 | 18.42 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 601985.SH | 中国核电 | energy_core_equity | 能源账户核心价格 | 10.91 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 003816.SZ | 中国广核 | energy_core_equity | 能源账户核心价格 | 4.27 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required |  |
| 600938.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600900.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 601088.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600489.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600547.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 603993.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600188.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600795.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy operation_candidate/watchlist/scan pool symbol; not a default candidate list item |
| 600028.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601857.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601225.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600011.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600027.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600905.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600886.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000975.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000630.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 000878.SZ | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 600362.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601600.SH | unknown | energy_layer_pool_equity | 能源账户关注池 |  | mock |  | development | False | False | True |  | check_required | energy watchlist/scan pool symbol; not a trading candidate by default |
| 601808.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 600583.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 600256.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 002128.SZ | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 000983.SZ | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 600348.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 601001.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 600985.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 000933.SZ | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 600988.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 603979.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 600497.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 000807.SZ | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 002155.SZ | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 600021.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 600642.SH | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |
| 000027.SZ | unknown | energy_scan_equity | 能源账户扫描池 |  | mock |  | development | False | False | True |  | check_required | energy scan pool symbol; not a trading candidate by default |

# Scan Universe Basic Ranking
- This is a review-priority ranking, not operation guidance.
- It does not produce execution instructions.
- Operation decisions require operation-grade price guard output.
- volume/amount are not used for cross-provider liquidity ranking unless comparable flags allow it.

## Scan Summary
- total_symbols: 41
- rankable_count: 0
- not_rankable_count: 41
- high_priority_count: 0
- medium_priority_count: 0
- low_priority_count: 0
- symbol_not_found_count: 0
- provider_issue_count: 37
- data_insufficient_count: 0
- exclusion reasons: development_only:4, provider_error:37
- ranking does not affect strict.

## Basic Ranking Table
| rank | symbol | name | tags | score | priority | last | chg% | base | data_quality | momentum | field_quality | liquidity | reconciliation | provider | status | note |
|---:|---|---|---|---:|---|---:|---:|---|---:|---:|---:|---:|---:|---|---|---|
|  |  |  |  |  | not_rankable |  |  | missing |  |  |  |  |  |  | not_rankable | no rankable records |

## Not Rankable
| symbol | name | reason | provider_status | suggested_next_step |
|---|---|---|---|---|
| 00883.HK | 中海油H | development_only | success | keep as candidate; does not affect core strict |
| 601899.SH | 紫金矿业A | development_only | success | keep as candidate; does not affect core strict |
| 601985.SH | 中国核电 | development_only | success | keep as candidate; does not affect core strict |
| 003816.SZ | 中国广核 | development_only | success | keep as candidate; does not affect core strict |
| 600938.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600900.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 601088.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600489.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600547.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 603993.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600188.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600795.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600028.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 601857.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 601225.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600011.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600027.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600905.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600886.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 000975.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 000630.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 000878.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600362.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 601600.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 601808.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600583.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600256.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 002128.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 000983.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600348.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 601001.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600985.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 000933.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600988.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 603979.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600497.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 000807.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 002155.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600021.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600642.SH | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 000027.SZ | unknown | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |

## Compact Base Quote Table
| symbol | name | tags | last | chg% | amount | base | data_status | provider | note |
|---|---|---|---:|---:|---:|---|---|---|---|
| 00883.HK | 中海油H | energy, hk, core | 21.35 | — | — | price_only | price_only | mock | scan_only |
| 601899.SH | 紫金矿业A | energy, a_share, core | 18.42 | — | — | price_only | price_only | mock | scan_only |
| 601985.SH | 中国核电 | energy, nuclear, a_share, core | 10.91 | — | — | price_only | price_only | mock | scan_only |
| 003816.SZ | 中国广核 | energy, nuclear, a_share, core | 4.27 | — | — | price_only | price_only | mock | scan_only |
| 600938.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600900.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 601088.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600489.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600547.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 603993.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600188.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600795.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600028.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 601857.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 601225.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600011.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600027.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600905.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600886.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 000975.SZ | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 000630.SZ | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 000878.SZ | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 600362.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 601600.SH | unknown | energy, a_share, layer_pool | — | — | — | missing | provider_error | mock | provider_error |
| 601808.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 600583.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 600256.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 002128.SZ | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 000983.SZ | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 600348.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 601001.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 600985.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 000933.SZ | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 600988.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 603979.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 600497.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 000807.SZ | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 002155.SZ | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 600021.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 600642.SH | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |
| 000027.SZ | unknown | energy, a_share, scan | — | — | — | missing | provider_error | mock | provider_error |

## Base Quote Summary
- base_quote_completeness counts:
- missing: 37
- price_only: 4
- missing fields top: amount:41, high_price:41, low_price:41, open_price:41, prev_close:41, volume:41, last_price:37
- base quote fields are auxiliary diagnostics; missing fields do not change existing strict in this version.

| symbol | base_quote_completeness | available | missing | missing_fields |
|---|---|---:|---:|---|
| 00883.HK | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 601899.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 601985.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 003816.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 600938.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600900.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601088.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600489.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600547.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603993.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600188.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600795.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600028.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601857.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601225.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600011.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600027.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600905.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600886.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000975.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000630.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000878.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600362.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601600.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601808.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600583.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600256.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002128.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000983.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600348.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 601001.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600985.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000933.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600988.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603979.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600497.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000807.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002155.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600021.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600642.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 000027.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |

## Provider Coverage / Failure Reasons
| symbol | registry_found | provider_attempted | provider_status | data_status | likely_reason | suggested_next_step |
|---|---|---|---|---|---|---|
| 00883.HK | True | akshare,mock | success | price_only | provider_timeout | keep as candidate; does not affect core strict |
| 601899.SH | True | eastmoney_direct,mock | success | price_only | provider_timeout | keep as candidate; does not affect core strict |
| 601985.SH | True | eastmoney_direct,mock | success | price_only | provider_timeout | keep as candidate; does not affect core strict |
| 003816.SZ | True | eastmoney_direct,mock | success | price_only | provider_timeout | keep as candidate; does not affect core strict |
| 600938.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600900.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601088.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600489.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600547.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 603993.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600188.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600795.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600028.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601857.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601225.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600011.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600027.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600905.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600886.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000975.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000630.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000878.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600362.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601600.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601808.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600583.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600256.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002128.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000983.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600348.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 601001.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600985.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000933.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600988.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 603979.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600497.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000807.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002155.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600021.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600642.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 000027.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |

## Safety Notes

- Scan ranking is not operation guidance.
- Reference-only does not mean operation-ready.
- Operation decisions require operation-grade guard output.
- Candidate/watchlist/scan records do not affect core strict.
- volume/amount unit normalization is not complete.
- minute bars / VWAP / QDII premium are not implemented.
