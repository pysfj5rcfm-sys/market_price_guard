# Energy Research Pipeline Summary

- generated_at: 2026-06-04T11:10:49.2142520Z
- pipeline_run_id: 20e98e48-5400-407f-8c5d-c52aeff16d87
- source_run_id: 20e98e48-5400-407f-8c5d-c52aeff16d87
- account: energy
- pipeline_name: energy_research_pipeline
- version: v0.7.5
- scan_mode: fast
- total_steps: 4
- passed: 3
- strict_blocked_but_reported: 1
- failed: 0
- runtime_warnings: 1
- skipped_steps: 0
- total_elapsed_seconds: 25.968
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- no minute_probe
- no intraday_metrics
- no VWAP
- no trading advice

## Steps

| step | status | exit_code | elapsed_seconds | runtime_warning_level | output_dir | snapshot_dir | generated_at | source_run_id | layer_manifest_hash | prices_snapshot_hash | upload_bundle_hash |
|---|---|---:|---:|---|---|---|---|---|---|---|---|
| energy_scan | passed | 0 | 14.829 | provider_circuit_open | outputs_energy_scan_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_scan | 2026-06-04T11:11:04.0484750Z | 20e98e48-5400-407f-8c5d-c52aeff16d87 | 6be2cba54cd4367af4d356ef45010447c7516a958958a9aca4f7e6f12660aac0 | 1f16a5cfb59bbc96a9324e46e79d9e0e108e828f3a28c9c8161cd5cc0d5729dc | 11c83101b6881421bb3298a466292e079b29c8dece4c24cd1eab9ee63fbfeeec |
| energy_watchlist | passed | 0 | 0.442 | runtime_info | outputs_energy_watchlist_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_watchlist | 2026-06-04T11:11:04.5304640Z | 20e98e48-5400-407f-8c5d-c52aeff16d87 | 0014688e659f3a93d428fc1f7d49af97a139da1851af9fb3ad3b313bf92504eb | 82e2257bbb312d7dc3976109049d8538fb73102baa17640a3adde3d7c9ef83d8 | e0d4d8ebf4a4a44d522095c1be6b18121a6238fdbb8d98e1f774b4fbacac097d |
| energy_operation_candidates | passed | 0 | 0.354 | runtime_info | outputs_energy_operation_candidates_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_operation_candidates | 2026-06-04T11:11:04.8952550Z | 20e98e48-5400-407f-8c5d-c52aeff16d87 | e0ac28225fd5732b4479e4e91be8600d0046203817619f720feb1788a79e869c | bbb353a018f71a5cc51c67805cf6bcf04893c7b02ab3a8456f0059bd49308270 | b300f39b3ffdef59cc4fb3b565c52d7d47c67b6d93f78d227f4a4d3db958c865 |
| energy_fast_strict | strict_blocked_but_reported | 2 | 10.277 | strict_blocked_but_reported | outputs_energy_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_fast_strict | 2026-06-04T11:11:15.1782050Z | 20e98e48-5400-407f-8c5d-c52aeff16d87 | 40ed5c89aabb38b9ab76a8aebaa5d4e83eaacf32a47f1ee38f7ea9e59b8d6988 | aef8e1f43eed6ffac538e4ce9d71eac025057f81e3d033f4f99e967d40f4c43a | c0a9d8518c1c3b84cab103d7d32fb83f935b5a1a4e860fa8b5d6bcd82bda4a66 |

## Pipeline Output Snapshots

- snapshots_root: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots
- snapshots are copied during this pipeline run and are not affected by later standalone layer runs.

| step_name | account | output_dir | snapshot_dir | snapshot_metadata | layer_manifest_path | manifest_hash | source_run_id |
|---|---|---|---|---|---|---|---|
| energy_scan | energy | outputs_energy_scan_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_scan | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_scan/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_scan/layer_manifest.json | 6be2cba54cd4367af4d356ef45010447c7516a958958a9aca4f7e6f12660aac0 | 20e98e48-5400-407f-8c5d-c52aeff16d87 |
| energy_watchlist | energy | outputs_energy_watchlist_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_watchlist | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_watchlist/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_watchlist/layer_manifest.json | 0014688e659f3a93d428fc1f7d49af97a139da1851af9fb3ad3b313bf92504eb | 20e98e48-5400-407f-8c5d-c52aeff16d87 |
| energy_operation_candidates | energy | outputs_energy_operation_candidates_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_operation_candidates | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_operation_candidates/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_operation_candidates/layer_manifest.json | e0ac28225fd5732b4479e4e91be8600d0046203817619f720feb1788a79e869c | 20e98e48-5400-407f-8c5d-c52aeff16d87 |
| energy_fast_strict | energy | outputs_energy_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_fast_strict | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_fast_strict/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots/energy_fast_strict/layer_manifest.json | 40ed5c89aabb38b9ab76a8aebaa5d4e83eaacf32a47f1ee38f7ea9e59b8d6988 | 20e98e48-5400-407f-8c5d-c52aeff16d87 |

## Layer Config Summary

| layer | configured | loaded | mismatch |
|---|---:|---:|---|
| energy_scan | 41 | 41 | false |
| energy_watchlist | 24 | 24 | false |
| energy_operation_candidates | 8 | 8 | false |
| energy_core | 4 | 4 | false |

## Data Completeness Summary

| layer | total | success | failed | provider_missing | unsupported | stale | usable_reference | usable_operation |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| energy_scan | 41 | 4 | 37 | 0 | 0 | 41 | 0 | 0 |
| energy_watchlist | 24 | 4 | 20 | 0 | 0 | 24 | 0 | 0 |
| energy_operation_candidates | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 |
| energy_fast_strict | 4 | 4 | 0 | 0 | 0 | 4 | 0 | 0 |

## Cache / Reuse Summary

- quote_cache_hit_count: 32
- quote_cache_miss_count: 45
- quote_cache_failure_hit_count: 28
- quote_cache_success_hit_count: 4
- batch_cache_hit_count: see step runtime_diagnostics.md
- batch_cache_miss_count: see step runtime_diagnostics.md
- repeated_provider_call_prevented_count: 32
- repeated_batch_call_prevented_count: see step runtime_diagnostics.md
- cache_hit_by_layer: see step runtime_diagnostics.md
- cache_hit_by_provider: see step runtime_diagnostics.md

## Runtime Diagnostics Summary

| step | runtime_warning | max_run_seconds |
|---|---|---:|
| energy_scan | false | 30.0 |
| energy_watchlist | false | 30.0 |
| energy_operation_candidates | false | 30.0 |
| energy_fast_strict | false | 30.0 |

## Runtime Budget Summary

| step | runtime_warning_level | runtime_warning_reason | run_time_budget_exceeded | provider_timeout_count | skipped_by_runtime_budget | circuit_open_count |
|---|---|---|---|---:|---:|---:|
| energy_scan | provider_circuit_open | provider_circuit_open_reported | false | 4 | 0 | 74 |
| energy_watchlist | runtime_info | within_runtime_policy | false | 0 | 0 | 0 |
| energy_operation_candidates | runtime_info | within_runtime_policy | false | 0 | 0 | 0 |
| energy_fast_strict | strict_blocked_but_reported | strict_blocked_with_reports | false | 3 | 4 | 4 |

## Provider Health Summary

| step | provider_health_report | planned_actual_summary |
|---|---|---|
| energy_scan | true | available |
| energy_watchlist | true | available |
| energy_operation_candidates | true | available |
| energy_fast_strict | true | available |

## Safety Statements

- operation_candidate is not an execution list.
- watchlist is not an execution layer.
- scan is not a trading signal.
- no trading advice is generated.
- scan, watchlist, and operation_candidate results are not promoted automatically.
