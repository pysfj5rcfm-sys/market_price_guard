# Energy Research Pipeline Upload Manifest

## Core State
- outputs_energy_latest/0_upload_bundle.md

## Research Chain
- outputs_energy_pipeline_latest/pipeline_summary.md
- outputs_energy_scan_latest/0_upload_bundle.md
- outputs_energy_watchlist_latest/0_upload_bundle.md
- outputs_energy_operation_candidates_latest/0_upload_bundle.md
- outputs_energy_latest/0_upload_bundle.md

## Notes
- Data and configuration status only.
- No minute_probe, no intraday_metrics, no VWAP, no trading advice.
