# market_price_guard 上传包

## 基本信息
- generated_at: 2026-06-04T11:11:04.811787+00:00
- profile: energy
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_energy_operation_candidates_latest
- universe_name: energy_operation_candidates
- universe_type: operation_candidate
- core_count: 0
- watchlist_count: 0
- scan_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: energy_operation_candidates
- config_source_path: config/universes/energy_operation_candidates.yaml
- config_source_hash_sha256: 0dc617cb3b8a
- configured_symbol_count: 8
- loaded_symbol_count: 8
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## 本轮结论
- 可用于快速参考：否
- 可用于具体操作建议：否
- 当前用途级别：reference-only
- confirmation_required 数量: 8
- blocking records 数量: 0

## 数据完整度摘要
- strict/exit_code: 0
- provider_error 数量: 8
- stale 数量: 0
- quote_time_missing 数量: 8
- invalid_price 数量: 8
- mock fallback not usable 数量: 0
- run_time_budget_exceeded: False

### Blocking records 摘要
- 无

## Quote Trust Tier 摘要
- operation-grade records 数量: 0
- reference-grade records 数量: 0
- development-grade records 数量: 8
- usable_for_reference=true 数量: 0
- usable_for_operation=true 数量: 0
- confirmation_required=true 数量: 8

## 基础行情快照 / Base Quote Snapshot
| symbol | name | last | chg% | open | high | low | prev | volume | amount | base | provider | tier | op? | stale? |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|
| 600938.SH | unknown | — | — | — | — | — | — | — | — | missing | mock | development | False | True |
| 600900.SH | unknown | — | — | — | — | — | — | — | — | missing | mock | development | False | True |
| 601088.SH | unknown | — | — | — | — | — | — | — | — | missing | mock | development | False | True |
| 600489.SH | unknown | — | — | — | — | — | — | — | — | missing | mock | development | False | True |
| 600547.SH | unknown | — | — | — | — | — | — | — | — | missing | mock | development | False | True |
| 603993.SH | unknown | — | — | — | — | — | — | — | — | missing | mock | development | False | True |
| 600188.SH | unknown | — | — | — | — | — | — | — | — | missing | mock | development | False | True |
| 600795.SH | unknown | — | — | — | — | — | — | — | — | missing | mock | development | False | True |
- base_quote_completeness is shown in the compact `base` column.

- volume/amount follow provider raw units unless unit normalization is explicitly available.
- 成交量/成交额暂按 provider 原始单位展示；未统一单位前不得直接跨 provider 排名。

## 字段质量提示 / Field Quality Notes
- volume/amount are shown in provider raw units unless explicitly validated.
- cross-provider volume/amount comparison is unsafe in this version.
- bid/ask, turnover_rate, minute_bars, VWAP and QDII premium are not validated or not implemented.
- See debug_bundle.md and provider_capability_report.md for details.

## Operation Candidate Summary
- universe_name: energy_operation_candidates
- universe_type: operation_candidate
- total_candidates: 8
- ready_for_review: 0
- data_incomplete: 0
- provider_error: 8
- symbol_not_found: 0
- registry_missing: 0
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations.

## Reconciliation Summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=0
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 项目核心内容
### Operation candidates

These are pre-trade verification candidates, not core holdings and not operation-grade.
They do not affect energy_fast_strict or outputs_energy_latest.
This output is not operation guidance.

- universe_name: energy_operation_candidates
- universe_type: operation_candidate
- quote_purpose: reference
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations

## Operation Candidate Summary
- universe_name: energy_operation_candidates
- universe_type: operation_candidate
- total_candidates: 8
- ready_for_review: 0
- data_incomplete: 0
- provider_error: 8
- symbol_not_found: 0
- registry_missing: 0
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations.

## Candidate Data Status
| symbol | name | operation_candidate | candidate_quote_ready | candidate_data_status | candidate_blocking_reason | candidate_next_step | required_for_operation | affect_core_strict | usable_for_operation | usable_for_reference | provider | rankable | rank_exclusion_reason |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 600938.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600900.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 601088.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600489.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600547.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 603993.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600188.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600795.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |

## Safety Notes
- Operation candidates are reference-only pre-check records.
- A candidate must be explicitly promoted to core holdings before it can be part of the tech fast strict path.
- Candidate provider failures do not block core operation.
- No operation guidance is generated.

## Universe isolation
- universe_name: energy_operation_candidates
- universe_type: operation_candidate
- core strict pollution isolation: enabled
- this universe is not used for core operation strict blocking.
- not usable for concrete operation recommendations.

## Reference / Operation 使用提示
- 本轮为快速参考模式。
- 可以用于快速参考。
- 不可用于具体操作建议。
- 不可给出具体执行动作、盘中高频判断或执行参数参数。
- 如需具体操作，请运行 operation 输出或补充有效盘口信息。

## Debug 提示
- 如出现 strict=2、blocking records、provider_error、quote_time_missing、invalid_price、stale、selected_provider=mock、fallback_used 异常、run_time_budget_exceeded、slow_provider_attempts、quote_time 可疑或报告冲突，请补充 debug_bundle.md。
- 本上传包只汇总数据状态、可用性和阻断原因。
