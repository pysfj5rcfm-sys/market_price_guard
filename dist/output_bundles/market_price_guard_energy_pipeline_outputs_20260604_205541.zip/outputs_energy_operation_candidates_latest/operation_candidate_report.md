# Energy Operation Candidate Report

These are pre-trade verification candidates, not core holdings and not operation-grade.
They do not affect energy_fast_strict or outputs_energy_latest.
This output is not operation guidance.

- universe_name: energy_operation_candidates
- universe_type: operation_candidate
- quote_purpose: reference
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations

## Operation Candidate Summary
- universe_name: energy_operation_candidates
- universe_type: operation_candidate
- total_candidates: 8
- ready_for_review: 0
- data_incomplete: 0
- provider_error: 8
- symbol_not_found: 0
- registry_missing: 0
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations.

## Candidate Data Status
| symbol | name | operation_candidate | candidate_quote_ready | candidate_data_status | candidate_blocking_reason | candidate_next_step | required_for_operation | affect_core_strict | usable_for_operation | usable_for_reference | provider | rankable | rank_exclusion_reason |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 600938.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600900.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 601088.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600489.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600547.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 603993.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600188.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600795.SH | unknown | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |

## Safety Notes
- Operation candidates are reference-only pre-check records.
- A candidate must be explicitly promoted to core holdings before it can be part of the tech fast strict path.
- Candidate provider failures do not block core operation.
- No operation guidance is generated.
