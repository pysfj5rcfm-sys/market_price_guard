# Acceptance Summary

- version: v0.7.5.3
- generated_at: 2026-06-04T11:09:42.1739370Z
- scope_classification: account-generic runtime/UAT acceptance polish

## Baselines

- tech: operation=7, operation_candidate=19, watchlist=28, scan=40
- energy: operation=4, operation_candidate=8, watchlist=24, scan=41

## Tech Pipeline

- passed: false
- failed_count: 1
- strict_blocked_but_reported_count: 0
- runtime_warnings: 0
- snapshot_path: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots
- pipeline_summary_path: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/pipeline_summary.md

## Energy Pipeline

- passed: false
- failed_count: 1
- strict_blocked_but_reported_count: 0
- runtime_warnings: 0
- snapshot_path: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/snapshots
- pipeline_summary_path: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_energy_pipeline_latest/pipeline_summary.md

## UAT

- quick: status=failed; summary_md=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_uat_latest/quick/outputs_uat_summary.md; timeout_seconds=; soft_budget_seconds=; hard_timeout_seconds=
- intraday: status=failed; summary_md=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_uat_latest/intraday/outputs_uat_summary.md; timeout_seconds=; soft_budget_seconds=; hard_timeout_seconds=
- energy: status=failed; summary_md=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_uat_latest/energy/outputs_uat_summary.md; timeout_seconds=; soft_budget_seconds=; hard_timeout_seconds=

## Config Diff

- expected: empty
- status: empty

## No Advice Scan

- status: passed
- hit_count: 0

## Unresolved Backlog

- tech scan_ai / minute_probe may exceed soft runtime budget
- energy operation provider coverage still weak
- QDII premium not implemented
- energy commodity reference not implemented
