# Runtime Diagnostics

- run_start_time_utc: 2026-06-04T11:10:16.193927+00:00
- run_end_time_utc: 2026-06-04T11:10:21.124874+00:00
- total_elapsed_seconds: 4.931
- profile: tech
- provider_mode: live
- provider_policy: fast
- strict: True
- quote_purpose: operation
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: 
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 0
- provider_runtime_budget_summary: akshare:attempts=3,elapsed=4.825,slow=0,failed=3; manual:attempts=1,elapsed=0.001,slow=0,failed=0; mock:attempts=6,elapsed=0.027,slow=0,failed=0
- quote_cache_hit_count: 47
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 39
- quote_cache_success_hit_count: 8
- repeated_provider_call_prevented_count: 47
- universe_name: 
- universe_type: 
- layer_config_mismatch: True
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319121.125
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-22T14:38:00+08:00

## Provider Runtime Summary
- account: tech
- layer: tech
- total_elapsed_seconds: 4.931
- run_time_budget_exceeded: False
- slow_provider_attempts: 0
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 4

## per_provider_elapsed_seconds
- akshare: 4.825
- mock: 0.027
- manual: 0.001
- yfinance: 0.0

## Config Source / Layer Manifest
- CONFIG_MISMATCH: true
- layer_name: tech_core
- config_source_path: config/universes/tech_core.yaml
- config_source_hash_sha256: 887257ec5e18
- configured_symbol_count: 8
- loaded_symbol_count: 7
- config_mismatch: true
- missing_from_loaded: 159995.SZ
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 159632.SZ: 4.831
- 513300.SH: 0.008
- 159819.SZ: 0.004
- 515880.SH: 0.003
- 159516.SZ: 0.003
- 510300.SH: 0.003
- GOLD_CNY: 0.001

## slow_provider_attempts
- 无

## provider_call_cache
- total_provider_calls: 1
- cache_hits: 2
- provider_call_count_by_function:
  - fund_etf_spot_em: 1

## Cache / Reuse Summary
- quote_cache_hit_count: 47
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 39
- quote_cache_success_hit_count: 8
- batch_cache_hit_count: 2
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 2
- batch_provider_failure_cached_count: 3
- repeated_provider_call_prevented_count: 47
- repeated_batch_call_prevented_count: 2
- quote_cache_profile_insufficient_count: 7
- cache_hit_by_layer: none
- cache_hit_by_provider: none

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 3
- provider_budget_account: tech
- provider_budget_run_id: 2026-06-04T11:10:16.193927+00:00
- provider_circuit_open: {'akshare': 'skipped_by_provider_circuit'}
- provider_budget_by_provider:
  - akshare: attempts=3, elapsed_seconds=4.825, slow_attempts=0, failed_attempts=3
  - manual: attempts=1, elapsed_seconds=0.001, slow_attempts=0, failed_attempts=0
  - mock: attempts=6, elapsed_seconds=0.027, slow_attempts=0, failed_attempts=0
