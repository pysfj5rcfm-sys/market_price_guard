# market_price_guard 排障包

## 基本信息
- generated_at: 2026-06-04T11:10:21.124874+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: operation
- reconcile_mode: default
- strict: true
- exit_code: 2
- output_dir: outputs_tech_latest
- universe_name: 
- universe_type: 

## Symbol Registry Resolution 摘要
- registry_enabled: false

## Config Source / Layer Manifest
- CONFIG_MISMATCH: true
- layer_name: tech_core
- config_source_path: config/universes/tech_core.yaml
- config_source_hash_sha256: 887257ec5e18
- configured_symbol_count: 8
- loaded_symbol_count: 7
- config_mismatch: true
- missing_from_loaded: 159995.SZ
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Provider Health 摘要
- provider_policy: fast
- provider_mode: live
- function_name=akshare, call_count=0, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=, failed=True, exception_type=, exception_message=
- function_name=fund_etf_spot_em, call_count=1, cache_hits=2, uat_run_cache_hits=0, cache_statuses=miss_failure_cached, returned_rows=, matched_symbols=, elapsed_seconds_first_call=4.717, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))

### Provider attempts
### 159632.SZ
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: akshare, mock
- provider_skip_reasons: none
- normalized_symbol: 159632.SZ
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: a_share_provider_error
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=fund_etf_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=True, cache_scope=uat_run, cache_status=miss_failure_cached, cache_file=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_cache_latest/akshare_fund_etf_spot_em.failure.json, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=4.825, slow_provider_attempt=False, reason=provider_error, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=1.432, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.006, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 513300.SH
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: akshare, mock
- provider_skip_reasons: none
- normalized_symbol: 513300.SH
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: a_share_provider_error
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=fund_etf_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=True, cache_enabled=True, cache_scope=uat_run, cache_status=miss_failure_cached, cache_file=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_cache_latest/akshare_fund_etf_spot_em.failure.json, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_error, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=1.671, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.008, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 159819.SZ
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: akshare, mock
- provider_skip_reasons: none
- normalized_symbol: 159819.SZ
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: a_share_provider_error
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=fund_etf_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=True, cache_enabled=True, cache_scope=uat_run, cache_status=miss_failure_cached, cache_file=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_cache_latest/akshare_fund_etf_spot_em.failure.json, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_error, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=0.921, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.004, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 515880.SH
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: mock
- provider_skip_reasons: akshare=skipped_by_provider_circuit
- normalized_symbol: 515880.SH
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=1.084, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 159516.SZ
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: mock
- provider_skip_reasons: akshare=skipped_by_provider_circuit
- normalized_symbol: 159516.SZ
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=0.756, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 510300.SH
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: mock
- provider_skip_reasons: akshare=skipped_by_provider_circuit
- normalized_symbol: 510300.SH
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=3.921, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### GOLD_CNY
- provider_policy: fast
- configured_provider_priority: manual
- provider_planned_chain: manual
- effective_provider_chain: manual
- actual_provider_attempted: manual
- provider_skip_reasons: none
- normalized_symbol: GOLD_CNY
- route_reason: manual_reference_required
- selected_provider: manual
- selected_source: manual
- fallback_used: False
- usable_for_operation: True
- quote_trust_tier: operation
- usable_for_reference: True
- confirmation_required: False
- selection_reason: selected_provider_returned_usable_price
- final_blocking_reason: stale
- provider_failure_reason: reference_available
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=manual, function_name=manual, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=992.12, quote_time=2026-05-22T14:38:00+08:00, usable_for_operation=True, quote_trust_tier=operation, usable_for_reference=True, confirmation_required=False, elapsed_seconds=0.001, slow_provider_attempt=False, reason=, exception_type=, exception_message=

## Runtime Diagnostics 摘要
- run_start_time_utc: 2026-06-04T11:10:16.193927+00:00
- run_end_time_utc: 2026-06-04T11:10:21.124874+00:00
- total_elapsed_seconds: 4.931
- profile: tech
- provider_mode: live
- provider_policy: fast
- strict: True
- quote_purpose: operation
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: 
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 0
- provider_runtime_budget_summary: akshare:attempts=3,elapsed=4.825,slow=0,failed=3; manual:attempts=1,elapsed=0.001,slow=0,failed=0; mock:attempts=6,elapsed=0.027,slow=0,failed=0
- quote_cache_hit_count: 47
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 39
- quote_cache_success_hit_count: 8
- repeated_provider_call_prevented_count: 47
- universe_name: 
- universe_type: 
- layer_config_mismatch: True
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319121.125
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-22T14:38:00+08:00

## Provider Runtime Summary
- account: tech
- layer: tech
- total_elapsed_seconds: 4.931
- run_time_budget_exceeded: False
- slow_provider_attempts: 0
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 4

## per_provider_elapsed_seconds
- akshare: 4.825
- mock: 0.027
- manual: 0.001
- yfinance: 0.0

## Config Source / Layer Manifest
- CONFIG_MISMATCH: true
- layer_name: tech_core
- config_source_path: config/universes/tech_core.yaml
- config_source_hash_sha256: 887257ec5e18
- configured_symbol_count: 8
- loaded_symbol_count: 7
- config_mismatch: true
- missing_from_loaded: 159995.SZ
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 159632.SZ: 4.831
- 513300.SH: 0.008
- 159819.SZ: 0.004
- 515880.SH: 0.003
- 159516.SZ: 0.003
- 510300.SH: 0.003
- GOLD_CNY: 0.001

## slow_provider_attempts
- 无

## provider_call_cache
- total_provider_calls: 1
- cache_hits: 2
- provider_call_count_by_function:
  - fund_etf_spot_em: 1

## Cache / Reuse Summary
- quote_cache_hit_count: 47
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 39
- quote_cache_success_hit_count: 8
- batch_cache_hit_count: 2
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 2
- batch_provider_failure_cached_count: 3
- repeated_provider_call_prevented_count: 47
- repeated_batch_call_prevented_count: 2
- quote_cache_profile_insufficient_count: 7
- cache_hit_by_layer: none
- cache_hit_by_provider: none

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 3
- provider_budget_account: tech
- provider_budget_run_id: 2026-06-04T11:10:16.193927+00:00
- provider_circuit_open: {'akshare': 'skipped_by_provider_circuit'}
- provider_budget_by_provider:
  - akshare: attempts=3, elapsed_seconds=4.825, slow_attempts=0, failed_attempts=3
  - manual: attempts=1, elapsed_seconds=0.001, slow_attempts=0, failed_attempts=0
  - mock: attempts=6, elapsed_seconds=0.027, slow_attempts=0, failed_attempts=0

## Price Reconciliation 摘要
- full report: price_reconciliation_report.md
- 159632.SZ: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 513300.SH: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 159819.SZ: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 515880.SH: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 510300.SH: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes

## Base Quote Fields Summary
| symbol | last | prev_close | open | high | low | volume | amount | change | change_pct | amplitude_pct | completeness | missing_fields | field_sources | exchange | country_market | trading_calendar |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|
| 159632.SZ | 1.432 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 513300.SH | 1.671 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159819.SZ | 0.921 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 515880.SH | 1.084 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159516.SZ | 0.756 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 510300.SH | 3.921 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| GOLD_CNY | 992.12 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=manual,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | MANUAL | MANUAL | MANUAL |

## Base Quote Field Sources
| symbol | last_source | prev_source | open_source | high_source | low_source | volume_source | amount_source | chg_source | completeness | missing_fields |
|---|---|---|---|---|---|---|---|---|---|---|
| 159632.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 513300.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159819.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 515880.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159516.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 510300.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| GOLD_CNY | manual | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |

## Provider Capability Summary
- full report: provider_capability_report.md
| provider | function_name | asset_type | base_price_fields | volume_amount_status | bid_ask_status | turnover_status | minute_status | operation_fit | notes |
|---|---|---|---|---|---|---|---|---|---|
| akshare | fund_etf_spot_em | ETF, QDII_ETF, A_SHARE_ETF | supported_or_calculable | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | Operation fit still depends on quote_trust_tier, strict, freshness, and provider health. |
| akshare | stock_spot_em | A_SHARE, HK_STOCK | mixed:missing,supported | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | A/H stock endpoint availability is environment-dependent. |
| akshare | fund_etf_hist_min_em | ETF, QDII_ETF, A_SHARE_ETF | missing | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | supported_if_endpoint_succeeds | diagnostic_only | ETF minute bars probe via AKShare; does not upgrade operation readiness. |
| eastmoney_direct | stock_get | ETF, A_SHARE_ETF, A_SHARE | mixed:calculable,supported_when_endpoint_succeeds | volume=supported_raw_unit; amount=supported_raw_unit | bid1=not_validated; ask1=not_validated | not_validated | attempted_provider_dependent | False | Reference / operation-candidate only; endpoint stability is not guaranteed. |
| yfinance | ticker_quote | ETF, HK_STOCK, A_SHARE, A_SHARE_ETF, INDEX | mixed:missing,provider_dependent,supported | volume=supported_raw_unit; amount=missing | bid1=missing_or_not_validated; ask1=missing_or_not_validated | missing | attempted_reference_fallback | reference_only | Open-source Yahoo Finance wrapper; not an official exchange feed. |
| manual | manual_price | MANUAL, GOLD | mixed:missing,supported | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | not_supported | conditional | Manual reference price; no market depth fields. |
| mock | mock_quote | TEST | mixed:missing,supported_for_tests | volume=supported_for_tests; amount=supported_for_tests | bid1=not_applicable; ask1=not_applicable | not_applicable | supported_for_tests | False | Development/testing only. |

### Current field quality risks
- raw_provider_unit records: 0
- unit_unknown records: 0
- volume_comparable_across_providers=false records: 7
- amount_comparable_across_providers=false records: 7
- bid/ask not validated; turnover_rate not validated; minute_bars/VWAP/QDII premium not implemented.

## Provider Capability Notes
AKShare:
- base quote fields: supported/partially supported through current normalized fields where provider raw fields are available.
- volume: raw provider unit.
- amount: raw provider unit or unit_unknown.
- bid/ask: not validated.
- turnover_rate: not validated.
- minute_bars: available through minute_probe when supported; reference-only and not operation-grade.

Eastmoney Direct:
- base quote fields: available only when endpoint succeeds.
- trust tier: reference / operation-candidate only.
- stability: unstable in current environment.
- bid/ask: not validated.
- minute_bars: available through minute_probe fallback when supported; reference-only and not operation-grade.

yfinance:
- base quote fields: reference-only for current ETF/watchlist usage.
- volume: raw provider unit.
- not operation-grade for A-share ETF operation path.
- timestamp/precision may differ from local exchange feeds.
- minute_bars: available as reference fallback through minute_probe when supported; provider_dependent and not operation-grade.

Capability label note:
- diagnostic_only in provider capability means capability label only; actual fallback behavior is controlled by minute_mode.

manual:
- GOLD_CNY price only.
- base_quote_completeness usually price_only.
- minute_bars: not supported.

mock:
- development/testing only.
- mock minute bars can be generated for tests when minute probe is enabled.
- not valid for real market decisions.

## Scan Ranking Trace
| symbol | rankable | exclusion_reason | data_quality_inputs | momentum_inputs | field_quality_inputs | liquidity_inputs | reconciliation_inputs | final_score | priority | notes |
|---|---|---|---|---|---|---|---|---:|---|---|
|  | false | not_applicable |  |  |  |  |  |  | not_rankable | scan ranking not applicable for operation profile |

## prices_snapshot 关键明细摘要
| symbol | name | selected_provider/source | quote_purpose | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | price | currency | quote_time | is_stale | stale_reason | required_for_operation | operation_blocking_reason | reference_note |
|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | mock | operation | development | False | False | True | 1.432 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 513300.SH | 纳指ETF | mock | operation | development | False | False | True | 1.671 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 159819.SZ | 人工智能ETF | mock | operation | development | False | False | True | 0.921 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 515880.SH | 通信ETF | mock | operation | development | False | False | True | 1.084 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 159516.SZ | 半导体设备ETF | mock | operation | development | False | False | True | 0.756 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 510300.SH | 沪深300ETF | mock | operation | development | False | False | True | 3.921 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| GOLD_CNY | 黄金持仓参考价 | manual | operation | operation | True | False | False | 992.12 | CNY | 2026-05-22T14:38:00+08:00 | True | manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议 | True | stale |  |

## Blocking / Error 摘要
### Blocking records
- project=tech, symbol=159632.SZ, name=纳指相关ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=513300.SH, name=纳指ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159819.SZ, name=人工智能ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=515880.SH, name=通信ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159516.SZ, name=半导体设备ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=GOLD_CNY, name=黄金持仓参考价, source=manual, quote_time=2026-05-22T14:38:00+08:00, is_stale=True, stale_reason=manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议, blocking_reason=stale, function_name=, provider_status=, exception_type=

### provider_error
- 无

### quote_time_missing
- 无

### invalid_price
- 无

### stale
- tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 510300.SH 沪深300ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech GOLD_CNY 黄金持仓参考价: manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议

### mock fallback not usable
- mock_fallback_not_allowed: tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 510300.SH 沪深300ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

### reference-only but operation requested
- 无

本排障包只用于定位 provider、runtime、freshness 和 blocking 问题。
