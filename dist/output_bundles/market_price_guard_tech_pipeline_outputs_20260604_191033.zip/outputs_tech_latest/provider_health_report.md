# Provider Health Report

行情源健康报告仅用于解释价格事实、接口状态和数据完整度，不提供具体操作建议，不做自动交易。

- provider_policy=fast
- quote_purpose=operation

## AKShare ETF
- provider: akshare
- market_category: ETF
- affected_symbols: 159632.SZ, 513300.SH, 159819.SZ
- quote_time_status: stale
- usable_for_operation: no
- function_name=fund_etf_spot_em, status=failed, returned_rows=, matched_symbols=, affected_symbols=159632.SZ, 513300.SH, 159819.SZ, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))

## AKShare Minute Bars
- provider: akshare
- function_name=fund_etf_hist_min_em
- affected_symbols: 
- status: not_called

## AKShare A股
- provider: akshare
- market_category: A_SHARE
- affected_symbols: 
- quote_time_status: not_available
- usable_for_operation: no
- status: not_called
- function_name=stock_zh_a_spot_em, status=not_called
- function_name=stock_sh_a_spot_em, status=not_called
- function_name=stock_sz_a_spot_em, status=not_called

## AKShare 港股
- provider: akshare
- market_category: HK
- affected_symbols: 
- quote_time_status: not_available
- usable_for_operation: no
- status: not_called
- function_name=stock_hk_spot_em, status=not_called
- function_name=stock_hk_main_board_spot_em, status=not_called
- function_name=stock_hsgt_sh_hk_spot_em, status=not_called

## YFinance 港股 / A股
- provider: yfinance
- market_category: HK/A_SHARE
- status: not_called
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_attempted_count: 0
- yfinance_skipped_by_circuit_count: 0
- yfinance_total_elapsed_seconds: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0

## Eastmoney Direct
- provider: eastmoney_direct
- market_category: ETF/A_SHARE
- status: not_called

## Manual
- provider: manual
- affected_symbols: GOLD_CNY
- quote_time_status: stale
- usable_for_operation: no
- symbol=GOLD_CNY, status=stale, quote_time=2026-05-22T14:38:00+08:00, source_note=用户手工录入：银行积存金/黄金理财估值价，需以后续实际账户可卖价为准

## Provider call summary
- function_name=akshare, call_count=0, cache_hits=0, uat_run_cache_hits=0, cache_statuses=, returned_rows=, matched_symbols=, elapsed_seconds_first_call=, failed=True, exception_type=, exception_message=
- function_name=fund_etf_spot_em, call_count=1, cache_hits=2, uat_run_cache_hits=0, cache_statuses=miss_failure_cached, returned_rows=, matched_symbols=, elapsed_seconds_first_call=4.717, failed=True, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))

## Provider Health Summary
| provider | planned_count | actual_attempt_count | success_count | failure_count | timeout_count | skipped_count | elapsed_seconds | slow_attempt_count | cache_hit_count | cache_miss_count | failure_cached_count | circuit_open_count | repeated_call_prevented_count | top_failure_reasons |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| akshare | 6 | 3 | 0 | 3 | 0 | 3 | 4.825 | 0 | 0 | 6 | 3 | 3 | 0 | provider_error:3, skipped_by_provider_circuit:3 |
| manual | 1 | 1 | 1 | 0 | 0 | 0 | 0.001 | 0 | 0 | 1 | 0 | 0 | 0 | none |
| mock | 6 | 6 | 6 | 0 | 0 | 0 | 0.027 | 0 | 0 | 6 | 0 | 0 | 0 | none |

## Provider attempts by symbol
### 159632.SZ
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: akshare, mock
- provider_skip_reasons: none
- normalized_symbol: 159632.SZ
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: a_share_provider_error
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=fund_etf_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=False, cache_enabled=True, cache_scope=uat_run, cache_status=miss_failure_cached, cache_file=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_cache_latest/akshare_fund_etf_spot_em.failure.json, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=4.825, slow_provider_attempt=False, reason=provider_error, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=1.432, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.006, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 513300.SH
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: akshare, mock
- provider_skip_reasons: none
- normalized_symbol: 513300.SH
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: a_share_provider_error
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=fund_etf_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=True, cache_enabled=True, cache_scope=uat_run, cache_status=miss_failure_cached, cache_file=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_cache_latest/akshare_fund_etf_spot_em.failure.json, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_error, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=1.671, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.008, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 159819.SZ
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: akshare, mock
- provider_skip_reasons: none
- normalized_symbol: 159819.SZ
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: a_share_provider_error
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=fund_etf_spot_em, status=failed, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=True, cache_enabled=True, cache_scope=uat_run, cache_status=miss_failure_cached, cache_file=/Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_cache_latest/akshare_fund_etf_spot_em.failure.json, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=provider_error, exception_type=ConnectionError, exception_message=HTTPSConnectionPool(host='push2delay.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/clist/get?pn=1&pz=100&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&wbp2u=%7C0%7C0%7C0%7Cweb&fid=f12&fs=b%3AMK0021%2Cb%3AMK0022%2Cb%3AMK0023%2Cb%3AMK0024%2Cb%3AMK0827&fields=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6%2Cf7%2Cf8%2Cf9%2Cf10%2Cf12%2Cf13%2Cf14%2Cf15%2Cf16%2Cf17%2Cf18%2Cf20%2Cf21%2Cf23%2Cf24%2Cf25%2Cf22%2Cf11%2Cf30%2Cf31%2Cf32%2Cf33%2Cf34%2Cf35%2Cf38%2Cf62%2Cf63%2Cf64%2Cf65%2Cf66%2Cf69%2Cf72%2Cf75%2Cf78%2Cf81%2Cf84%2Cf87%2Cf115%2Cf124%2Cf128%2Cf136%2Cf152%2Cf184%2Cf297%2Cf402%2Cf441 (Caused by NameResolutionError("HTTPSConnection(host='push2delay.eastmoney.com', port=443): Failed to resolve 'push2delay.eastmoney.com' ([Errno 8] nodename nor servname provided, or not known)"))
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=0.921, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.004, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 515880.SH
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: mock
- provider_skip_reasons: akshare=skipped_by_provider_circuit
- normalized_symbol: 515880.SH
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=1.084, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 159516.SZ
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: mock
- provider_skip_reasons: akshare=skipped_by_provider_circuit
- normalized_symbol: 159516.SZ
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=0.756, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### 510300.SH
- provider_policy: fast
- configured_provider_priority: akshare, mock
- provider_planned_chain: akshare, mock
- effective_provider_chain: akshare, mock
- actual_provider_attempted: mock
- provider_skip_reasons: akshare=skipped_by_provider_circuit
- normalized_symbol: 510300.SH
- route_reason: configured_provider_route:operation
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts:
  - provider=akshare, function_name=akshare, status=skipped, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=, quote_time=, usable_for_operation=False, quote_trust_tier=, usable_for_reference=, confirmation_required=, elapsed_seconds=0.0, slow_provider_attempt=False, reason=skipped_by_provider_circuit, exception_type=, exception_message=
  - provider=mock, function_name=mock, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=3.921, quote_time=2026-05-20T12:45:00+08:00, usable_for_operation=False, quote_trust_tier=development, usable_for_reference=False, confirmation_required=True, elapsed_seconds=0.003, slow_provider_attempt=False, reason=, exception_type=, exception_message=
### GOLD_CNY
- provider_policy: fast
- configured_provider_priority: manual
- provider_planned_chain: manual
- effective_provider_chain: manual
- actual_provider_attempted: manual
- provider_skip_reasons: none
- normalized_symbol: GOLD_CNY
- route_reason: manual_reference_required
- selected_provider: manual
- selected_source: manual
- fallback_used: False
- usable_for_operation: True
- quote_trust_tier: operation
- usable_for_reference: True
- confirmation_required: False
- selection_reason: selected_provider_returned_usable_price
- final_blocking_reason: stale
- provider_failure_reason: reference_available
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts:
  - provider=manual, function_name=manual, status=success, secid=, endpoint=, request_status=, retry_count=, final_status=, from_cache=, cache_enabled=, cache_scope=, cache_status=, cache_file=, price=992.12, quote_time=2026-05-22T14:38:00+08:00, usable_for_operation=True, quote_trust_tier=operation, usable_for_reference=True, confirmation_required=False, elapsed_seconds=0.001, slow_provider_attempt=False, reason=, exception_type=, exception_message=
