# 数据完整度报告

quote_purpose: operation
reconcile_mode: default
可用于具体操作建议：否

本工具不做自动交易，不输出具体操作建议，只输出价格事实、数据源、时间戳、市场状态和数据完整度。

行情源健康状态详见 provider_health_report.md。

## Config Source / Layer Manifest
- CONFIG_MISMATCH: true
- layer_name: tech_core
- config_source_path: config/universes/tech_core.yaml
- config_source_hash_sha256: 887257ec5e18
- configured_symbol_count: 8
- loaded_symbol_count: 7
- config_mismatch: true
- missing_from_loaded: 159995.SZ
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Strict blocking records
- project=tech, symbol=159632.SZ, name=纳指相关ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=513300.SH, name=纳指ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159819.SZ, name=人工智能ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=515880.SH, name=通信ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159516.SZ, name=半导体设备ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=GOLD_CNY, name=黄金持仓参考价, source=manual, quote_time=2026-05-22T14:38:00+08:00, is_stale=True, stale_reason=manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议, blocking_reason=stale, function_name=, provider_status=, exception_type=

## Provider diagnostics
- 无 AKShare 记录

## Provider routing notes
- 159632.SZ: provider_policy=fast
- 159632.SZ: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 159632.SZ: mock fallback 不可用于具体操作建议
- 513300.SH: provider_policy=fast
- 513300.SH: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 513300.SH: mock fallback 不可用于具体操作建议
- 159819.SZ: provider_policy=fast
- 159819.SZ: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 159819.SZ: mock fallback 不可用于具体操作建议
- 515880.SH: provider_policy=fast
- 515880.SH: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 515880.SH: mock fallback 不可用于具体操作建议
- 159516.SZ: provider_policy=fast
- 159516.SZ: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 159516.SZ: mock fallback 不可用于具体操作建议
- 510300.SH: provider_policy=fast
- 510300.SH: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 510300.SH: mock fallback 不可用于具体操作建议
- GOLD_CNY: provider_policy=fast

## Quote trust tier diagnostics
- quote_purpose: operation
- quote_trust_tier summary: operation=1, reference=0, development=6
- operation-grade records: GOLD_CNY
- reference-grade records: 
- development-grade records: 159632.SZ, 513300.SH, 159819.SZ, 515880.SH, 159516.SZ, 510300.SH
- confirmation_required records: 159632.SZ, 513300.SH, 159819.SZ, 515880.SH, 159516.SZ, 510300.SH

## Source agreement diagnostics
- full report: price_reconciliation_report.md
- 159632.SZ: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 513300.SH: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 159819.SZ: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 515880.SH: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 510300.SH: compared_sources=akshare, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes

## Base quote completeness summary
- base_quote_completeness counts:
- price_only: 7
- missing fields top: amount:7, high_price:7, low_price:7, open_price:7, prev_close:7, volume:7
- base quote fields are auxiliary diagnostics; missing fields do not change existing strict in this version.

| symbol | base_quote_completeness | available | missing | missing_fields |
|---|---|---:|---:|---|
| 159632.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 513300.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159819.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 515880.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159516.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 510300.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| GOLD_CNY | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |

### Base quote caveats
- volume/amount follow provider raw units unless unit normalization is explicitly available.
- cross-provider volume/amount comparison is not reliable until provider field validation is completed.
- base quote missing does not change existing strict; base quote and field capability issues do not change existing strict in v0.7.1.6.
- operation still depends on quote_trust_tier / usable_for_operation / strict / freshness.
- field completeness is a diagnostic aid, not operation guidance.

## Field Quality / Provider Capability
- volume_comparable_across_providers=true records: 0
- amount_comparable_across_providers=true records: 0
- unit_unknown records: 0
- raw_provider_unit records: 0
- field_validation_status counts: development_only:6, validated:1
- not_validated fields: bid1_price, ask1_price, turnover_rate
- not_implemented fields: minute_bars, intraday_vwap, iopv, premium_pct
- field validation issues do not change existing strict in v0.7.1.6.
- operation still depends on quote_trust_tier / usable_for_operation / strict / freshness.
- capability data is diagnostic, not operation guidance.

## Minute Bars Completeness
- include_minute_bars: False
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- minute_bars_available count: 0
- operation_candidate_symbols_count: 0
- operation_candidate_minute_available_count: 0
- operation_candidate_minute_missing_count: 0
- unavailable count: 0
- not_supported count: 0
- provider_error count: 0
- symbol_not_found count: 0
- stale count: 0
- akshare_attempted_count: 0
- akshare_success_count: 0
- akshare_error_count: 0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_empty_response_count: 0
- yfinance_parse_error_count: 0
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- fallback_skipped_yfinance_circuit_open_count: 0
- yfinance_last_error: 
- eastmoney_attempted_count: 0
- eastmoney_success_count: 0
- eastmoney_error_count: 0
- eastmoney_empty_response_count: 0
- eastmoney_parse_error_count: 0
- empty_response count: 0
- after_close_possible_count: 0
- retry_during_trading_hours_count: 0
- current session summary: missing:7
- upload bundle uses compact minute notes; full provider diagnostics remain in debug_bundle.md.
- status counts:
  - not_attempted: 7
- by provider:
  - missing: 7
- minute bars missing does not change existing strict in v0.7.3.
- Eastmoney minute bars are diagnostic/reference only.
- minute fallback behavior depends on minute_mode; balanced skips Eastmoney minute fallback by default.
- minute bars are diagnostic only.

## Scan Ranking Summary
- total_symbols: 0
- rankable_count: 0
- not_rankable_count: 0
- high_priority_count: 0
- medium_priority_count: 0
- low_priority_count: 0
- symbol_not_found_count: 0
- provider_issue_count: 0
- data_insufficient_count: 0
- exclusion reasons: none
- ranking does not affect strict.
- See price_reconciliation_report.md for full multi-source comparison details.

## Runtime freshness diagnostics
- 详见 runtime_diagnostics.md
- provider_policy: fast
- total_elapsed_seconds: 4.931
- run_time_budget_exceeded: False
- max_quote_lag_seconds: 1319121.125
- max_data_lag_seconds: 300.0

## AKShare price records
- 无

## AKShare quote freshness details
- 无

## AKShare / 数据质量问题
- 无

## 黄金手工价说明
黄金持仓参考价为用户手工录入价，不等同于国际现货金价；用于科技账户防守仓/潜在转科技资金的参考，实际操作前需核对账户内可卖价、手续费、点差和到账规则。

## 如果为否，原因
- 存在 stale 价格

## 缺失价格列表
- 无

## stale 价格列表
- tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 510300.SH 沪深300ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech GOLD_CNY 黄金持仓参考价: manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议

## quote_time 缺失列表
- 无

## manual price records
- GOLD_CNY 黄金持仓参考价: price=992.12, quote_time=2026-05-22T14:38:00+08:00, is_stale=True, source_note=用户手工录入：银行积存金/黄金理财估值价，需以后续实际账户可卖价为准, fee_note=手续费、点差、赎回到账规则未自动计算, asset_role=defense_or_potential_tech_funding

## warning
- tech 510300.SH 沪深300ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

## 不确定性
- 手续费、点差、赎回到账规则未自动计算。
- GOLD_CNY 需以后续实际账户可卖价为准。

## 允许使用范围
- 可用于价格事实同步、数据源核对、时间戳核对、市场状态核对和数据完整度检查。
- 收盘后价格仅可作为收盘/最后成交参考。
- GOLD_CNY 仅可作为科技账户防守仓/潜在转科技资金参考。

## 禁止使用范围
- 不可用于自动交易。
- 不输出具体操作建议。
- 若 required_for_operation 指标缺失、stale、quote_time 缺失或无效，不可用于具体操作建议。
- 收盘/最后成交参考价不可用于盘中盘中高频判断。
