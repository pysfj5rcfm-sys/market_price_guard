# market_price_guard 上传包

## 基本信息
- generated_at: 2026-06-04T11:10:21.124874+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: operation
- reconcile_mode: default
- strict: true
- exit_code: 2
- output_dir: outputs_tech_latest
- universe_name: 
- universe_type: 
- core_count: 
- watchlist_count: 
- scan_count: 
- unsupported_count: 

## Config Source / Layer Manifest
- CONFIG_MISMATCH: true
- layer_name: tech_core
- config_source_path: config/universes/tech_core.yaml
- config_source_hash_sha256: 887257ec5e18
- configured_symbol_count: 8
- loaded_symbol_count: 7
- config_mismatch: true
- missing_from_loaded: 159995.SZ
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## 本轮结论
- 可用于快速参考：是
- 可用于具体操作建议：否
- 当前用途级别：operation-blocked
- confirmation_required 数量: 6
- blocking records 数量: 6

## 数据完整度摘要
- strict/exit_code: 2
- provider_error 数量: 0
- stale 数量: 7
- quote_time_missing 数量: 0
- invalid_price 数量: 0
- mock fallback not usable 数量: 6
- run_time_budget_exceeded: False

### Blocking records 摘要
- project=tech, symbol=159632.SZ, name=纳指相关ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=513300.SH, name=纳指ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159819.SZ, name=人工智能ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=515880.SH, name=通信ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159516.SZ, name=半导体设备ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=GOLD_CNY, name=黄金持仓参考价, source=manual, quote_time=2026-05-22T14:38:00+08:00, is_stale=True, stale_reason=manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议, blocking_reason=stale, function_name=, provider_status=, exception_type=

## Quote Trust Tier 摘要
- operation-grade records 数量: 1
- reference-grade records 数量: 0
- development-grade records 数量: 6
- usable_for_reference=true 数量: 1
- usable_for_operation=true 数量: 0
- confirmation_required=true 数量: 6

## 基础行情快照 / Base Quote Snapshot
| symbol | name | last | chg% | open | high | low | prev | volume | amount | base | provider | tier | op? |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|
| 159632.SZ | 纳指相关ETF | 1.432 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 513300.SH | 纳指ETF | 1.671 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 159819.SZ | 人工智能ETF | 0.921 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 515880.SH | 通信ETF | 1.084 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 159516.SZ | 半导体设备ETF | 0.756 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 510300.SH | 沪深300ETF | 3.921 | — | — | — | — | — | — | — | price_only | mock | development | False |
| GOLD_CNY | 黄金持仓参考价 | 992.12 | — | — | — | — | — | — | — | price_only | manual | operation | False |
- base_quote_completeness is shown in the compact `base` column.

- volume/amount follow provider raw units unless unit normalization is explicitly available.
- 成交量/成交额暂按 provider 原始单位展示；未统一单位前不得直接跨 provider 排名。

## 字段质量提示 / Field Quality Notes
- volume/amount are shown in provider raw units unless explicitly validated.
- cross-provider volume/amount comparison is unsafe in this version.
- bid/ask, turnover_rate, minute_bars, VWAP and QDII premium are not validated or not implemented.
- See debug_bundle.md and provider_capability_report.md for details.

## Reconciliation Summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=5
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 项目核心内容
### 纳指 / 海外科技ETF

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | 1.432 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 513300.SH | 纳指ETF | 1.671 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

### AI / 人工智能ETF

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 159819.SZ | 人工智能ETF | 0.921 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

### 通信 / 科技ETF

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 515880.SH | 通信ETF | 1.084 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

### 黄金防守仓 / 潜在转科技资金

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| GOLD_CNY | 黄金持仓参考价 | 992.12 | CNY | manual | manual | 2026-05-22T14:38:00+08:00 | 2026-06-04T11:10:21.123061+00:00 | manual | True | manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议 | False | operation | True | False |

### 非科技宽基单独列示

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 510300.SH | 沪深300ETF | 3.921 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |


## Universe isolation
- legacy profile mode; no explicit universe selected.

## Reference / Operation 使用提示
- 本轮为 operation 模式。
- 如果 strict=2 或 blocking records 存在，不得给高精度执行价位。
- 可根据数据完整度要求补充数据或降级为事实核对。

## Debug 提示
- 如出现 strict=2、blocking records、provider_error、quote_time_missing、invalid_price、stale、selected_provider=mock、fallback_used 异常、run_time_budget_exceeded、slow_provider_attempts、quote_time 可疑或报告冲突，请补充 debug_bundle.md。
- 本上传包只汇总数据状态、可用性和阻断原因。
