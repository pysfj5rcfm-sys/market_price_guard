# market_price_guard 上传包

## 基本信息
- generated_at: 2026-06-04T11:10:21.725550+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_tech_minute_probe_latest
- universe_name: tech_minute_probe
- universe_type: minute_probe
- core_count: 8
- watchlist_count: 0
- scan_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: tech_minute_probe
- config_source_path: config/universes/tech_core.yaml+config/universes/tech_operation_candidates.yaml
- config_source_hash_sha256: 5a028ccc1d5b
- configured_symbol_count: 23
- loaded_symbol_count: 23
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## 本轮结论
- 可用于快速参考：是
- 可用于具体操作建议：否
- 当前用途级别：reference-only
- confirmation_required 数量: 22
- blocking records 数量: 6

## 数据完整度摘要
- strict/exit_code: 0
- provider_error 数量: 16
- stale 数量: 7
- quote_time_missing 数量: 16
- invalid_price 数量: 16
- mock fallback not usable 数量: 6
- run_time_budget_exceeded: False

### Blocking records 摘要
- project=tech, symbol=159632.SZ, name=纳指相关ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=513300.SH, name=纳指ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159819.SZ, name=人工智能ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=515880.SH, name=通信ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159516.SZ, name=半导体设备ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=GOLD_CNY, name=黄金持仓参考价, source=manual, quote_time=2026-05-22T14:38:00+08:00, is_stale=True, stale_reason=manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议, blocking_reason=stale, function_name=, provider_status=, exception_type=

## Quote Trust Tier 摘要
- operation-grade records 数量: 1
- reference-grade records 数量: 0
- development-grade records 数量: 22
- usable_for_reference=true 数量: 1
- usable_for_operation=true 数量: 0
- confirmation_required=true 数量: 22

## 基础行情快照 / Base Quote Snapshot
| symbol | name | last | chg% | open | high | low | prev | volume | amount | base | provider | tier | op? |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|
| 159632.SZ | 纳指相关ETF | 1.432 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 513300.SH | 纳指ETF | 1.671 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 159819.SZ | 人工智能ETF | 0.921 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 515880.SH | 通信ETF | 1.084 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 159516.SZ | 半导体设备ETF | 0.756 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 510300.SH | 沪深300ETF | 3.921 | — | — | — | — | — | — | — | price_only | mock | development | False |
| GOLD_CNY | 黄金持仓参考价 | 992.12 | — | — | — | — | — | — | — | price_only | manual | operation | False |
| 159995.SZ | 芯片ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 588200.SH | 科创芯片ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 512480.SH | 半导体ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 588890.SH | 科创芯片相关ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 588170.SH | 科创半导体ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 159558.SZ | 半导体设备ETF易方达 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 515050.SH | 通信ETF华夏 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 159994.SZ | 通信ETF银华 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 513180.SH | 恒生科技指数ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 513130.SH | 恒生科技相关ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 513150.SH | 港股互联网ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 513020.SH | 港股科技互联网相关ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 002463.SZ | 沪电股份 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 002938.SZ | 鹏鼎控股 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 600183.SH | 生益科技 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 002281.SZ | 光迅科技 | — | — | — | — | — | — | — | — | missing | mock | development | False |
- base_quote_completeness is shown in the compact `base` column.

- volume/amount follow provider raw units unless unit normalization is explicitly available.
- 成交量/成交额暂按 provider 原始单位展示；未统一单位前不得直接跨 provider 排名。

## 字段质量提示 / Field Quality Notes
- volume/amount are shown in provider raw units unless explicitly validated.
- cross-provider volume/amount comparison is unsafe in this version.
- bid/ask, turnover_rate, minute_bars, VWAP and QDII premium are not validated or not implemented.
- See debug_bundle.md and provider_capability_report.md for details.

## 分钟线探测摘要 / Minute Bars Probe Summary
Minute note is compact. Full provider failure details are in debug_bundle.md.
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
| symbol | name | available | provider | interval | count | latest_time | status | validation | note |
|---|---|---|---|---|---:|---|---|---|---|
| 159632.SZ | 纳指相关ETF | False | yfinance | not_available | 0 | — | provider_error | provider_dependent | provider_error; see_debug |
| 513300.SH | 纳指ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | provider_skipped; see_debug |
| 159819.SZ | 人工智能ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 515880.SH | 通信ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 159516.SZ | 半导体设备ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 510300.SH | 沪深300ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| GOLD_CNY | 黄金持仓参考价 | False | manual | not_available | 0 | — | not_supported | not_supported | manual_price_only; minute_not_supported |
| 159995.SZ | 芯片ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 588200.SH | 科创芯片ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 512480.SH | 半导体ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 588890.SH | 科创芯片相关ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 588170.SH | 科创半导体ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 159558.SZ | 半导体设备ETF易方达 | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 515050.SH | 通信ETF华夏 | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 159994.SZ | 通信ETF银华 | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 513180.SH | 恒生科技指数ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 513130.SH | 恒生科技相关ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 513150.SH | 港股互联网ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 513020.SH | 港股科技互联网相关ETF | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 002463.SZ | 沪电股份 | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 002938.SZ | 鹏鼎控股 | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 600183.SH | 生益科技 | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
| 002281.SZ | 光迅科技 | False | yfinance | not_available | 0 | — | provider_skipped | provider_dependent | yfinance_circuit_open; no_minute_bars; see_debug |
- Minute bars are reference-only and do not change strict or operation readiness.
- VWAP and intraday derived fields are calculated separately in outputs_tech_intraday_latest.
- Operation decisions still depend on quote_trust_tier / usable_for_operation / strict / freshness.
- This section does not provide execution instructions.

## Reconciliation Summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=5
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 项目核心内容
### 纳指 / 海外科技ETF

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | 1.432 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 513300.SH | 纳指ETF | 1.671 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

### AI / 人工智能ETF

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 159819.SZ | 人工智能ETF | 0.921 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

### 通信 / 科技ETF

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 515880.SH | 通信ETF | 1.084 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

### 黄金防守仓 / 潜在转科技资金

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| GOLD_CNY | 黄金持仓参考价 | 992.12 | CNY | manual | manual | 2026-05-22T14:38:00+08:00 | 2026-06-04T11:10:15.069406+00:00 | manual | True | manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议 | False | operation | True | False |

### 非科技宽基单独列示

| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 510300.SH | 沪深300ETF | 3.921 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |


## Universe isolation
- universe_name: tech_minute_probe
- universe_type: minute_probe
- candidate/watchlist/scan symbols keep required_for_operation=false unless promoted to core_holdings.

## Reference / Operation 使用提示
- 本轮为快速参考模式。
- 可以用于快速参考。
- 不可用于具体操作建议。
- 不可给出具体执行动作、盘中高频判断或执行参数参数。
- 如需具体操作，请运行 operation 输出或补充有效盘口信息。

## Debug 提示
- 如出现 strict=2、blocking records、provider_error、quote_time_missing、invalid_price、stale、selected_provider=mock、fallback_used 异常、run_time_budget_exceeded、slow_provider_attempts、quote_time 可疑或报告冲突，请补充 debug_bundle.md。
- 本上传包只汇总数据状态、可用性和阻断原因。
