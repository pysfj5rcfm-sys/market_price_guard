# market_price_guard 排障包

## 基本信息
- generated_at: 2026-06-04T11:10:21.725550+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_tech_minute_probe_latest
- universe_name: tech_minute_probe
- universe_type: minute_probe

## Symbol Registry Resolution 摘要
- registry_enabled: true
- registry_path: /Users/chenyulin/Documents/AIProjects/market_price_guard/config/symbol_registry.yaml
- universe_name: tech_minute_probe
- universe_type: minute_probe
- core_count: 8
- watchlist_count: 0
- scan_count: 0
- operation_candidate_count: 15
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: tech_minute_probe
- config_source_path: config/universes/tech_core.yaml+config/universes/tech_operation_candidates.yaml
- config_source_hash_sha256: 5a028ccc1d5b
- configured_symbol_count: 23
- loaded_symbol_count: 23
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Provider Health 摘要
- provider_policy: fast
- provider_mode: live
- 无

### Provider attempts
### 159632.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: none
- normalized_symbol: 159632.SZ
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### 513300.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: none
- normalized_symbol: 513300.SH
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### 159819.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: none
- normalized_symbol: 159819.SZ
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### 515880.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: akshare=skipped_by_provider_circuit, eastmoney_direct=skipped_by_provider_circuit
- normalized_symbol: 515880.SH
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### 159516.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit
- normalized_symbol: 159516.SZ
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 510300.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: akshare=skipped_by_provider_circuit, eastmoney_direct=skipped_by_provider_circuit
- normalized_symbol: 510300.SH
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### GOLD_CNY
- provider_policy: fast
- configured_provider_priority: manual
- provider_planned_chain: manual
- effective_provider_chain: manual
- actual_provider_attempted: 
- provider_skip_reasons: none
- normalized_symbol: GOLD_CNY
- route_reason: manual_reference_required
- selected_provider: manual
- selected_source: manual
- fallback_used: False
- usable_for_operation: True
- quote_trust_tier: operation
- usable_for_reference: True
- confirmation_required: False
- selection_reason: selected_provider_returned_usable_price
- final_blocking_reason: stale
- provider_failure_reason: reference_available
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 159995.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit
- normalized_symbol: 159995.SZ
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 588200.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit
- normalized_symbol: 588200.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 512480.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit
- normalized_symbol: 512480.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 588890.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 588890.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 588170.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 588170.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 159558.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 159558.SZ
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 515050.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 515050.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 159994.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 159994.SZ
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513180.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513180.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513130.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513130.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513150.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513150.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513020.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513020.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 002463.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 002463.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 002938.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 002938.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 600183.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600183.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 002281.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 002281.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无

## Runtime Diagnostics 摘要
- run_start_time_utc: 2026-06-04T11:10:21.475286+00:00
- run_end_time_utc: 2026-06-04T11:10:21.725550+00:00
- total_elapsed_seconds: 0.25
- profile: tech
- provider_mode: live
- provider_policy: fast
- strict: False
- quote_purpose: reference
- reconcile_mode: default
- include_minute_bars: True
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: True
- yfinance_circuit_reason: repeated_error
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.041
- yfinance_attempted_count: 3
- yfinance_success_count: 0
- yfinance_error_count: 3
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 21
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 21
- yfinance_last_error: empty_response
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 0
- provider_runtime_budget_summary: none
- quote_cache_hit_count: 70
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 55
- quote_cache_success_hit_count: 15
- repeated_provider_call_prevented_count: 70
- universe_name: tech_minute_probe
- universe_type: minute_probe
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319121.726
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-22T14:38:00+08:00

## Provider Runtime Summary
- account: tech
- layer: tech_minute_probe
- total_elapsed_seconds: 0.25
- run_time_budget_exceeded: False
- slow_provider_attempts: 0
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 0

## per_provider_elapsed_seconds
- yfinance: 0.041

## Config Source / Layer Manifest
- layer_name: tech_minute_probe
- config_source_path: config/universes/tech_core.yaml+config/universes/tech_operation_candidates.yaml
- config_source_hash_sha256: 5a028ccc1d5b
- configured_symbol_count: 23
- loaded_symbol_count: 23
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 159632.SZ: 0.0
- 513300.SH: 0.0
- 159819.SZ: 0.0
- 515880.SH: 0.0
- 159516.SZ: 0.0
- 510300.SH: 0.0
- GOLD_CNY: 0.0
- 159995.SZ: 0.0
- 588200.SH: 0.0
- 512480.SH: 0.0
- 588890.SH: 0.0
- 588170.SH: 0.0
- 159558.SZ: 0.0
- 515050.SH: 0.0
- 159994.SZ: 0.0
- 513180.SH: 0.0
- 513130.SH: 0.0
- 513150.SH: 0.0
- 513020.SH: 0.0
- 002463.SZ: 0.0
- 002938.SZ: 0.0
- 600183.SH: 0.0
- 002281.SZ: 0.0

## slow_provider_attempts
- 无

## provider_call_cache
- total_provider_calls: 0
- cache_hits: 0
- provider_call_count_by_function: 无

## Cache / Reuse Summary
- quote_cache_hit_count: 70
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 55
- quote_cache_success_hit_count: 15
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 70
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 7
- cache_hit_by_layer: tech_core:8, tech_operation_candidates:15
- cache_hit_by_provider: manual:1, mock:22

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 0
- provider_budget_account: tech
- provider_budget_run_id: 2026-06-04T11:10:21.475286+00:00
- provider_circuit_open: {}
- provider_budget_by_provider: none

## Price Reconciliation 摘要
- full report: price_reconciliation_report.md
- 159632.SZ: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 513300.SH: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 159819.SZ: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 515880.SH: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 510300.SH: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes

## Base Quote Fields Summary
| symbol | last | prev_close | open | high | low | volume | amount | change | change_pct | amplitude_pct | completeness | missing_fields | field_sources | exchange | country_market | trading_calendar |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|
| 159632.SZ | 1.432 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 513300.SH | 1.671 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159819.SZ | 0.921 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 515880.SH | 1.084 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159516.SZ | 0.756 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 510300.SH | 3.921 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| GOLD_CNY | 992.12 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=manual,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | MANUAL | MANUAL | MANUAL |
| 159995.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 588200.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 512480.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 588890.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 588170.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159558.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 515050.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159994.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 513180.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 513130.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 513150.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 513020.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 002463.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 002938.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 600183.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 002281.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |

## Base Quote Field Sources
| symbol | last_source | prev_source | open_source | high_source | low_source | volume_source | amount_source | chg_source | completeness | missing_fields |
|---|---|---|---|---|---|---|---|---|---|---|
| 159632.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 513300.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159819.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 515880.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159516.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 510300.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| GOLD_CNY | manual | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159995.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588200.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512480.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588890.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588170.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159558.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515050.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159994.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513180.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513130.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513150.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513020.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002463.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002938.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600183.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002281.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |

## Provider Capability Summary
- full report: provider_capability_report.md
| provider | function_name | asset_type | base_price_fields | volume_amount_status | bid_ask_status | turnover_status | minute_status | operation_fit | notes |
|---|---|---|---|---|---|---|---|---|---|
| akshare | fund_etf_spot_em | ETF, QDII_ETF, A_SHARE_ETF | supported_or_calculable | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | Operation fit still depends on quote_trust_tier, strict, freshness, and provider health. |
| akshare | stock_spot_em | A_SHARE, HK_STOCK | mixed:missing,supported | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | A/H stock endpoint availability is environment-dependent. |
| akshare | fund_etf_hist_min_em | ETF, QDII_ETF, A_SHARE_ETF | missing | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | supported_if_endpoint_succeeds | diagnostic_only | ETF minute bars probe via AKShare; does not upgrade operation readiness. |
| eastmoney_direct | stock_get | ETF, A_SHARE_ETF, A_SHARE | mixed:calculable,supported_when_endpoint_succeeds | volume=supported_raw_unit; amount=supported_raw_unit | bid1=not_validated; ask1=not_validated | not_validated | attempted_provider_dependent | False | Reference / operation-candidate only; endpoint stability is not guaranteed. |
| yfinance | ticker_quote | ETF, HK_STOCK, A_SHARE, A_SHARE_ETF, INDEX | mixed:missing,provider_dependent,supported | volume=supported_raw_unit; amount=missing | bid1=missing_or_not_validated; ask1=missing_or_not_validated | missing | attempted_reference_fallback | reference_only | Open-source Yahoo Finance wrapper; not an official exchange feed. |
| manual | manual_price | MANUAL, GOLD | mixed:missing,supported | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | not_supported | conditional | Manual reference price; no market depth fields. |
| mock | mock_quote | TEST | mixed:missing,supported_for_tests | volume=supported_for_tests; amount=supported_for_tests | bid1=not_applicable; ask1=not_applicable | not_applicable | supported_for_tests | False | Development/testing only. |

### Current field quality risks
- raw_provider_unit records: 0
- unit_unknown records: 0
- volume_comparable_across_providers=false records: 23
- amount_comparable_across_providers=false records: 23
- bid/ask not validated; turnover_rate not validated; minute_bars/VWAP/QDII premium not implemented.

## Provider Capability Notes
AKShare:
- base quote fields: supported/partially supported through current normalized fields where provider raw fields are available.
- volume: raw provider unit.
- amount: raw provider unit or unit_unknown.
- bid/ask: not validated.
- turnover_rate: not validated.
- minute_bars: available through minute_probe when supported; reference-only and not operation-grade.

Eastmoney Direct:
- base quote fields: available only when endpoint succeeds.
- trust tier: reference / operation-candidate only.
- stability: unstable in current environment.
- bid/ask: not validated.
- minute_bars: available through minute_probe fallback when supported; reference-only and not operation-grade.

yfinance:
- base quote fields: reference-only for current ETF/watchlist usage.
- volume: raw provider unit.
- not operation-grade for A-share ETF operation path.
- timestamp/precision may differ from local exchange feeds.
- minute_bars: available as reference fallback through minute_probe when supported; provider_dependent and not operation-grade.

Capability label note:
- diagnostic_only in provider capability means capability label only; actual fallback behavior is controlled by minute_mode.

manual:
- GOLD_CNY price only.
- base_quote_completeness usually price_only.
- minute_bars: not supported.

mock:
- development/testing only.
- mock minute bars can be generated for tests when minute probe is enabled.
- not valid for real market decisions.

## Minute Bars Probe Detail
| symbol | source_universe | base_quote_provider_attempted | minute_provider_attempted | provider_success | normalized_symbol | eastmoney_secid | akshare_status | akshare_reason | akshare_error_type | akshare_error_message | eastmoney_status | eastmoney_reason | eastmoney_endpoint | eastmoney_error_type | eastmoney_error_message | yfinance_ticker | yfinance_status | yfinance_reason | yfinance_error_type | yfinance_error_message | status | interval | count | latest_time | fetch_time | validation_status | missing_reason | market_session | after_close_possible | after_close_applies_to | retry_suggested | retry_reason | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| 159632.SZ | tech_core | — | akshare,yfinance | none | 159632 | 0.159632 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | 159632.SZ | provider_error | provider_error | DNSError | Failed to perform, curl: (6) Could not resolve host: guce.yahoo.com. See https://curl.se/libcurl/c/libcurl-errors.html first for more details. | provider_error | not_available | 0 | — | 2026-06-04T11:10:21.567137+00:00 | provider_dependent | provider_error | cn_after_close | True | akshare,eastmoney_direct | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=provider_error; yfinance_reason=provider_error; yfinance_ticker=159632.SZ; yfinance_error_type=DNSError; yfinance_error_message=Failed to perform, curl: (6) Could not resolve host: guce.yahoo.com. See https://curl.se/libcurl/c/libcurl-errors.html first for more details.; reference_only; provider_dependent; not_operation_grade; yfinance_intraday_limit; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=159632; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; DNSError: Failed to perform, curl: (6) Could not resolve host: guce.yahoo.com. See https://curl.se/libcurl/c/libcurl-errors.html first for more details.; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare,eastmoney_direct; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 513300.SH | tech_core | — | akshare,yfinance | none | 513300 | 1.513300 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | 513300.SS | provider_skipped | yfinance_circuit_open | — | yfinance_circuit_open | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.713111+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare,eastmoney_direct | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=provider_skipped; yfinance_reason=yfinance_circuit_open; yfinance_ticker=513300.SS; yfinance_error_type=; yfinance_error_message=yfinance_circuit_open; reference_only; provider_dependent; not_operation_grade; yfinance_intraday_limit; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=513300; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; yfinance_circuit_open; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare,eastmoney_direct; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error |
| 159819.SZ | tech_core | — | akshare,yfinance | none | 159819 | 0.159819 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.715021+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=159819; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 515880.SH | tech_core | — | akshare,yfinance | none | 515880 | 1.515880 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.715825+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=515880; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 159516.SZ | tech_core | — | akshare,yfinance | none | 159516 | 0.159516 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.716571+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=159516; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 510300.SH | tech_core | — | akshare,yfinance | none | 510300 | 1.510300 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.717278+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=510300; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| GOLD_CNY | tech_core | — | manual | none | GOLD_CNY | — | not_called | — | — | — | — | — | — | — | — | — | — | — | — | — | not_supported | not_available | 0 | — | 2026-06-04T11:10:21.717875+00:00 | not_supported | manual_price_only | — | False | — | — | — | manual price only; minute bars are not supported |
| 159995.SZ | tech_core | — | akshare,yfinance | none | 159995 | 0.159995 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.717884+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=159995; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 588200.SH | tech_operation_candidates | — | akshare,yfinance | none | 588200 | 1.588200 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.718497+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=588200; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 512480.SH | tech_operation_candidates | — | akshare,yfinance | none | 512480 | 1.512480 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.719187+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=512480; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 588890.SH | tech_operation_candidates | — | akshare,yfinance | none | 588890 | 1.588890 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.719787+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=588890; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 588170.SH | tech_operation_candidates | — | akshare,yfinance | none | 588170 | 1.588170 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.720387+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=588170; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 159558.SZ | tech_operation_candidates | — | akshare,yfinance | none | 159558 | 0.159558 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.721053+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=159558; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 515050.SH | tech_operation_candidates | — | akshare,yfinance | none | 515050 | 1.515050 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.721639+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=515050; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 159994.SZ | tech_operation_candidates | — | akshare,yfinance | none | 159994 | 0.159994 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.722227+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=159994; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 513180.SH | tech_operation_candidates | — | akshare,yfinance | none | 513180 | 1.513180 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.723009+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=513180; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 513130.SH | tech_operation_candidates | — | akshare,yfinance | none | 513130 | 1.513130 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.723655+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=513130; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 513150.SH | tech_operation_candidates | — | akshare,yfinance | none | 513150 | 1.513150 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.724233+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=513150; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 513020.SH | tech_operation_candidates | — | akshare,yfinance | none | 513020 | 1.513020 | provider_error | provider_error | ConnectionError | HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2 | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.724894+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | True | akshare | rerun_during_cn_trading_hours | AKShare minute endpoint failed outside CN continuous trading hours; market session may be a contributing factor, not a confirmed root cause. | provider_attempted=akshare,yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; akshare_status=provider_error; akshare_reason=provider_error; akshare_note=akshare_error_type=ConnectionError; akshare_error_message=HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; fund_etf_hist_min_em normalized_symbol=513020; ConnectionError: HTTPSConnectionPool(host='push2his.eastmoney.com', port=443): Max retries exceeded with url: /api/qt/stock/kline/get?fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause.; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=true; after_close_applies_to=akshare; retry_suggested=rerun_during_cn_trading_hours; retry_reason=AKShare minute endpoint failed outside CN continuous trading hours, market session may be a contributing factor, not a confirmed root cause. |
| 002463.SZ | tech_operation_candidates | — | yfinance | none | 002463 | 0.002463 | not_called | — | — | — | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.725459+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | False | — | — | — | provider_attempted=yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=false; after_close_applies_to=; retry_suggested=; retry_reason= |
| 002938.SZ | tech_operation_candidates | — | yfinance | none | 002938 | 0.002938 | not_called | — | — | — | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.725470+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | False | — | — | — | provider_attempted=yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=false; after_close_applies_to=; retry_suggested=; retry_reason= |
| 600183.SH | tech_operation_candidates | — | yfinance | none | 600183 | 1.600183 | not_called | — | — | — | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.725479+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | False | — | — | — | provider_attempted=yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=false; after_close_applies_to=; retry_suggested=; retry_reason= |
| 002281.SZ | tech_operation_candidates | — | yfinance | none | 002281 | 0.002281 | not_called | — | — | — | skipped | fallback_skipped_balanced_mode | — | — | — | — | skipped | yfinance_circuit_open | — | — | provider_skipped | not_available | 0 | — | 2026-06-04T11:10:21.725488+00:00 | provider_dependent | yfinance_circuit_open | cn_after_close | False | — | — | — | provider_attempted=yfinance; provider_success=none; yfinance_status=skipped; yfinance_reason=yfinance_circuit_open; yfinance_circuit_open=true; yfinance_circuit_reason=repeated_error; fallback_skipped_yfinance_circuit_open=true; eastmoney_status=skipped; eastmoney_reason=fallback_skipped_balanced_mode; market_session=cn_after_close; after_close_possible=false; after_close_applies_to=; retry_suggested=; retry_reason= |

## Scan Ranking Trace
| symbol | rankable | exclusion_reason | data_quality_inputs | momentum_inputs | field_quality_inputs | liquidity_inputs | reconciliation_inputs | final_score | priority | notes |
|---|---|---|---|---|---|---|---|---:|---|---|
|  | false | not_applicable |  |  |  |  |  |  | not_rankable | scan ranking not applicable for operation profile |

## prices_snapshot 关键明细摘要
| symbol | name | selected_provider/source | quote_purpose | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | price | currency | quote_time | is_stale | stale_reason | required_for_operation | operation_blocking_reason | reference_note |
|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | mock | reference | development | False | False | True | 1.432 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 513300.SH | 纳指ETF | mock | reference | development | False | False | True | 1.671 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 159819.SZ | 人工智能ETF | mock | reference | development | False | False | True | 0.921 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 515880.SH | 通信ETF | mock | reference | development | False | False | True | 1.084 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 159516.SZ | 半导体设备ETF | mock | reference | development | False | False | True | 0.756 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | True | mock_fallback_not_allowed |  |
| 510300.SH | 沪深300ETF | mock | reference | development | False | False | True | 3.921 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| GOLD_CNY | 黄金持仓参考价 | manual | reference | operation | True | False | False | 992.12 | CNY | 2026-05-22T14:38:00+08:00 | True | manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议 | True | stale |  |
| 159995.SZ | 芯片ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 588200.SH | 科创芯片ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 512480.SH | 半导体ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 588890.SH | 科创芯片相关ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 588170.SH | 科创半导体ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 159558.SZ | 半导体设备ETF易方达 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 515050.SH | 通信ETF华夏 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 159994.SZ | 通信ETF银华 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513180.SH | 恒生科技指数ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513130.SH | 恒生科技相关ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513150.SH | 港股互联网ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513020.SH | 港股科技互联网相关ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 002463.SZ | 沪电股份 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 002938.SZ | 鹏鼎控股 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600183.SH | 生益科技 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 002281.SZ | 光迅科技 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |

## Blocking / Error 摘要
### Blocking records
- project=tech, symbol=159632.SZ, name=纳指相关ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=513300.SH, name=纳指ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159819.SZ, name=人工智能ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=515880.SH, name=通信ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=159516.SZ, name=半导体设备ETF, source=mock_fallback, quote_time=2026-05-20T12:45:00+08:00, is_stale=True, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, blocking_reason=mock_fallback_not_allowed, function_name=, provider_status=, exception_type=
- project=tech, symbol=GOLD_CNY, name=黄金持仓参考价, source=manual, quote_time=2026-05-22T14:38:00+08:00, is_stale=True, stale_reason=manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议, blocking_reason=stale, function_name=, provider_status=, exception_type=

### provider_error
- provider_error: tech 159995.SZ 芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 588200.SH 科创芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 512480.SH 半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 588890.SH 科创芯片相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 588170.SH 科创半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 159558.SZ 半导体设备ETF易方达: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 515050.SH 通信ETF华夏: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 159994.SZ 通信ETF银华: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513180.SH 恒生科技指数ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513130.SH 恒生科技相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513150.SH 港股互联网ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513020.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 002463.SZ 沪电股份: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 002938.SZ 鹏鼎控股: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 600183.SH 生益科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 002281.SZ 光迅科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

### quote_time_missing
- quote_time_missing: tech 159995.SZ 芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588200.SH 科创芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 512480.SH 半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588890.SH 科创芯片相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588170.SH 科创半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 159558.SZ 半导体设备ETF易方达: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 515050.SH 通信ETF华夏: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 159994.SZ 通信ETF银华: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513180.SH 恒生科技指数ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513130.SH 恒生科技相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513150.SH 港股互联网ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513020.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002463.SZ 沪电股份: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002938.SZ 鹏鼎控股: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 600183.SH 生益科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002281.SZ 光迅科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

### invalid_price
- 无

### stale
- tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 510300.SH 沪深300ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech GOLD_CNY 黄金持仓参考价: manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议

### mock fallback not usable
- mock_fallback_not_allowed: tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 510300.SH 沪深300ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

### reference-only but operation requested
- 无

本排障包只用于定位 provider、runtime、freshness 和 blocking 问题。
