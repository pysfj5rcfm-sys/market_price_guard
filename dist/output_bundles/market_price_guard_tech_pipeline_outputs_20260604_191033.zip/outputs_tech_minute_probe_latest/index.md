# market_price_guard 本轮刷新索引

## 基本信息
- generated_at: 2026-06-04T11:10:21.725550+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_tech_minute_probe_latest
- quote_purpose: reference
- reconcile_mode: default
- universe_name: tech_minute_probe
- universe_type: minute_probe

## 本轮结论
- 可用于具体操作建议：否
- 本轮为快速参考模式。
- 可用于快速参考：是
- 不可用于具体操作建议。
- 如需具体执行动作或盘中价位，必须运行 operation-grade / strict 输出。
- strict blocking records 数量: 6
- provider_error 数量: 16
- stale 数量: 7
- quote_time_missing 数量: 16
- mock fallback not usable 数量: 6
- run_time_budget_exceeded: False

## Blocking Records 摘要
- project=tech, symbol=159632.SZ, name=纳指相关ETF, selected_provider=mock_fallback, blocking_reason=mock_fallback_not_allowed, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, quote_time=2026-05-20T12:45:00+08:00
- project=tech, symbol=513300.SH, name=纳指ETF, selected_provider=mock_fallback, blocking_reason=mock_fallback_not_allowed, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, quote_time=2026-05-20T12:45:00+08:00
- project=tech, symbol=159819.SZ, name=人工智能ETF, selected_provider=mock_fallback, blocking_reason=mock_fallback_not_allowed, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, quote_time=2026-05-20T12:45:00+08:00
- project=tech, symbol=515880.SH, name=通信ETF, selected_provider=mock_fallback, blocking_reason=mock_fallback_not_allowed, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, quote_time=2026-05-20T12:45:00+08:00
- project=tech, symbol=159516.SZ, name=半导体设备ETF, selected_provider=mock_fallback, blocking_reason=mock_fallback_not_allowed, stale_reason=mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed, quote_time=2026-05-20T12:45:00+08:00
- project=tech, symbol=GOLD_CNY, name=黄金持仓参考价, selected_provider=manual, blocking_reason=stale, stale_reason=manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议, quote_time=2026-05-22T14:38:00+08:00

## 核心价格覆盖摘要
- 能源账户核心价格：本轮未刷新
- 科技账户核心价格：不完整
- 黄金参考价：不可用
- 非科技宽基：不可用

## Quote trust summary
- current quote_purpose: reference
- operation-grade records 数量: 1
- reference-grade records 数量: 0
- development-grade records 数量: 22
- confirmation_required 数量: 22
- 可用于快速参考: 是
- 可用于具体操作建议: 否

## Reconciliation summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=5
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 运行时效摘要
- total_elapsed_seconds: 0.25
- max_quote_lag_seconds: 1319121.726
- run_time_budget_exceeded: False
- slow_provider_attempts 数量: 0
- provider calls: 0
- cache hits: 0
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-22T14:38:00+08:00

## Provider 摘要
- manual: 1
- mock: 22
- fallback_used 数量: 6
- mock fallback not usable 数量: 6

## 推荐复制给项目的文件
- 0_upload_bundle.md
- debug_bundle.md if blocking/provider_error/stale/quote_time_missing/major_diff/runtime issues appear

## 报告入口
- data_completeness_report.md
- provider_health_report.md
- runtime_diagnostics.md

本索引只汇总数据状态、可用性、阻断原因和建议查看的报告文件。
