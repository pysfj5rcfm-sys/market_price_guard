# Runtime Diagnostics

- run_start_time_utc: 2026-06-04T11:10:21.475286+00:00
- run_end_time_utc: 2026-06-04T11:10:21.725550+00:00
- total_elapsed_seconds: 0.25
- profile: tech
- provider_mode: live
- provider_policy: fast
- strict: False
- quote_purpose: reference
- reconcile_mode: default
- include_minute_bars: True
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: True
- yfinance_circuit_reason: repeated_error
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.041
- yfinance_attempted_count: 3
- yfinance_success_count: 0
- yfinance_error_count: 3
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 21
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 21
- yfinance_last_error: empty_response
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 0
- provider_runtime_budget_summary: none
- quote_cache_hit_count: 70
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 55
- quote_cache_success_hit_count: 15
- repeated_provider_call_prevented_count: 70
- universe_name: tech_minute_probe
- universe_type: minute_probe
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319121.726
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-22T14:38:00+08:00

## Provider Runtime Summary
- account: tech
- layer: tech_minute_probe
- total_elapsed_seconds: 0.25
- run_time_budget_exceeded: False
- slow_provider_attempts: 0
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 0

## per_provider_elapsed_seconds
- yfinance: 0.041

## Config Source / Layer Manifest
- layer_name: tech_minute_probe
- config_source_path: config/universes/tech_core.yaml+config/universes/tech_operation_candidates.yaml
- config_source_hash_sha256: 5a028ccc1d5b
- configured_symbol_count: 23
- loaded_symbol_count: 23
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 159632.SZ: 0.0
- 513300.SH: 0.0
- 159819.SZ: 0.0
- 515880.SH: 0.0
- 159516.SZ: 0.0
- 510300.SH: 0.0
- GOLD_CNY: 0.0
- 159995.SZ: 0.0
- 588200.SH: 0.0
- 512480.SH: 0.0
- 588890.SH: 0.0
- 588170.SH: 0.0
- 159558.SZ: 0.0
- 515050.SH: 0.0
- 159994.SZ: 0.0
- 513180.SH: 0.0
- 513130.SH: 0.0
- 513150.SH: 0.0
- 513020.SH: 0.0
- 002463.SZ: 0.0
- 002938.SZ: 0.0
- 600183.SH: 0.0
- 002281.SZ: 0.0

## slow_provider_attempts
- 无

## provider_call_cache
- total_provider_calls: 0
- cache_hits: 0
- provider_call_count_by_function: 无

## Cache / Reuse Summary
- quote_cache_hit_count: 70
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 55
- quote_cache_success_hit_count: 15
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 70
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 7
- cache_hit_by_layer: tech_core:8, tech_operation_candidates:15
- cache_hit_by_provider: manual:1, mock:22

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 0
- provider_budget_account: tech
- provider_budget_run_id: 2026-06-04T11:10:21.475286+00:00
- provider_circuit_open: {}
- provider_budget_by_provider: none
