# 科技账户价格事实块

仅为价格事实和新鲜度记录，不包含具体操作建议。

## 纳指 / 海外科技ETF
| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | 1.432 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |
| 513300.SH | 纳指ETF | 1.671 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

## AI / 人工智能ETF
| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 159819.SZ | 人工智能ETF | 0.921 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

## 通信 / 科技ETF
| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 515880.SH | 通信ETF | 1.084 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

## 黄金防守仓 / 潜在转科技资金
黄金持仓参考价为用户手工录入价，不等同于国际现货金价；用于科技账户防守仓/潜在转科技资金的参考，实际操作前需核对账户内可卖价、手续费、点差和到账规则。
| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| GOLD_CNY | 黄金持仓参考价 | 992.12 | CNY | manual | manual | 2026-05-22T14:38:00+08:00 | 2026-06-04T11:10:15.069406+00:00 | manual | True | manual 价格超过允许录入时间（MANUAL max_age_seconds），不可用于具体操作建议 | False | operation | True | False |

## 非科技宽基单独列示
| symbol | name | price | currency | source | selected_provider | quote_time | fetch_time | market_status | is_stale | stale_reason | usable_for_operation | quote_trust_tier | usable_for_reference | confirmation_required |
|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|
| 510300.SH | 沪深300ETF | 3.921 | CNY | mock_fallback | mock | 2026-05-20T12:45:00+08:00 | 2026-05-20T12:50:00+08:00 | closed | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | development | False | True |

## 基础行情字段 / Base Quote Fields
| symbol | name | last | chg% | open | high | low | prev | volume | amount | base | missing_fields |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| 159632.SZ | 纳指相关ETF | 1.432 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 513300.SH | 纳指ETF | 1.671 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159819.SZ | 人工智能ETF | 0.921 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 515880.SH | 通信ETF | 1.084 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159516.SZ | 半导体设备ETF | 0.756 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 510300.SH | 沪深300ETF | 3.921 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| GOLD_CNY | 黄金持仓参考价 | 992.12 | — | — | — | — | — | — | — | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159995.SZ | 芯片ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588200.SH | 科创芯片ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512480.SH | 半导体ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588890.SH | 科创芯片相关ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588170.SH | 科创半导体ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159558.SZ | 半导体设备ETF易方达 | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515050.SH | 通信ETF华夏 | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159994.SZ | 通信ETF银华 | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513180.SH | 恒生科技指数ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513130.SH | 恒生科技相关ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513150.SH | 港股互联网ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513020.SH | 港股科技互联网相关ETF | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002463.SZ | 沪电股份 | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002938.SZ | 鹏鼎控股 | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600183.SH | 生益科技 | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002281.SZ | 光迅科技 | — | — | — | — | — | — | — | — | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |

- volume/amount follow provider raw units unless unit normalization is explicitly available.
- 成交量/成交额暂按 provider 原始单位展示；未统一单位前不得直接跨 provider 排名。
