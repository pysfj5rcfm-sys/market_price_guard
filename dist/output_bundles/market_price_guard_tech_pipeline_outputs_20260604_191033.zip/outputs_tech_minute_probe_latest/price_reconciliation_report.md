# market_price_guard 多源价格差异检查报告

## 基本信息
- generated_at: 2026-06-04T11:10:21.725550+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- reconciliation_enabled: true

## 总结
- total_symbols: 5
- reconciled_symbols: 0
- single_source_only: 0
- aligned: 0
- minor_diff: 0
- warning_diff: 0
- major_diff: 0
- insufficient_data: 0
- provider_error: 5

## 每个 symbol 的比较表
| symbol | name | asset_role | compared_sources | selected_provider | reference_source | candidate_sources | prices_by_source | quote_times_by_source | max_price_diff_abs | max_price_diff_pct | max_quote_time_gap_seconds | source_agreement_status | operation_candidate_agreed | reconciliation_note |
|---|---|---|---|---|---|---|---|---|---:|---:|---:|---|---|---|
| 159632.SZ | 纳指相关ETF | nasdaq_or_overseas_tech_etf | akshare, eastmoney_direct | mock |  |  | akshare=; eastmoney_direct= | akshare=; eastmoney_direct= |  |  |  | provider_error | False | no comparable real provider quotes |
| 513300.SH | 纳指ETF | nasdaq_or_overseas_tech_etf | akshare, eastmoney_direct | mock |  |  | akshare=; eastmoney_direct= | akshare=; eastmoney_direct= |  |  |  | provider_error | False | no comparable real provider quotes |
| 159819.SZ | 人工智能ETF | ai_tech_equity | akshare, eastmoney_direct | mock |  |  | akshare=; eastmoney_direct= | akshare=; eastmoney_direct= |  |  |  | provider_error | False | no comparable real provider quotes |
| 515880.SH | 通信ETF | communication_tech_equity | akshare, eastmoney_direct | mock |  |  | akshare=; eastmoney_direct= | akshare=; eastmoney_direct= |  |  |  | provider_error | False | no comparable real provider quotes |
| 510300.SH | 沪深300ETF | non_tech_broad_base_etf | akshare, eastmoney_direct | mock |  |  | akshare=; eastmoney_direct= | akshare=; eastmoney_direct= |  |  |  | provider_error | False | no comparable real provider quotes |

## 使用边界
- Multi-source reconciliation is for data quality diagnostics only.
- It does not provide operation guidance.
- It does not automatically upgrade reference-grade data to operation-grade.
- Operation analysis still requires strict, freshness, quote_trust_tier, and usable_for_operation checks to pass.
