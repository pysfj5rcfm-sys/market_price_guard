# market_price_guard 上传包

## 基本信息
- generated_at: 2026-06-04T11:10:15.887726+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_tech_operation_candidates_latest
- universe_name: tech_operation_candidates
- universe_type: operation_candidate
- core_count: 0
- watchlist_count: 0
- scan_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: tech_operation_candidates
- config_source_path: config/universes/tech_operation_candidates.yaml
- config_source_hash_sha256: ab7caee01147
- configured_symbol_count: 19
- loaded_symbol_count: 19
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## 本轮结论
- 可用于快速参考：否
- 可用于具体操作建议：否
- 当前用途级别：reference-only
- confirmation_required 数量: 19
- blocking records 数量: 0

## 数据完整度摘要
- strict/exit_code: 0
- provider_error 数量: 16
- stale 数量: 3
- quote_time_missing 数量: 16
- invalid_price 数量: 16
- mock fallback not usable 数量: 3
- run_time_budget_exceeded: False

### Blocking records 摘要
- 无

## Quote Trust Tier 摘要
- operation-grade records 数量: 0
- reference-grade records 数量: 0
- development-grade records 数量: 19
- usable_for_reference=true 数量: 0
- usable_for_operation=true 数量: 0
- confirmation_required=true 数量: 19

## 基础行情快照 / Base Quote Snapshot
| symbol | name | last | chg% | open | high | low | prev | volume | amount | base | provider | tier | op? |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|
| 159819.SZ | 人工智能ETF | 0.921 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 515880.SH | 通信ETF | 1.084 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 159516.SZ | 半导体设备ETF | 0.756 | — | — | — | — | — | — | — | price_only | mock | development | False |
| 159995.SZ | 芯片ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 588200.SH | 科创芯片ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 512480.SH | 半导体ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 588890.SH | 科创芯片相关ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 588170.SH | 科创半导体ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 159558.SZ | 半导体设备ETF易方达 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 515050.SH | 通信ETF华夏 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 159994.SZ | 通信ETF银华 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 513180.SH | 恒生科技指数ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 513130.SH | 恒生科技相关ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 513150.SH | 港股互联网ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 513020.SH | 港股科技互联网相关ETF | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 002463.SZ | 沪电股份 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 002938.SZ | 鹏鼎控股 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 600183.SH | 生益科技 | — | — | — | — | — | — | — | — | missing | mock | development | False |
| 002281.SZ | 光迅科技 | — | — | — | — | — | — | — | — | missing | mock | development | False |
- base_quote_completeness is shown in the compact `base` column.

- volume/amount follow provider raw units unless unit normalization is explicitly available.
- 成交量/成交额暂按 provider 原始单位展示；未统一单位前不得直接跨 provider 排名。

## 字段质量提示 / Field Quality Notes
- volume/amount are shown in provider raw units unless explicitly validated.
- cross-provider volume/amount comparison is unsafe in this version.
- bid/ask, turnover_rate, minute_bars, VWAP and QDII premium are not validated or not implemented.
- See debug_bundle.md and provider_capability_report.md for details.

## Operation Candidate Summary
- universe_name: tech_operation_candidates
- universe_type: operation_candidate
- total_candidates: 19
- ready_for_review: 0
- data_incomplete: 3
- provider_error: 16
- symbol_not_found: 0
- registry_missing: 0
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations.

## Reconciliation Summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=2
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 项目核心内容
### Operation candidates

These are pre-trade verification candidates, not core holdings and not operation-grade.
They do not affect tech_fast_strict or outputs_tech_latest.
This output is not operation guidance.

- universe_name: tech_operation_candidates
- universe_type: operation_candidate
- quote_purpose: reference
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations

## Operation Candidate Summary
- universe_name: tech_operation_candidates
- universe_type: operation_candidate
- total_candidates: 19
- ready_for_review: 0
- data_incomplete: 3
- provider_error: 16
- symbol_not_found: 0
- registry_missing: 0
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations.

## Candidate Data Status
| symbol | name | operation_candidate | candidate_quote_ready | candidate_data_status | candidate_blocking_reason | candidate_next_step | required_for_operation | affect_core_strict | usable_for_operation | usable_for_reference | provider | rankable | rank_exclusion_reason |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 159819.SZ | 人工智能ETF | True | False | data_incomplete | stale | run_reconcile | False | False | False | False | mock | False |  |
| 515880.SH | 通信ETF | True | False | data_incomplete | stale | run_reconcile | False | False | False | False | mock | False |  |
| 159516.SZ | 半导体设备ETF | True | False | data_incomplete | stale | run_reconcile | False | False | False | False | mock | False |  |
| 159995.SZ | 芯片ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 588200.SH | 科创芯片ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 512480.SH | 半导体ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 588890.SH | 科创芯片相关ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 588170.SH | 科创半导体ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 159558.SZ | 半导体设备ETF易方达 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 515050.SH | 通信ETF华夏 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 159994.SZ | 通信ETF银华 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 513180.SH | 恒生科技指数ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 513130.SH | 恒生科技相关ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 513150.SH | 港股互联网ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 513020.SH | 港股科技互联网相关ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 002463.SZ | 沪电股份 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 002938.SZ | 鹏鼎控股 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600183.SH | 生益科技 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 002281.SZ | 光迅科技 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |

## Safety Notes
- Operation candidates are reference-only pre-check records.
- A candidate must be explicitly promoted to core holdings before it can be part of the tech fast strict path.
- Candidate provider failures do not block core operation.
- No operation guidance is generated.

## Universe isolation
- universe_name: tech_operation_candidates
- universe_type: operation_candidate
- core strict pollution isolation: enabled
- this universe is not used for core operation strict blocking.
- not usable for concrete operation recommendations.

## Reference / Operation 使用提示
- 本轮为快速参考模式。
- 可以用于快速参考。
- 不可用于具体操作建议。
- 不可给出具体执行动作、盘中高频判断或执行参数参数。
- 如需具体操作，请运行 operation 输出或补充有效盘口信息。

## Debug 提示
- 如出现 strict=2、blocking records、provider_error、quote_time_missing、invalid_price、stale、selected_provider=mock、fallback_used 异常、run_time_budget_exceeded、slow_provider_attempts、quote_time 可疑或报告冲突，请补充 debug_bundle.md。
- 本上传包只汇总数据状态、可用性和阻断原因。
