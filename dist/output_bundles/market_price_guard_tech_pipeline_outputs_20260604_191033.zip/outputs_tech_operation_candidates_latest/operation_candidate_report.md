# Tech Operation Candidate Report

These are pre-trade verification candidates, not core holdings and not operation-grade.
They do not affect tech_fast_strict or outputs_tech_latest.
This output is not operation guidance.

- universe_name: tech_operation_candidates
- universe_type: operation_candidate
- quote_purpose: reference
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations

## Operation Candidate Summary
- universe_name: tech_operation_candidates
- universe_type: operation_candidate
- total_candidates: 19
- ready_for_review: 0
- data_incomplete: 3
- provider_error: 16
- symbol_not_found: 0
- registry_missing: 0
- required_for_operation: false
- usable_for_operation: false
- affect_core_strict: false
- not usable for concrete operation recommendations.

## Candidate Data Status
| symbol | name | operation_candidate | candidate_quote_ready | candidate_data_status | candidate_blocking_reason | candidate_next_step | required_for_operation | affect_core_strict | usable_for_operation | usable_for_reference | provider | rankable | rank_exclusion_reason |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 159819.SZ | 人工智能ETF | True | False | data_incomplete | stale | run_reconcile | False | False | False | False | mock | False |  |
| 515880.SH | 通信ETF | True | False | data_incomplete | stale | run_reconcile | False | False | False | False | mock | False |  |
| 159516.SZ | 半导体设备ETF | True | False | data_incomplete | stale | run_reconcile | False | False | False | False | mock | False |  |
| 159995.SZ | 芯片ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 588200.SH | 科创芯片ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 512480.SH | 半导体ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 588890.SH | 科创芯片相关ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 588170.SH | 科创半导体ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 159558.SZ | 半导体设备ETF易方达 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 515050.SH | 通信ETF华夏 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 159994.SZ | 通信ETF银华 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 513180.SH | 恒生科技指数ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 513130.SH | 恒生科技相关ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 513150.SH | 港股互联网ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 513020.SH | 港股科技互联网相关ETF | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 002463.SZ | 沪电股份 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 002938.SZ | 鹏鼎控股 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 600183.SH | 生益科技 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |
| 002281.SZ | 光迅科技 | True | False | provider_error | provider_error | fix_provider | False | False | False | False | mock | False |  |

## Safety Notes
- Operation candidates are reference-only pre-check records.
- A candidate must be explicitly promoted to core holdings before it can be part of the tech fast strict path.
- Candidate provider failures do not block core operation.
- No operation guidance is generated.
