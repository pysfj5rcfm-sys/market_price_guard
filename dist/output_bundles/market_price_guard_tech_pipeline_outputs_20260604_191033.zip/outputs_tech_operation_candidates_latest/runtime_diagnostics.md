# Runtime Diagnostics

- run_start_time_utc: 2026-06-04T11:10:15.839031+00:00
- run_end_time_utc: 2026-06-04T11:10:15.887726+00:00
- total_elapsed_seconds: 0.049
- profile: tech
- provider_mode: live
- provider_policy: fast
- strict: False
- quote_purpose: reference
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: 
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 0
- provider_runtime_budget_summary: none
- quote_cache_hit_count: 47
- quote_cache_miss_count: 40
- quote_cache_failure_hit_count: 39
- quote_cache_success_hit_count: 8
- repeated_provider_call_prevented_count: 47
- universe_name: tech_operation_candidates
- universe_type: operation_candidate
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319115.888
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-20T12:45:00+08:00

## Provider Runtime Summary
- account: tech
- layer: tech_operation_candidates
- total_elapsed_seconds: 0.049
- run_time_budget_exceeded: False
- slow_provider_attempts: 0
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 0

## per_provider_elapsed_seconds
- yfinance: 0.0

## Config Source / Layer Manifest
- layer_name: tech_operation_candidates
- config_source_path: config/universes/tech_operation_candidates.yaml
- config_source_hash_sha256: ab7caee01147
- configured_symbol_count: 19
- loaded_symbol_count: 19
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 159819.SZ: 0.0
- 515880.SH: 0.0
- 159516.SZ: 0.0
- 159995.SZ: 0.0
- 588200.SH: 0.0
- 512480.SH: 0.0
- 588890.SH: 0.0
- 588170.SH: 0.0
- 159558.SZ: 0.0
- 515050.SH: 0.0
- 159994.SZ: 0.0
- 513180.SH: 0.0
- 513130.SH: 0.0
- 513150.SH: 0.0
- 513020.SH: 0.0
- 002463.SZ: 0.0
- 002938.SZ: 0.0
- 600183.SH: 0.0
- 002281.SZ: 0.0

## slow_provider_attempts
- 无

## provider_call_cache
- total_provider_calls: 0
- cache_hits: 0
- provider_call_count_by_function: 无

## Cache / Reuse Summary
- quote_cache_hit_count: 47
- quote_cache_miss_count: 40
- quote_cache_failure_hit_count: 39
- quote_cache_success_hit_count: 8
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 47
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 0
- cache_hit_by_layer: tech_operation_candidates:19
- cache_hit_by_provider: mock:19

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 0
- provider_budget_account: tech
- provider_budget_run_id: 2026-06-04T11:10:15.839031+00:00
- provider_circuit_open: {}
- provider_budget_by_provider: none
