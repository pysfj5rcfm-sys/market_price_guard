# market_price_guard Reference Intraday Metrics Index

- generated_at: 2026-06-04T11:10:22.170490+00:00
- profile: tech
- output_type: reference_intraday_metrics
- strict: false
- total_symbols: 27
- vwap_calculable_count: 0

## Files
- 0_upload_bundle.md
- intraday_metrics_snapshot.csv
- reference_vwap_report.md
- debug_bundle.md
- data_completeness_report.md
- provider_capability_report.md
- runtime_diagnostics.md
