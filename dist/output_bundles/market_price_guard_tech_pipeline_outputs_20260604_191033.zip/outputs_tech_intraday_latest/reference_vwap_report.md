# Reference VWAP Report

## Purpose / Scope
- This report calculates reference VWAP and basic intraday position metrics from minute probe output.
- VWAP is reference-only.
- It is not a trading signal.
- It does not upgrade operation readiness.
- It does not replace QDII premium or IOPV checks.
- For QDII ETFs, the premium module is still required before operation-level evaluation.
- usable_for_operation belongs to core price/operation context, not intraday VWAP availability.

## Source Priority
1. AKShare
2. Eastmoney Direct
3. YFinance reference fallback

## Core Holdings
| symbol | name | provider | bars | ref_vwap | last | dist_vwap_pct | pos_pct | spot_align | status | note |
|---|---|---|---:|---:|---:|---:|---:|---|---|---|
| 159632.SZ | 纳指相关ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513300.SH | 纳指ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159819.SZ | 人工智能ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 515880.SH | 通信ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159516.SZ | 半导体设备ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 510300.SH | 沪深300ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| GOLD_CNY | 黄金持仓参考价 | missing | 0 |  |  |  |  | unknown | not_supported | manual_price_only; intraday_not_supported |
| 159995.SZ | 芯片ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |

## Operation Candidates
| symbol | name | provider | bars | ref_vwap | last | dist_vwap_pct | pos_pct | spot_align | status | note |
|---|---|---|---:|---:|---:|---:|---:|---|---|---|
| 159819.SZ | 人工智能ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 515880.SH | 通信ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159516.SZ | 半导体设备ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159995.SZ | 芯片ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 588200.SH | 科创芯片ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 512480.SH | 半导体ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 588890.SH | 科创芯片相关ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 588170.SH | 科创半导体ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159558.SZ | 半导体设备ETF易方达 | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 515050.SH | 通信ETF华夏 | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159994.SZ | 通信ETF银华 | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513180.SH | 恒生科技指数ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513130.SH | 恒生科技相关ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513150.SH | 港股互联网ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513020.SH | 港股科技互联网相关ETF | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 002463.SZ | 沪电股份 | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 002938.SZ | 鹏鼎控股 | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 600183.SH | 生益科技 | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 002281.SZ | 光迅科技 | missing | 0 |  |  |  |  | unknown | no_minute_bars | no_minute_bars |

## Not Calculable
| symbol | name | status | support_status | missing_reason | note |
|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_error: provider_error; provider=yfinance |
| 513300.SH | 纳指ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159819.SZ | 人工智能ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 515880.SH | 通信ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159516.SZ | 半导体设备ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 510300.SH | 沪深300ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| GOLD_CNY | 黄金持仓参考价 | not_supported | manual_not_supported | manual_price_only | manual_price_only |
| 159995.SZ | 芯片ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159819.SZ | 人工智能ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 515880.SH | 通信ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159516.SZ | 半导体设备ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159995.SZ | 芯片ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 588200.SH | 科创芯片ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 512480.SH | 半导体ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 588890.SH | 科创芯片相关ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 588170.SH | 科创半导体ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159558.SZ | 半导体设备ETF易方达 | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 515050.SH | 通信ETF华夏 | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159994.SZ | 通信ETF银华 | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 513180.SH | 恒生科技指数ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 513130.SH | 恒生科技相关ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 513150.SH | 港股互联网ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 513020.SH | 港股科技互联网相关ETF | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 002463.SZ | 沪电股份 | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 002938.SZ | 鹏鼎控股 | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 600183.SH | 生益科技 | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 002281.SZ | 光迅科技 | no_minute_bars | no_minute_bars | no_minute_bars | provider_skipped: yfinance_circuit_open; provider=yfinance |

## Data Quality Notes
- provider_raw_count: 0
- provider_dependent_count: 0
- amount/volume units remain provider artifacts; this module uses close-volume weighting unless native amount/volume confidence is explicit.
- Spot quotes are displayed for alignment checks; distance to reference VWAP uses minute-bar latest close.

## Safety Notes
- Reference intraday metrics do not change strict.
- Reference intraday metrics do not change quote_trust_tier or usable_for_operation.
- No trading advice is generated.
