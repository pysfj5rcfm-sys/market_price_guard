# Intraday Metrics Data Completeness Report

- total_symbols: 27
- core_symbols: 8
- operation_candidate_symbols: 19
- vwap_calculable_count: 0
- no_minute_bars_count: 26
- zero_volume_count: 0
- manual_not_supported_count: 1
- provider_raw_count: 0
- provider_dependent_count: 0
- akshare_count: 0
- eastmoney_count: 0
- yfinance_count: 0
- spot_stale_minute_fresh_count: 0
- aligned_count: 0
- minute_stale_count: 0

## Config Source / Layer Manifest
- layer_name: tech_intraday_metrics
- config_source_path: derived_from_outputs_tech_minute_probe_latest
- config_source_hash_sha256: 
- configured_symbol_count: 23
- loaded_symbol_count: 27
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

Derived intraday fields are reference-only and do not change operation readiness.
