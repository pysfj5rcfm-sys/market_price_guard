# Runtime Diagnostics

- generated_at: 2026-06-04T11:10:22.170490+00:00
- provider_calls: 0
- note: intraday metrics read existing CSV artifacts only.

## Config Source / Layer Manifest
- layer_name: tech_intraday_metrics
- config_source_path: derived_from_outputs_tech_minute_probe_latest
- config_source_hash_sha256: 
- configured_symbol_count: 23
- loaded_symbol_count: 27
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false
