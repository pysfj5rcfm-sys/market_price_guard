# market_price_guard Reference Intraday Upload Bundle

## Basic Info
- profile: tech
- output_type: reference_intraday_metrics
- strict: false
- purpose: reference-only
- generated_at: 2026-06-04T11:10:22.170490+00:00
- source_minute_file: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_minute_probe_latest/minute_bars_snapshot.csv

## Config Source / Layer Manifest
- layer_name: tech_intraday_metrics
- config_source_path: derived_from_outputs_tech_minute_probe_latest
- config_source_hash_sha256: 
- configured_symbol_count: 23
- loaded_symbol_count: 27
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Safety Note
- Reference VWAP is not operation-grade.
- Intraday metrics do not change strict or usable_for_operation.
- No trading advice is generated.

## Reference Intraday Summary
| symbol | name | universe | provider | validation | bars | latest_time | ref_vwap | last | dist_vwap_pct | pos_pct | spot_align | support | note |
|---|---|---|---|---|---:|---|---:|---:|---:|---:|---|---|---|
| 159632.SZ | 纳指相关ETF | tech_core | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513300.SH | 纳指ETF | tech_core | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159819.SZ | 人工智能ETF | tech_core | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 515880.SH | 通信ETF | tech_core | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159516.SZ | 半导体设备ETF | tech_core | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 510300.SH | 沪深300ETF | tech_core | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| GOLD_CNY | 黄金持仓参考价 | tech_core | missing | not_supported | 0 |  |  |  |  |  | unknown | manual_not_supported | manual_price_only; intraday_not_supported |
| 159995.SZ | 芯片ETF | tech_core | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159819.SZ | 人工智能ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 515880.SH | 通信ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159516.SZ | 半导体设备ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159995.SZ | 芯片ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 588200.SH | 科创芯片ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 512480.SH | 半导体ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 588890.SH | 科创芯片相关ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 588170.SH | 科创半导体ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159558.SZ | 半导体设备ETF易方达 | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 515050.SH | 通信ETF华夏 | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 159994.SZ | 通信ETF银华 | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513180.SH | 恒生科技指数ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513130.SH | 恒生科技相关ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513150.SH | 港股互联网ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 513020.SH | 港股科技互联网相关ETF | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 002463.SZ | 沪电股份 | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 002938.SZ | 鹏鼎控股 | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 600183.SH | 生益科技 | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
| 002281.SZ | 光迅科技 | tech_operation_candidates | missing | not_calculable | 0 |  |  |  |  |  | unknown | no_minute_bars | no_minute_bars |
