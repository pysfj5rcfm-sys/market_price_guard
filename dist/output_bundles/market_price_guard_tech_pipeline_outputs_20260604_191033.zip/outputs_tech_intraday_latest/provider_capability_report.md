# Provider Capability Report

## Intraday Metrics Capability
- AKShare minute bars are treated as provider_raw reference data when available.
- Eastmoney Direct minute bars are provider-dependent reference data when available.
- YFinance minute bars are provider-dependent reference fallback data.
- Reference VWAP does not upgrade operation readiness.

## Source Counts
- akshare: 0
- eastmoney_direct: 0
- yfinance: 0
