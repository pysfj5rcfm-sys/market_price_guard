# Intraday Metrics Debug Bundle

- source_minute_file: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_minute_probe_latest/minute_bars_snapshot.csv
- tech_spot_file: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_latest/prices_snapshot.csv
- operation_candidate_spot_file: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_operation_candidates_latest/prices_snapshot.csv

## Config Source / Layer Manifest
- layer_name: tech_intraday_metrics
- config_source_path: derived_from_outputs_tech_minute_probe_latest
- config_source_hash_sha256: 
- configured_symbol_count: 23
- loaded_symbol_count: 27
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Calculation Trace
| symbol | source_universe | minute_rows | valid_rows | invalid_rows | volume_sum | vwap_method | high | low | last | spot_time | minute_time | alignment | reason |
|---|---|---:|---:|---:|---:|---|---:|---:|---:|---|---|---|---|
| 159632.SZ | tech_core | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_error: provider_error; provider=yfinance |
| 513300.SH | tech_core | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159819.SZ | tech_core | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 515880.SH | tech_core | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159516.SZ | tech_core | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 510300.SH | tech_core | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| GOLD_CNY | tech_core | 0 | 0 | 0 |  |  |  |  |  | 2026-05-22 14:38:00+08:00 |  | unknown | manual_price_only |
| 159995.SZ | tech_core | 0 | 0 | 0 |  |  |  |  |  |  |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159819.SZ | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 515880.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159516.SZ | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | 2026-05-20 12:45:00+08:00 |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159995.SZ | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 588200.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 512480.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 588890.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 588170.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159558.SZ | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 515050.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 159994.SZ | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 513180.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 513130.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 513150.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 513020.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 002463.SZ | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 002938.SZ | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 600183.SH | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
| 002281.SZ | tech_operation_candidates | 0 | 0 | 0 |  |  |  |  |  | nan |  | unknown | provider_skipped: yfinance_circuit_open; provider=yfinance |
