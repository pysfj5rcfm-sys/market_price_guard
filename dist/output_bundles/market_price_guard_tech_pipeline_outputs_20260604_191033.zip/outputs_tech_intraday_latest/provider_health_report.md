# Provider Health Report

This intraday report reads existing minute probe artifacts and does not call providers.
- symbols_with_reference_vwap: 0
- symbols_without_minute_bars: 26
