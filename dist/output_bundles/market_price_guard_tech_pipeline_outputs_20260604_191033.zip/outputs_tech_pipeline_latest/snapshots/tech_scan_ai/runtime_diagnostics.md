# Runtime Diagnostics

- run_start_time_utc: 2026-06-04T11:10:10.003391+00:00
- run_end_time_utc: 2026-06-04T11:10:15.087084+00:00
- total_elapsed_seconds: 5.084
- profile: tech
- provider_mode: live
- provider_policy: fast
- strict: False
- quote_purpose: reference
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: disabled_in_fast_mode
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: 
- provider_timeout_count: 3
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 0
- provider_runtime_budget_summary: akshare:attempts=3,elapsed=4.953,slow=0,failed=3; eastmoney_direct:attempts=3,elapsed=0.049,slow=0,failed=3; manual:attempts=1,elapsed=0.0,slow=0,failed=0; mock:attempts=9,elapsed=0.021,slow=0,failed=3
- quote_cache_hit_count: 0
- quote_cache_miss_count: 40
- quote_cache_failure_hit_count: 0
- quote_cache_success_hit_count: 0
- repeated_provider_call_prevented_count: 0
- universe_name: tech_scan_ai
- universe_type: scan_universe
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319115.087
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-22T14:38:00+08:00

## Provider Runtime Summary
- account: tech
- layer: tech_scan_ai
- total_elapsed_seconds: 5.084
- run_time_budget_exceeded: False
- slow_provider_attempts: 0
- provider_timeout_count: 3
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 94

## per_provider_elapsed_seconds
- akshare: 4.953
- eastmoney_direct: 0.049
- mock: 0.021
- manual: 0.0
- yfinance: 0.0

## Config Source / Layer Manifest
- layer_name: tech_scan_ai
- config_source_path: config/universes/tech_scan_ai.yaml
- config_source_hash_sha256: fbbad0890e41
- configured_symbol_count: 40
- loaded_symbol_count: 40
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 159632.SZ: 4.982
- 513300.SH: 0.017
- 159819.SZ: 0.012
- 515880.SH: 0.002
- 159516.SZ: 0.002
- 510300.SH: 0.002
- GOLD_CNY: 0.0
- 512480.SH: 0.002
- 159995.SZ: 0.002
- 588200.SH: 0.002
- 588890.SH: 0.0
- 588170.SH: 0.0
- 159558.SZ: 0.0
- 513310.SH: 0.0
- 515050.SH: 0.0
- 159994.SZ: 0.0
- 300308.SZ: 0.0
- 300502.SZ: 0.0
- 688256.SH: 0.0
- 588760.SH: 0.0
- 588930.SH: 0.0
- 159363.SZ: 0.0
- 516510.SH: 0.0
- 515980.SH: 0.0
- 513180.SH: 0.0
- 513130.SH: 0.0
- 513150.SH: 0.0
- 513020.SH: 0.0
- 159792.SZ: 0.0
- 513320.SH: 0.0
- 002463.SZ: 0.0
- 002938.SZ: 0.0
- 600183.SH: 0.0
- 603228.SH: 0.0
- 002281.SZ: 0.0
- 515000.SH: 0.0
- 512930.SH: 0.0
- 300476.SZ: 0.0
- 002916.SZ: 0.0
- 300394.SZ: 0.0

## slow_provider_attempts
- 无

## provider_call_cache
- total_provider_calls: 1
- cache_hits: 2
- provider_call_count_by_function:
  - fund_etf_spot_em: 1

## Cache / Reuse Summary
- quote_cache_hit_count: 0
- quote_cache_miss_count: 40
- quote_cache_failure_hit_count: 0
- quote_cache_success_hit_count: 0
- batch_cache_hit_count: 2
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 2
- batch_provider_failure_cached_count: 3
- repeated_provider_call_prevented_count: 0
- repeated_batch_call_prevented_count: 2
- quote_cache_profile_insufficient_count: 0
- cache_hit_by_layer: none
- cache_hit_by_provider: none

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 91
- provider_budget_account: tech
- provider_budget_run_id: 2026-06-04T11:10:10.003391+00:00
- provider_circuit_open: {'akshare': 'skipped_by_provider_circuit', 'eastmoney_direct': 'skipped_by_provider_circuit', 'mock': 'skipped_by_provider_circuit'}
- provider_budget_by_provider:
  - akshare: attempts=3, elapsed_seconds=4.953, slow_attempts=0, failed_attempts=3
  - eastmoney_direct: attempts=3, elapsed_seconds=0.049, slow_attempts=0, failed_attempts=3
  - manual: attempts=1, elapsed_seconds=0.0, slow_attempts=0, failed_attempts=0
  - mock: attempts=9, elapsed_seconds=0.021, slow_attempts=0, failed_attempts=3
