# market_price_guard 上传包

## 基本信息
- generated_at: 2026-06-04T11:10:15.087084+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_tech_scan_ai_latest
- universe_name: tech_scan_ai
- universe_type: scan_universe
- core_count: 0
- watchlist_count: 0
- scan_count: 40
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: tech_scan_ai
- config_source_path: config/universes/tech_scan_ai.yaml
- config_source_hash_sha256: fbbad0890e41
- configured_symbol_count: 40
- loaded_symbol_count: 40
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## 本轮结论
- 可用于快速参考：是
- 可用于具体操作建议：否
- 当前用途级别：reference-only
- confirmation_required 数量: 40
- blocking records 数量: 0

## 数据完整度摘要
- strict/exit_code: 0
- provider_error 数量: 33
- stale 数量: 7
- quote_time_missing 数量: 33
- invalid_price 数量: 33
- mock fallback not usable 数量: 6
- run_time_budget_exceeded: False

### Blocking records 摘要
- 无

## Quote Trust Tier 摘要
- operation-grade records 数量: 0
- reference-grade records 数量: 1
- development-grade records 数量: 39
- usable_for_reference=true 数量: 1
- usable_for_operation=true 数量: 0
- confirmation_required=true 数量: 40

## 基础行情快照 / Base Quote Snapshot
| symbol | name | tags | last | chg% | amount | base | data_status | provider | note |
|---|---|---|---:|---:|---:|---|---|---|---|
| 159632.SZ | 纳指相关ETF | watchlist, etf, core, nasdaq, qdii, operation, premium_compare, scan, tech_core, tech, overseas | 1.432 | — | — | price_only | price_only | mock | scan_only |
| 513300.SH | 纳指ETF | watchlist, etf, core, nasdaq, qdii, operation, premium_compare, scan, tech_core, tech, overseas | 1.671 | — | — | price_only | price_only | mock | scan_only |
| 159819.SZ | 人工智能ETF | watchlist, ai, etf, core, computing_power, operation, candidate, scan, artificial_intelligence, tech, tech_core, operation_candidate, layer3 | 0.921 | — | — | price_only | price_only | mock | scan_only |
| 515880.SH | 通信ETF | watchlist, etf, core, cpo, operation, candidate, layer2, scan, tech_core, tech, operation_candidate, optical_module, communication | 1.084 | — | — | price_only | price_only | mock | scan_only |
| 159516.SZ | 半导体设备ETF | failed_trial_observation, watchlist, semiconductor, etf, layer1, core, equipment, operation, candidate, semiconductor_equipment, scan, tech_core, tech, operation_candidate | 0.756 | — | — | price_only | price_only | mock | scan_only |
| 510300.SH | 沪深300ETF | broad_base, operation, scan, non_tech, hs300, tech_core | 3.921 | — | — | price_only | price_only | mock | scan_only |
| GOLD_CNY | 黄金持仓参考价 | core, defense, gold, operation, scan, tech_core, tech | 992.12 | — | — | price_only | price_only | manual | scan_only |
| 512480.SH | 半导体ETF | watchlist, semiconductor, etf, layer1, candidate, chip, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 159995.SZ | 芯片ETF | watchlist, semiconductor, etf, layer1, candidate, chip, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 588200.SH | 科创芯片ETF | watchlist, semiconductor, etf, layer1, candidate, chip, scan, tech, sci_tech_chip, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 588890.SH | 科创芯片相关ETF | watchlist, semiconductor, etf, layer1, name_needs_provider_validation, candidate, scan, tech, sci_tech_chip, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 588170.SH | 科创半导体ETF | watchlist, semiconductor, etf, layer1, sci_tech_semiconductor, candidate, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 159558.SZ | 半导体设备ETF易方达 | watchlist, semiconductor, etf, layer1, equipment, semiconductor_equipment, candidate, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 513310.SH | 中韩半导体ETF | semiconductor, etf, qdii, layer4, cross_border, scan, tech, korea_semiconductor | — | — | — | missing | provider_error | mock | provider_error |
| 515050.SH | 通信ETF华夏 | watchlist, etf, 5g, cpo, name_needs_provider_validation, candidate, layer2, scan, tech, operation_candidate, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 159994.SZ | 通信ETF银华 | watchlist, etf, cpo, candidate, layer2, scan, tech, operation_candidate, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 300308.SZ | 中际旭创 | watchlist, cpo, layer2, stock, ai_infrastructure, scan, tech, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 300502.SZ | 新易盛 | watchlist, cpo, layer2, stock, ai_infrastructure, scan, tech, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 688256.SH | 寒武纪 | watchlist, ai, semiconductor, computing_power, stock, scan, tech, ai_chip, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 588760.SH | 科创人工智能ETF广发 | ai, etf, artificial_intelligence, scan, sci_tech_ai, tech, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 588930.SH | 科创AI相关ETF | ai, etf, name_needs_provider_validation, artificial_intelligence, scan, sci_tech_ai, tech, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 159363.SZ | 创业板人工智能ETF | ai, etf, computing_power, name_needs_provider_validation, artificial_intelligence, scan, sci_tech_ai, tech, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 516510.SH | 云计算ETF | etf, computing_power, cloud, scan, ai_infrastructure, tech, cloud_computing, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 515980.SH | 人工智能相关ETF | ai, etf, computing_power, name_needs_provider_validation, artificial_intelligence, scan, tech, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 513180.SH | 恒生科技指数ETF | watchlist, etf, qdii, layer4, candidate, cross_border, hk_tech, scan, tech, operation_candidate, hang_seng_tech | — | — | — | missing | provider_error | mock | provider_error |
| 513130.SH | 恒生科技相关ETF | watchlist, etf, qdii, layer4, name_needs_provider_validation, candidate, cross_border, hk_tech, scan, tech, operation_candidate, hang_seng_tech | — | — | — | missing | provider_error | mock | provider_error |
| 513150.SH | 港股互联网ETF | watchlist, etf, hk_internet, qdii, layer4, candidate, cross_border, hk_tech, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 513020.SH | 港股科技互联网相关ETF | watchlist, etf, hk_internet, qdii, layer4, name_needs_provider_validation, candidate, cross_border, hk_tech, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 159792.SZ | 港股通互联网相关ETF | etf, hk_internet, layer4, name_needs_provider_validation, cross_border, hk_tech, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 513320.SH | 港股科技互联网相关ETF | watchlist, etf, hk_internet, qdii, layer4, name_needs_provider_validation, cross_border, hk_tech, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 002463.SZ | 沪电股份 | watchlist, ai_pcb, event_watch, candidate, server_pcb, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 002938.SZ | 鹏鼎控股 | watchlist, server_chain, pcb, candidate, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 600183.SH | 生益科技 | watchlist, ai_pcb, server_chain, event_watch, pcb_material, candidate, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 603228.SH | 景旺电子 | pcb, watchlist, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 002281.SZ | 光迅科技 | watchlist, event_watch, cpo, candidate, scan, tech, operation_candidate, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 515000.SH | 科技ETF华宝 | watchlist, etf, science_technology, broad_tech, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 512930.SH | AI人工智能ETF平安 | watchlist, ai, etf, scan, artificial_intelligence, tech | — | — | — | missing | provider_error | mock | provider_error |
| 300476.SZ | 胜宏科技 | ai_pcb, server_pcb, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 002916.SZ | 深南电路 | server_pcb, ai_pcb, tech, scan | — | — | — | missing | provider_error | mock | provider_error |
| 300394.SZ | 天孚通信 | cpo, scan, tech, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
- candidate/watchlist/scan records do not affect core strict.
- symbol_not_found in candidate or scan output is a data coverage status, not a system failure.
- not usable for concrete operation recommendations.

## 字段质量提示 / Field Quality Notes
- volume/amount are shown in provider raw units unless explicitly validated.
- cross-provider volume/amount comparison is unsafe in this version.
- bid/ask, turnover_rate, minute_bars, VWAP and QDII premium are not validated or not implemented.
- See debug_bundle.md and provider_capability_report.md for details.

## Scan Runtime / Coverage Policy
- scan_mode: fast
- stock_fast_path_enabled: true
- stock_fast_provider: eastmoney_direct
- yfinance_fallback_policy: disabled_in_fast_mode
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- eastmoney_direct_stock_attempted_count: 11
- eastmoney_direct_stock_success_count: 0
- eastmoney_direct_stock_error_count: 11
- stock_reference_coverage_count: 0
- stock_reference_missing_count: 11
- provider_timeout_count: 3
- fallback_skipped_fast_mode_count: 11
- slow_symbol_count: 0
- run_time_budget_exceeded: False

## 扫描优先级摘要 / Scan Priority Summary
| priority | count | note |
|---|---:|---|
| high | 0 | review candidates only |
| medium | 0 | reference candidates |
| low | 0 | weak or incomplete |
| not_rankable | 40 | data unavailable / provider issue |

## Top Scan Candidates
| rank | symbol | name | score | priority | chg% | base | provider | note |
|---:|---|---|---:|---|---:|---|---|---|
|  |  |  |  | not_rankable |  | missing |  | no rankable records |

- Scan ranking is not operation guidance.
- Reference-only does not mean operation-ready.
- Operation decisions require operation-grade guard output.
- Candidate/watchlist/scan records do not affect core strict.
- volume/amount unit normalization is not complete.
- minute bars / VWAP / QDII premium are not implemented.

## Reconciliation Summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=5
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 项目核心内容
### Scan universe

Scan universe records are for opportunity observation and data completeness checks only. They do not affect core operation strict.

- universe_name: tech_scan_ai
- universe_type: scan_universe
- scan_mode: fast
- stock_fast_path_enabled: true
- stock_fast_provider: eastmoney_direct
- data_status: price_change_pct/amount/volume may be missing in this version.

- scan_mode: fast
- stock_fast_path_enabled: true
- stock_fast_provider: eastmoney_direct
- yfinance_fallback_policy: disabled_in_fast_mode
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- eastmoney_direct_stock_attempted_count: 11
- eastmoney_direct_stock_success_count: 0
- eastmoney_direct_stock_error_count: 11
- stock_reference_coverage_count: 0
- stock_reference_missing_count: 11
- provider_timeout_count: 3
- fallback_skipped_fast_mode_count: 11
- slow_symbol_count: 0
- run_time_budget_exceeded: False

| symbol | name | role | report_group | price | source | quote_time | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | source_agreement_status | data_status | note |
|---|---|---|---|---:|---|---|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | nasdaq_or_overseas_tech_etf | 纳指 / 海外科技ETF | 1.432 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | 科技账户核心纳指相关 ETF; current holding; nasdaq primary anchor; QDII premium must be checked externally until premium module is implemented |
| 513300.SH | 纳指ETF | nasdaq_or_overseas_tech_etf | 纳指 / 海外科技ETF | 1.671 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | current holding; nasdaq anchor but include priority lower than 159632 unless premium is materially better |
| 159819.SZ | 人工智能ETF | ai_tech_equity | AI / 人工智能ETF | 0.921 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | already in tech core; included in scan universe for comparison only; current holding; AI second observation satellite; candidate only after AI group resonance and support confirmation |
| 515880.SH | 通信ETF | communication_tech_equity | 通信 / 科技ETF | 1.084 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | already in tech core; included in scan universe for comparison only; current holding; communication/CPO first observation satellite; candidate only after pullback/support confirmation |
| 159516.SZ | 半导体设备ETF | semiconductor_equipment_core_etf | 半导体 / 科创芯片 / 半导体设备 | 0.756 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True |  | check_required | current holding; failed trial observation position; retained in operation_candidate only as restricted observation; restricted observation, not a repair candidate; any new trade requires full re-evaluation |
| 510300.SH | 沪深300ETF | non_tech_broad_base_etf | 非科技宽基单独列示 | 3.921 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | current holding; non-tech broad-base risk appetite reference; not a tech budget candidate |
| GOLD_CNY | 黄金持仓参考价 | defense_or_potential_tech_funding | 黄金防守仓 / 潜在转科技资金 | 992.12 | manual | 2026-05-22T14:38:00+08:00 | reference | True | False | True |  | ok | manual reference only; defensive/potential tech funding; does not overwrite formal gold asset amount; no intraday VWAP support |
| 512480.SH | 半导体ETF | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; existing candidate expanded into layer1; 半导体整体强弱验证；可作为新交易候选 |
| 159995.SZ | 芯片ETF | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; existing candidate expanded into layer1; 芯片方向强弱验证；可作为新交易候选 |
| 588200.SH | 科创芯片ETF | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; existing candidate expanded into layer1; 科创芯片弹性验证；可作为新交易候选 |
| 588890.SH | 科创芯片相关ETF | candidate_tech_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider |
| 588170.SH | 科创半导体ETF | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 科创半导体强弱验证；当前不列入candidate，可用于同组验证 |
| 159558.SZ | 半导体设备ETF易方达 | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 159516同类设备验证；不得用于补159516；不作为当前candidate |
| 513310.SH | 中韩半导体ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border semiconductor ETF; premium/reference module not yet available |
| 515050.SH | 通信ETF华夏 | operation_validator_etf | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 同组验证；若明显强于515880且同组共振，才作为候选；不默认买 |
| 159994.SZ | 通信ETF银华 | operation_validator_etf | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 同组验证；若明显强于515880且同组共振，才作为候选；不默认买 |
| 300308.SZ | 中际旭创 | scan_candidate_stock | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | single-stock scan candidate; not ETF; do not compare raw volume/amount directly with ETFs |
| 300502.SZ | 新易盛 | scan_candidate_stock | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | single-stock scan candidate; not ETF; do not compare raw volume/amount directly with ETFs |
| 688256.SH | 寒武纪 | scan_candidate_stock | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | single-stock scan candidate; not ETF; do not compare raw volume/amount directly with ETFs |
| 588760.SH | 科创人工智能ETF广发 | operation_validator_etf | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 科创AI验证；若明显强于159819且AI同组共振，才作为候选 |
| 588930.SH | 科创AI相关ETF | candidate_tech_etf | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider |
| 159363.SZ | 创业板人工智能ETF | operation_validator_etf | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; AI弹性验证；若明显强于159819且AI同组共振，才作为候选 |
| 516510.SH | 云计算ETF | candidate_tech_etf | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider |
| 515980.SH | 人工智能相关ETF | candidate_tech_etf | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider |
| 513180.SH | 恒生科技指数ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK tech scan candidate; premium module not yet available |
| 513130.SH | 恒生科技相关ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK tech scan candidate; fund name should be validated by provider |
| 513150.SH | 港股互联网ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK internet scan candidate; premium module not yet available |
| 513020.SH | 港股科技互联网相关ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK tech scan candidate; fund name should be validated by provider |
| 159792.SZ | 港股通互联网相关ETF | scan_candidate_hk_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | scan candidate; verify whether QDII or HK-stock-connect ETF |
| 513320.SH | 港股科技互联网相关ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK tech scan candidate; fund name should be validated by provider |
| 002463.SZ | 沪电股份 | event_watch_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | operation-fly review observation only; not candidate by default; requires user authorization and event-position state machine; now user-selected operation_candidate; event_stock_candidate_warning; requires event state-machine review; policy override is user-driven, not operation guidance |
| 002938.SZ | 鹏鼎控股 | scan_candidate_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | PCB/server chain scan only; not candidate by default; now user-selected operation_candidate/watchlist; PCB/server chain strength verification; policy warning only |
| 600183.SH | 生益科技 | event_watch_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | AI PCB/materials event-watch candidate; policy warning only; not default operation guidance; now user-selected operation_candidate/watchlist; AI PCB/materials event-watch candidate; policy warning only |
| 603228.SH | 景旺电子 | scan_candidate_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | PCB scan only; not candidate by default |
| 002281.SZ | 光迅科技 | event_watch_stock | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | CPO/optical module event-watch candidate; policy warning only; not default operation guidance; now user-selected operation_candidate/watchlist; CPO/optical module strength verification; policy warning only |
| 515000.SH | 科技ETF华宝 | candidate_tech_etf | 科技宽基 / AI / 算力扩散 |  | mock |  | development | False | False | True |  | check_required | broad technology ETF watch/scan candidate; not operation-grade |
| 512930.SH | AI人工智能ETF平安 | candidate_tech_etf | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | AI artificial intelligence ETF watch/scan candidate; not operation-grade |
| 300476.SZ | 胜宏科技 | scan_candidate_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | AI PCB strength verification only; not default operation object |
| 002916.SZ | 深南电路 | scan_candidate_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | AI PCB/server PCB scan only; not candidate by default |
| 300394.SZ | 天孚通信 | scan_candidate_stock | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | CPO/optical device strength verification only; not default operation object |

# Scan Universe Basic Ranking
- This is a review-priority ranking, not operation guidance.
- It does not produce execution instructions.
- Operation decisions require operation-grade price guard output.
- volume/amount are not used for cross-provider liquidity ranking unless comparable flags allow it.

## Scan Summary
- total_symbols: 40
- rankable_count: 0
- not_rankable_count: 40
- high_priority_count: 0
- medium_priority_count: 0
- low_priority_count: 0
- symbol_not_found_count: 0
- provider_issue_count: 34
- data_insufficient_count: 0
- exclusion reasons: development_only:6, provider_error:33, stale_reference:1
- ranking does not affect strict.

## Basic Ranking Table
| rank | symbol | name | tags | score | priority | last | chg% | base | data_quality | momentum | field_quality | liquidity | reconciliation | provider | status | note |
|---:|---|---|---|---:|---|---:|---:|---|---:|---:|---:|---:|---:|---|---|---|
|  |  |  |  |  | not_rankable |  |  | missing |  |  |  |  |  |  | not_rankable | no rankable records |

## Not Rankable
| symbol | name | reason | provider_status | suggested_next_step |
|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | development_only | success | keep as candidate; does not affect core strict |
| 513300.SH | 纳指ETF | development_only | success | keep as candidate; does not affect core strict |
| 159819.SZ | 人工智能ETF | development_only | success | keep as candidate; does not affect core strict |
| 515880.SH | 通信ETF | development_only | success | keep as candidate; does not affect core strict |
| 159516.SZ | 半导体设备ETF | development_only | success | keep as candidate; does not affect core strict |
| 510300.SH | 沪深300ETF | development_only | success | keep as candidate; does not affect core strict |
| GOLD_CNY | 黄金持仓参考价 | stale_reference | success | keep as candidate; does not affect core strict |
| 512480.SH | 半导体ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 159995.SZ | 芯片ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 588200.SH | 科创芯片ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 588890.SH | 科创芯片相关ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 588170.SH | 科创半导体ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 159558.SZ | 半导体设备ETF易方达 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 513310.SH | 中韩半导体ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 515050.SH | 通信ETF华夏 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 159994.SZ | 通信ETF银华 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 300308.SZ | 中际旭创 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 300502.SZ | 新易盛 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 688256.SH | 寒武纪 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 588760.SH | 科创人工智能ETF广发 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 588930.SH | 科创AI相关ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 159363.SZ | 创业板人工智能ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 516510.SH | 云计算ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 515980.SH | 人工智能相关ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 513180.SH | 恒生科技指数ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 513130.SH | 恒生科技相关ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 513150.SH | 港股互联网ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 513020.SH | 港股科技互联网相关ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 159792.SZ | 港股通互联网相关ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 513320.SH | 港股科技互联网相关ETF | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 002463.SZ | 沪电股份 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 002938.SZ | 鹏鼎控股 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 600183.SH | 生益科技 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 603228.SH | 景旺电子 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 002281.SZ | 光迅科技 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 515000.SH | 科技ETF华宝 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 512930.SH | AI人工智能ETF平安 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 300476.SZ | 胜宏科技 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 002916.SZ | 深南电路 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |
| 300394.SZ | 天孚通信 | provider_error | provider_error,skipped_by_provider_circuit | keep as candidate; review provider_health/debug details |

## Compact Base Quote Table
| symbol | name | tags | last | chg% | amount | base | data_status | provider | note |
|---|---|---|---:|---:|---:|---|---|---|---|
| 159632.SZ | 纳指相关ETF | watchlist, etf, core, nasdaq, qdii, operation, premium_compare, scan, tech_core, tech, overseas | 1.432 | — | — | price_only | price_only | mock | scan_only |
| 513300.SH | 纳指ETF | watchlist, etf, core, nasdaq, qdii, operation, premium_compare, scan, tech_core, tech, overseas | 1.671 | — | — | price_only | price_only | mock | scan_only |
| 159819.SZ | 人工智能ETF | watchlist, ai, etf, core, computing_power, operation, candidate, scan, artificial_intelligence, tech, tech_core, operation_candidate, layer3 | 0.921 | — | — | price_only | price_only | mock | scan_only |
| 515880.SH | 通信ETF | watchlist, etf, core, cpo, operation, candidate, layer2, scan, tech_core, tech, operation_candidate, optical_module, communication | 1.084 | — | — | price_only | price_only | mock | scan_only |
| 159516.SZ | 半导体设备ETF | failed_trial_observation, watchlist, semiconductor, etf, layer1, core, equipment, operation, candidate, semiconductor_equipment, scan, tech_core, tech, operation_candidate | 0.756 | — | — | price_only | price_only | mock | scan_only |
| 510300.SH | 沪深300ETF | broad_base, operation, scan, non_tech, hs300, tech_core | 3.921 | — | — | price_only | price_only | mock | scan_only |
| GOLD_CNY | 黄金持仓参考价 | core, defense, gold, operation, scan, tech_core, tech | 992.12 | — | — | price_only | price_only | manual | scan_only |
| 512480.SH | 半导体ETF | watchlist, semiconductor, etf, layer1, candidate, chip, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 159995.SZ | 芯片ETF | watchlist, semiconductor, etf, layer1, candidate, chip, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 588200.SH | 科创芯片ETF | watchlist, semiconductor, etf, layer1, candidate, chip, scan, tech, sci_tech_chip, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 588890.SH | 科创芯片相关ETF | watchlist, semiconductor, etf, layer1, name_needs_provider_validation, candidate, scan, tech, sci_tech_chip, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 588170.SH | 科创半导体ETF | watchlist, semiconductor, etf, layer1, sci_tech_semiconductor, candidate, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 159558.SZ | 半导体设备ETF易方达 | watchlist, semiconductor, etf, layer1, equipment, semiconductor_equipment, candidate, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 513310.SH | 中韩半导体ETF | semiconductor, etf, qdii, layer4, cross_border, scan, tech, korea_semiconductor | — | — | — | missing | provider_error | mock | provider_error |
| 515050.SH | 通信ETF华夏 | watchlist, etf, 5g, cpo, name_needs_provider_validation, candidate, layer2, scan, tech, operation_candidate, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 159994.SZ | 通信ETF银华 | watchlist, etf, cpo, candidate, layer2, scan, tech, operation_candidate, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 300308.SZ | 中际旭创 | watchlist, cpo, layer2, stock, ai_infrastructure, scan, tech, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 300502.SZ | 新易盛 | watchlist, cpo, layer2, stock, ai_infrastructure, scan, tech, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 688256.SH | 寒武纪 | watchlist, ai, semiconductor, computing_power, stock, scan, tech, ai_chip, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 588760.SH | 科创人工智能ETF广发 | ai, etf, artificial_intelligence, scan, sci_tech_ai, tech, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 588930.SH | 科创AI相关ETF | ai, etf, name_needs_provider_validation, artificial_intelligence, scan, sci_tech_ai, tech, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 159363.SZ | 创业板人工智能ETF | ai, etf, computing_power, name_needs_provider_validation, artificial_intelligence, scan, sci_tech_ai, tech, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 516510.SH | 云计算ETF | etf, computing_power, cloud, scan, ai_infrastructure, tech, cloud_computing, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 515980.SH | 人工智能相关ETF | ai, etf, computing_power, name_needs_provider_validation, artificial_intelligence, scan, tech, layer3 | — | — | — | missing | provider_error | mock | provider_error |
| 513180.SH | 恒生科技指数ETF | watchlist, etf, qdii, layer4, candidate, cross_border, hk_tech, scan, tech, operation_candidate, hang_seng_tech | — | — | — | missing | provider_error | mock | provider_error |
| 513130.SH | 恒生科技相关ETF | watchlist, etf, qdii, layer4, name_needs_provider_validation, candidate, cross_border, hk_tech, scan, tech, operation_candidate, hang_seng_tech | — | — | — | missing | provider_error | mock | provider_error |
| 513150.SH | 港股互联网ETF | watchlist, etf, hk_internet, qdii, layer4, candidate, cross_border, hk_tech, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 513020.SH | 港股科技互联网相关ETF | watchlist, etf, hk_internet, qdii, layer4, name_needs_provider_validation, candidate, cross_border, hk_tech, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 159792.SZ | 港股通互联网相关ETF | etf, hk_internet, layer4, name_needs_provider_validation, cross_border, hk_tech, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 513320.SH | 港股科技互联网相关ETF | watchlist, etf, hk_internet, qdii, layer4, name_needs_provider_validation, cross_border, hk_tech, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 002463.SZ | 沪电股份 | watchlist, ai_pcb, event_watch, candidate, server_pcb, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 002938.SZ | 鹏鼎控股 | watchlist, server_chain, pcb, candidate, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 600183.SH | 生益科技 | watchlist, ai_pcb, server_chain, event_watch, pcb_material, candidate, scan, tech, operation_candidate | — | — | — | missing | provider_error | mock | provider_error |
| 603228.SH | 景旺电子 | pcb, watchlist, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 002281.SZ | 光迅科技 | watchlist, event_watch, cpo, candidate, scan, tech, operation_candidate, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |
| 515000.SH | 科技ETF华宝 | watchlist, etf, science_technology, broad_tech, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 512930.SH | AI人工智能ETF平安 | watchlist, ai, etf, scan, artificial_intelligence, tech | — | — | — | missing | provider_error | mock | provider_error |
| 300476.SZ | 胜宏科技 | ai_pcb, server_pcb, scan, tech | — | — | — | missing | provider_error | mock | provider_error |
| 002916.SZ | 深南电路 | server_pcb, ai_pcb, tech, scan | — | — | — | missing | provider_error | mock | provider_error |
| 300394.SZ | 天孚通信 | cpo, scan, tech, optical_module, communication | — | — | — | missing | provider_error | mock | provider_error |

## Base Quote Summary
- base_quote_completeness counts:
- missing: 33
- price_only: 7
- missing fields top: amount:40, high_price:40, low_price:40, open_price:40, prev_close:40, volume:40, last_price:33
- base quote fields are auxiliary diagnostics; missing fields do not change existing strict in this version.

| symbol | base_quote_completeness | available | missing | missing_fields |
|---|---|---:|---:|---|
| 159632.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 513300.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159819.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 515880.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159516.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 510300.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| GOLD_CNY | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 512480.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159995.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588200.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588890.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588170.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159558.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513310.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515050.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159994.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300308.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300502.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 688256.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588760.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588930.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159363.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 516510.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515980.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513180.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513130.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513150.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513020.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159792.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513320.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002463.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002938.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600183.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603228.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002281.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515000.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512930.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300476.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002916.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300394.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |

## Provider Coverage / Failure Reasons
| symbol | registry_found | provider_attempted | provider_status | data_status | likely_reason | suggested_next_step |
|---|---|---|---|---|---|---|
| 159632.SZ | True | akshare,eastmoney_direct,mock | success | price_only | provider_timeout | keep as candidate; does not affect core strict |
| 513300.SH | True | akshare,eastmoney_direct,mock | success | price_only | provider_timeout | keep as candidate; does not affect core strict |
| 159819.SZ | True | akshare,eastmoney_direct,mock | success | price_only | provider_timeout | keep as candidate; does not affect core strict |
| 515880.SH | True | akshare,eastmoney_direct,mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 159516.SZ | True | eastmoney_direct,akshare,mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 510300.SH | True | akshare,eastmoney_direct,mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| GOLD_CNY | True | manual | success | price_only | reference_available | keep as candidate; does not affect core strict |
| 512480.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 159995.SZ | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 588200.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 588890.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 588170.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 159558.SZ | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513310.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 515050.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 159994.SZ | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 300308.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 300502.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 688256.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 588760.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 588930.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 159363.SZ | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 516510.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 515980.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513180.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513130.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513150.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513020.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 159792.SZ | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513320.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002463.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002938.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600183.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 603228.SH | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002281.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 515000.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 512930.SH | True | eastmoney_direct,akshare,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 300476.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002916.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 300394.SZ | True | eastmoney_direct,mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |

## Safety Notes

- Scan ranking is not operation guidance.
- Reference-only does not mean operation-ready.
- Operation decisions require operation-grade guard output.
- Candidate/watchlist/scan records do not affect core strict.
- volume/amount unit normalization is not complete.
- minute bars / VWAP / QDII premium are not implemented.

## Universe isolation
- universe_name: tech_scan_ai
- universe_type: scan_universe
- core strict pollution isolation: enabled
- this universe is not used for core operation strict blocking.
- not usable for concrete operation recommendations.

## Reference / Operation 使用提示
- 本轮为快速参考模式。
- 可以用于快速参考。
- 不可用于具体操作建议。
- 不可给出具体执行动作、盘中高频判断或执行参数参数。
- 如需具体操作，请运行 operation 输出或补充有效盘口信息。

## Debug 提示
- 如出现 strict=2、blocking records、provider_error、quote_time_missing、invalid_price、stale、selected_provider=mock、fallback_used 异常、run_time_budget_exceeded、slow_provider_attempts、quote_time 可疑或报告冲突，请补充 debug_bundle.md。
- 本上传包只汇总数据状态、可用性和阻断原因。
