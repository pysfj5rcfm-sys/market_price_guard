# market_price_guard 排障包

## 基本信息
- generated_at: 2026-06-04T11:10:15.520291+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_tech_watchlist_latest
- universe_name: tech_watchlist
- universe_type: candidate_watchlist

## Symbol Registry Resolution 摘要
- registry_enabled: true
- registry_path: /Users/chenyulin/Documents/AIProjects/market_price_guard/config/symbol_registry.yaml
- universe_name: tech_watchlist
- universe_type: candidate_watchlist
- core_count: 0
- watchlist_count: 28
- scan_count: 0
- operation_candidate_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: tech_watchlist
- config_source_path: config/universes/tech_watchlist.yaml
- config_source_hash_sha256: 409e0b30b112
- configured_symbol_count: 28
- loaded_symbol_count: 28
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Provider Health 摘要
- provider_policy: fast
- provider_mode: live
- 无

### Provider attempts
### 159632.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: none
- normalized_symbol: 159632.SZ
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### 513300.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: none
- normalized_symbol: 513300.SH
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### 159819.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: none
- normalized_symbol: 159819.SZ
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### 515880.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: akshare=skipped_by_provider_circuit, eastmoney_direct=skipped_by_provider_circuit
- normalized_symbol: 515880.SH
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: True
- source_agreement_status: provider_error
- operation_candidate_agreed: False
- attempts: 无
### 159516.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit
- normalized_symbol: 159516.SZ
- route_reason: configured_provider_route:reference
- selected_provider: mock
- selected_source: mock_fallback
- fallback_used: True
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: mock_fallback_not_allowed_for_operation
- final_blocking_reason: mock_fallback_not_allowed
- provider_failure_reason: mock/development only
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 159995.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit
- normalized_symbol: 159995.SZ
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 588200.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit
- normalized_symbol: 588200.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 512480.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit
- normalized_symbol: 512480.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 588890.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 588890.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 588170.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 588170.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 159558.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 159558.SZ
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 515050.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 515050.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 159994.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 159994.SZ
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 688256.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 688256.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 300308.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 300308.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 300502.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 300502.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513180.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513180.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513130.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513130.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513020.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513020.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513150.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513150.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 513320.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 513320.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 002463.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 002463.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 002938.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 002938.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 600183.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 600183.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 603228.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 603228.SH
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 002281.SZ
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 002281.SZ
- route_reason: account_generic_a_share_stock_route
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 515000.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 515000.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无
### 512930.SH
- provider_policy: fast
- configured_provider_priority: eastmoney_direct, yfinance, akshare, mock
- provider_planned_chain: eastmoney_direct, yfinance, akshare, mock
- effective_provider_chain: eastmoney_direct, yfinance, akshare, mock
- actual_provider_attempted: 
- provider_skip_reasons: eastmoney_direct=skipped_by_provider_circuit, akshare=skipped_by_provider_circuit, mock=skipped_by_provider_circuit
- normalized_symbol: 512930.SH
- route_reason: configured_provider_route:reference
- selected_provider: 
- selected_source: mock
- fallback_used: False
- usable_for_operation: False
- quote_trust_tier: development
- usable_for_reference: False
- confirmation_required: True
- selection_reason: all_provider_attempts_failed
- final_blocking_reason: provider_error
- provider_failure_reason: endpoint_failed
- reconciliation_enabled: False
- source_agreement_status: 
- operation_candidate_agreed: False
- attempts: 无

## Runtime Diagnostics 摘要
- run_start_time_utc: 2026-06-04T11:10:15.469071+00:00
- run_end_time_utc: 2026-06-04T11:10:15.520291+00:00
- total_elapsed_seconds: 0.051
- profile: tech
- provider_mode: live
- provider_policy: fast
- strict: False
- quote_purpose: reference
- reconcile_mode: default
- include_minute_bars: False
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- future_quote_tolerance_seconds: 120
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_total_elapsed_seconds: 0.0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- selected_provider_success_policy_skip_count: 0
- base_quote_yfinance_skipped_by_circuit_count: 0
- minute_yfinance_skipped_by_circuit_count: 0
- yfinance_last_error: 
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- slow_provider_attempts_count: 0
- provider_runtime_budget_summary: none
- quote_cache_hit_count: 28
- quote_cache_miss_count: 40
- quote_cache_failure_hit_count: 23
- quote_cache_success_hit_count: 5
- repeated_provider_call_prevented_count: 28
- universe_name: tech_watchlist
- universe_type: candidate_watchlist
- layer_config_mismatch: False
- run_time_budget_exceeded: False
- runtime_warning_level: runtime_info
- runtime_warning_reason: within_runtime_policy
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true
- max_run_seconds: 30.0
- max_data_lag_seconds: 300.0
- max_quote_lag_seconds: 1319115.52
- oldest_quote_time: 2026-05-20T12:45:00+08:00
- newest_quote_time: 2026-05-20T12:45:00+08:00

## Provider Runtime Summary
- account: tech
- layer: tech_watchlist
- total_elapsed_seconds: 0.051
- run_time_budget_exceeded: False
- slow_provider_attempts: 0
- provider_timeout_count: 0
- provider_skipped_by_runtime_budget_count: 0
- provider_circuit_open_count: 0

## per_provider_elapsed_seconds
- yfinance: 0.0

## Config Source / Layer Manifest
- layer_name: tech_watchlist
- config_source_path: config/universes/tech_watchlist.yaml
- config_source_hash_sha256: 409e0b30b112
- configured_symbol_count: 28
- loaded_symbol_count: 28
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## per_symbol_elapsed_seconds
- 159632.SZ: 0.0
- 513300.SH: 0.0
- 159819.SZ: 0.0
- 515880.SH: 0.0
- 159516.SZ: 0.0
- 159995.SZ: 0.0
- 588200.SH: 0.0
- 512480.SH: 0.0
- 588890.SH: 0.0
- 588170.SH: 0.0
- 159558.SZ: 0.0
- 515050.SH: 0.0
- 159994.SZ: 0.0
- 688256.SH: 0.0
- 300308.SZ: 0.0
- 300502.SZ: 0.0
- 513180.SH: 0.0
- 513130.SH: 0.0
- 513020.SH: 0.0
- 513150.SH: 0.0
- 513320.SH: 0.0
- 002463.SZ: 0.0
- 002938.SZ: 0.0
- 600183.SH: 0.0
- 603228.SH: 0.0
- 002281.SZ: 0.0
- 515000.SH: 0.0
- 512930.SH: 0.0

## slow_provider_attempts
- 无

## provider_call_cache
- total_provider_calls: 0
- cache_hits: 0
- provider_call_count_by_function: 无

## Cache / Reuse Summary
- quote_cache_hit_count: 28
- quote_cache_miss_count: 40
- quote_cache_failure_hit_count: 23
- quote_cache_success_hit_count: 5
- batch_cache_hit_count: 0
- batch_cache_miss_count: 0
- batch_provider_reuse_count: 0
- batch_provider_failure_cached_count: 0
- repeated_provider_call_prevented_count: 28
- repeated_batch_call_prevented_count: 0
- quote_cache_profile_insufficient_count: 0
- cache_hit_by_layer: tech_watchlist:28
- cache_hit_by_provider: mock:28

## provider_runtime_budget
- provider_skipped_by_runtime_budget_count: 0
- provider_skipped_by_failure_budget_count: 0
- provider_skipped_by_circuit_count: 0
- provider_budget_account: tech
- provider_budget_run_id: 2026-06-04T11:10:15.469071+00:00
- provider_circuit_open: {}
- provider_budget_by_provider: none

## Price Reconciliation 摘要
- full report: price_reconciliation_report.md
- 159632.SZ: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 513300.SH: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 159819.SZ: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 515880.SH: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes

## Base Quote Fields Summary
| symbol | last | prev_close | open | high | low | volume | amount | change | change_pct | amplitude_pct | completeness | missing_fields | field_sources | exchange | country_market | trading_calendar |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|
| 159632.SZ | 1.432 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 513300.SH | 1.671 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159819.SZ | 0.921 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 515880.SH | 1.084 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159516.SZ | 0.756 |  |  |  |  |  |  |  |  |  | price_only | prev_close,open_price,high_price,low_price,volume,amount | last=mock,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 159995.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 588200.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 512480.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 588890.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 588170.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159558.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 515050.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 159994.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 688256.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 300308.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 300502.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 513180.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 513130.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 513020.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 513150.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 513320.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 002463.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 002938.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 600183.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 603228.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 002281.SZ |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SZ | CN | CN_A_SHARE |
| 515000.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |
| 512930.SH |  |  |  |  |  |  |  |  |  |  | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount | last=missing,prev=missing,open=missing,high=missing,low=missing,volume=missing,amount=missing,change_pct=missing | SH | CN | CN_A_SHARE |

## Base Quote Field Sources
| symbol | last_source | prev_source | open_source | high_source | low_source | volume_source | amount_source | chg_source | completeness | missing_fields |
|---|---|---|---|---|---|---|---|---|---|---|
| 159632.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 513300.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159819.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 515880.SH | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159516.SZ | mock | missing | missing | missing | missing | missing | missing | missing | price_only | prev_close,open_price,high_price,low_price,volume,amount |
| 159995.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588200.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512480.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588890.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588170.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159558.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515050.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159994.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 688256.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300308.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300502.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513180.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513130.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513020.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513150.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513320.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002463.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002938.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600183.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603228.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002281.SZ | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515000.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512930.SH | missing | missing | missing | missing | missing | missing | missing | missing | missing | last_price,prev_close,open_price,high_price,low_price,volume,amount |

## Provider Capability Summary
- full report: provider_capability_report.md
| provider | function_name | asset_type | base_price_fields | volume_amount_status | bid_ask_status | turnover_status | minute_status | operation_fit | notes |
|---|---|---|---|---|---|---|---|---|---|
| akshare | fund_etf_spot_em | ETF, QDII_ETF, A_SHARE_ETF | supported_or_calculable | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | Operation fit still depends on quote_trust_tier, strict, freshness, and provider health. |
| akshare | stock_spot_em | A_SHARE, HK_STOCK | mixed:missing,supported | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | A/H stock endpoint availability is environment-dependent. |
| akshare | fund_etf_hist_min_em | ETF, QDII_ETF, A_SHARE_ETF | missing | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | supported_if_endpoint_succeeds | diagnostic_only | ETF minute bars probe via AKShare; does not upgrade operation readiness. |
| eastmoney_direct | stock_get | ETF, A_SHARE_ETF, A_SHARE | mixed:calculable,supported_when_endpoint_succeeds | volume=supported_raw_unit; amount=supported_raw_unit | bid1=not_validated; ask1=not_validated | not_validated | attempted_provider_dependent | False | Reference / operation-candidate only; endpoint stability is not guaranteed. |
| yfinance | ticker_quote | ETF, HK_STOCK, A_SHARE, A_SHARE_ETF, INDEX | mixed:missing,provider_dependent,supported | volume=supported_raw_unit; amount=missing | bid1=missing_or_not_validated; ask1=missing_or_not_validated | missing | attempted_reference_fallback | reference_only | Open-source Yahoo Finance wrapper; not an official exchange feed. |
| manual | manual_price | MANUAL, GOLD | mixed:missing,supported | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | not_supported | conditional | Manual reference price; no market depth fields. |
| mock | mock_quote | TEST | mixed:missing,supported_for_tests | volume=supported_for_tests; amount=supported_for_tests | bid1=not_applicable; ask1=not_applicable | not_applicable | supported_for_tests | False | Development/testing only. |

### Current field quality risks
- raw_provider_unit records: 0
- unit_unknown records: 0
- volume_comparable_across_providers=false records: 28
- amount_comparable_across_providers=false records: 28
- bid/ask not validated; turnover_rate not validated; minute_bars/VWAP/QDII premium not implemented.

## Provider Capability Notes
AKShare:
- base quote fields: supported/partially supported through current normalized fields where provider raw fields are available.
- volume: raw provider unit.
- amount: raw provider unit or unit_unknown.
- bid/ask: not validated.
- turnover_rate: not validated.
- minute_bars: available through minute_probe when supported; reference-only and not operation-grade.

Eastmoney Direct:
- base quote fields: available only when endpoint succeeds.
- trust tier: reference / operation-candidate only.
- stability: unstable in current environment.
- bid/ask: not validated.
- minute_bars: available through minute_probe fallback when supported; reference-only and not operation-grade.

yfinance:
- base quote fields: reference-only for current ETF/watchlist usage.
- volume: raw provider unit.
- not operation-grade for A-share ETF operation path.
- timestamp/precision may differ from local exchange feeds.
- minute_bars: available as reference fallback through minute_probe when supported; provider_dependent and not operation-grade.

Capability label note:
- diagnostic_only in provider capability means capability label only; actual fallback behavior is controlled by minute_mode.

manual:
- GOLD_CNY price only.
- base_quote_completeness usually price_only.
- minute_bars: not supported.

mock:
- development/testing only.
- mock minute bars can be generated for tests when minute probe is enabled.
- not valid for real market decisions.

## Scan Ranking Trace
| symbol | rankable | exclusion_reason | data_quality_inputs | momentum_inputs | field_quality_inputs | liquidity_inputs | reconciliation_inputs | final_score | priority | notes |
|---|---|---|---|---|---|---|---|---:|---|---|
| 159632.SZ | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement=provider_error | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 513300.SH | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement=provider_error | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 159819.SZ | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement=provider_error | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 515880.SH | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement=provider_error | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 159516.SZ | False | development_only | base=price_only; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 159995.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 588200.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 512480.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 588890.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 588170.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 159558.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 515050.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 159994.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 688256.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 300308.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 300502.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 513180.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 513130.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 513020.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 513150.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 513320.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 002463.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 002938.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 600183.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 603228.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 002281.SZ | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 515000.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| 512930.SH | False | provider_error | base=missing; stale=True; reference=False | price_change_pct=— | status=development_only; provider_capability=configured | volume_comp=False; amount_comp=False; volume_unit=not_applicable; amount_unit=not_applicable | agreement= | — | not_rankable | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |

## prices_snapshot 关键明细摘要
| symbol | name | selected_provider/source | quote_purpose | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | price | currency | quote_time | is_stale | stale_reason | required_for_operation | operation_blocking_reason | reference_note |
|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | mock | reference | development | False | False | True | 1.432 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 513300.SH | 纳指ETF | mock | reference | development | False | False | True | 1.671 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 159819.SZ | 人工智能ETF | mock | reference | development | False | False | True | 0.921 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 515880.SH | 通信ETF | mock | reference | development | False | False | True | 1.084 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 159516.SZ | 半导体设备ETF | mock | reference | development | False | False | True | 0.756 | CNY | 2026-05-20T12:45:00+08:00 | True | mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed | False | mock_fallback_not_allowed |  |
| 159995.SZ | 芯片ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 588200.SH | 科创芯片ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 512480.SH | 半导体ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 588890.SH | 科创芯片相关ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 588170.SH | 科创半导体ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 159558.SZ | 半导体设备ETF易方达 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 515050.SH | 通信ETF华夏 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 159994.SZ | 通信ETF银华 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 688256.SH | 寒武纪 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 300308.SZ | 中际旭创 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 300502.SZ | 新易盛 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513180.SH | 恒生科技指数ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513130.SH | 恒生科技相关ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513020.SH | 港股科技互联网相关ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513150.SH | 港股互联网ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 513320.SH | 港股科技互联网相关ETF | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 002463.SZ | 沪电股份 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 002938.SZ | 鹏鼎控股 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 600183.SH | 生益科技 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 603228.SH | 景旺电子 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 002281.SZ | 光迅科技 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 515000.SH | 科技ETF华宝 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |
| 512930.SH | AI人工智能ETF平安 | mock | reference | development | False | False | True |  |  |  | True | provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit | False | provider_error |  |

## Blocking / Error 摘要
### Blocking records
- 无

### provider_error
- provider_error: tech 159995.SZ 芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 588200.SH 科创芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 512480.SH 半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 588890.SH 科创芯片相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 588170.SH 科创半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 159558.SZ 半导体设备ETF易方达: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 515050.SH 通信ETF华夏: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 159994.SZ 通信ETF银华: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 688256.SH 寒武纪: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 300308.SZ 中际旭创: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 300502.SZ 新易盛: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513180.SH 恒生科技指数ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513130.SH 恒生科技相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513020.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513150.SH 港股互联网ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 513320.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 002463.SZ 沪电股份: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 002938.SZ 鹏鼎控股: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 600183.SH 生益科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 603228.SH 景旺电子: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 002281.SZ 光迅科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 515000.SH 科技ETF华宝: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- provider_error: tech 512930.SH AI人工智能ETF平安: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

### quote_time_missing
- quote_time_missing: tech 159995.SZ 芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588200.SH 科创芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 512480.SH 半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588890.SH 科创芯片相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588170.SH 科创半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 159558.SZ 半导体设备ETF易方达: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 515050.SH 通信ETF华夏: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 159994.SZ 通信ETF银华: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 688256.SH 寒武纪: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 300308.SZ 中际旭创: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 300502.SZ 新易盛: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513180.SH 恒生科技指数ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513130.SH 恒生科技相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513020.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513150.SH 港股互联网ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513320.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002463.SZ 沪电股份: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002938.SZ 鹏鼎控股: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 600183.SH 生益科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 603228.SH 景旺电子: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002281.SZ 光迅科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 515000.SH 科技ETF华宝: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 512930.SH AI人工智能ETF平安: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

### invalid_price
- 无

### stale
- tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

### mock fallback not usable
- mock_fallback_not_allowed: tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- mock_fallback_not_allowed: tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

### reference-only but operation requested
- 无

本排障包只用于定位 provider、runtime、freshness 和 blocking 问题。
