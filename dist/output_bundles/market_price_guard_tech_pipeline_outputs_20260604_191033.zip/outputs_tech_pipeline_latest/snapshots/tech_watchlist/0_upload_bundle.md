# market_price_guard 上传包

## 基本信息
- generated_at: 2026-06-04T11:10:15.520291+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- reconcile_mode: default
- strict: false
- exit_code: 0
- output_dir: outputs_tech_watchlist_latest
- universe_name: tech_watchlist
- universe_type: candidate_watchlist
- core_count: 0
- watchlist_count: 28
- scan_count: 0
- unsupported_count: 0

## Config Source / Layer Manifest
- layer_name: tech_watchlist
- config_source_path: config/universes/tech_watchlist.yaml
- config_source_hash_sha256: 409e0b30b112
- configured_symbol_count: 28
- loaded_symbol_count: 28
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## 本轮结论
- 可用于快速参考：否
- 可用于具体操作建议：否
- 当前用途级别：reference-only
- confirmation_required 数量: 28
- blocking records 数量: 0

## 数据完整度摘要
- strict/exit_code: 0
- provider_error 数量: 23
- stale 数量: 5
- quote_time_missing 数量: 23
- invalid_price 数量: 23
- mock fallback not usable 数量: 5
- run_time_budget_exceeded: False

### Blocking records 摘要
- 无

## Quote Trust Tier 摘要
- operation-grade records 数量: 0
- reference-grade records 数量: 0
- development-grade records 数量: 28
- usable_for_reference=true 数量: 0
- usable_for_operation=true 数量: 0
- confirmation_required=true 数量: 28

## 基础行情快照 / Base Quote Snapshot
| symbol | name | last | chg% | high | low | amount | base | data_status | provider | required_for_operation |
|---|---|---:|---:|---:|---:|---:|---|---|---|---|
| 159632.SZ | 纳指相关ETF | 1.432 | — | — | — | — | price_only | price_only | mock | False |
| 513300.SH | 纳指ETF | 1.671 | — | — | — | — | price_only | price_only | mock | False |
| 159819.SZ | 人工智能ETF | 0.921 | — | — | — | — | price_only | price_only | mock | False |
| 515880.SH | 通信ETF | 1.084 | — | — | — | — | price_only | price_only | mock | False |
| 159516.SZ | 半导体设备ETF | 0.756 | — | — | — | — | price_only | price_only | mock | False |
| 159995.SZ | 芯片ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 588200.SH | 科创芯片ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 512480.SH | 半导体ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 588890.SH | 科创芯片相关ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 588170.SH | 科创半导体ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 159558.SZ | 半导体设备ETF易方达 | — | — | — | — | — | missing | provider_error | mock | False |
| 515050.SH | 通信ETF华夏 | — | — | — | — | — | missing | provider_error | mock | False |
| 159994.SZ | 通信ETF银华 | — | — | — | — | — | missing | provider_error | mock | False |
| 688256.SH | 寒武纪 | — | — | — | — | — | missing | provider_error | mock | False |
| 300308.SZ | 中际旭创 | — | — | — | — | — | missing | provider_error | mock | False |
| 300502.SZ | 新易盛 | — | — | — | — | — | missing | provider_error | mock | False |
| 513180.SH | 恒生科技指数ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 513130.SH | 恒生科技相关ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 513020.SH | 港股科技互联网相关ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 513150.SH | 港股互联网ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 513320.SH | 港股科技互联网相关ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 002463.SZ | 沪电股份 | — | — | — | — | — | missing | provider_error | mock | False |
| 002938.SZ | 鹏鼎控股 | — | — | — | — | — | missing | provider_error | mock | False |
| 600183.SH | 生益科技 | — | — | — | — | — | missing | provider_error | mock | False |
| 603228.SH | 景旺电子 | — | — | — | — | — | missing | provider_error | mock | False |
| 002281.SZ | 光迅科技 | — | — | — | — | — | missing | provider_error | mock | False |
| 515000.SH | 科技ETF华宝 | — | — | — | — | — | missing | provider_error | mock | False |
| 512930.SH | AI人工智能ETF平安 | — | — | — | — | — | missing | provider_error | mock | False |
- candidate/watchlist/scan records do not affect core strict.
- symbol_not_found in candidate or scan output is a data coverage status, not a system failure.
- not usable for concrete operation recommendations.

## 字段质量提示 / Field Quality Notes
- volume/amount are shown in provider raw units unless explicitly validated.
- cross-provider volume/amount comparison is unsafe in this version.
- bid/ask, turnover_rate, minute_bars, VWAP and QDII premium are not validated or not implemented.
- See debug_bundle.md and provider_capability_report.md for details.

## 扫描优先级摘要 / Scan Priority Summary
| priority | count | note |
|---|---:|---|
| high | 0 | review candidates only |
| medium | 0 | reference candidates |
| low | 0 | weak or incomplete |
| not_rankable | 28 | data unavailable / provider issue |

## Top Scan Candidates
| rank | symbol | name | score | priority | chg% | base | provider | note |
|---:|---|---|---:|---|---:|---|---|---|
|  |  |  |  | not_rankable |  | missing |  | no rankable records |

- Scan ranking is not operation guidance.
- Reference-only does not mean operation-ready.
- Operation decisions require operation-grade guard output.
- Candidate/watchlist/scan records do not affect core strict.
- volume/amount unit normalization is not complete.
- minute bars / VWAP / QDII premium are not implemented.

## Reconciliation Summary
- reconciliation_enabled: true
- source_agreement_status summary: aligned=0, minor_diff=0, warning_diff=0, major_diff=0, single_source_only=0, insufficient_data=0, provider_error=4
- operation_candidate_agreed count: 0
- multi-source reconciliation is diagnostic only and does not upgrade reference-grade to operation-grade.
- full report: price_reconciliation_report.md
- upload: daily use should start with 0_upload_bundle.md; include debug_bundle.md only for blocking, provider_error, stale, quote_time_missing, major_diff, or runtime budget issues.

## 项目核心内容
### Candidate watchlist

Candidate watchlist records are reference/conditional observations. They do not affect core operation strict.

- universe_name: tech_watchlist
- universe_type: candidate_watchlist

| symbol | name | role | report_group | price | source | quote_time | quote_trust_tier | usable_for_reference | usable_for_operation | confirmation_required | source_agreement_status | data_status | note |
|---|---|---|---|---:|---|---|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | nasdaq_or_overseas_tech_etf | 纳指 / 海外科技ETF | 1.432 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | 科技账户核心纳指相关 ETF; current holding; nasdaq primary anchor; QDII premium must be checked externally until premium module is implemented |
| 513300.SH | 纳指ETF | nasdaq_or_overseas_tech_etf | 纳指 / 海外科技ETF | 1.671 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | current holding; nasdaq anchor but include priority lower than 159632 unless premium is materially better |
| 159819.SZ | 人工智能ETF | ai_tech_equity | AI / 人工智能ETF | 0.921 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | already in tech core; included in scan universe for comparison only; current holding; AI second observation satellite; candidate only after AI group resonance and support confirmation |
| 515880.SH | 通信ETF | communication_tech_equity | 通信 / 科技ETF | 1.084 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True | provider_error | check_required | already in tech core; included in scan universe for comparison only; current holding; communication/CPO first observation satellite; candidate only after pullback/support confirmation |
| 159516.SZ | 半导体设备ETF | semiconductor_equipment_core_etf | 半导体 / 科创芯片 / 半导体设备 | 0.756 | mock | 2026-05-20T12:45:00+08:00 | development | False | False | True |  | check_required | current holding; failed trial observation position; retained in operation_candidate only as restricted observation; restricted observation, not a repair candidate; any new trade requires full re-evaluation |
| 159995.SZ | 芯片ETF | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; existing candidate expanded into layer1; 芯片方向强弱验证；可作为新交易候选 |
| 588200.SH | 科创芯片ETF | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; existing candidate expanded into layer1; 科创芯片弹性验证；可作为新交易候选 |
| 512480.SH | 半导体ETF | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; existing candidate expanded into layer1; 半导体整体强弱验证；可作为新交易候选 |
| 588890.SH | 科创芯片相关ETF | candidate_tech_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider |
| 588170.SH | 科创半导体ETF | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 科创半导体强弱验证；当前不列入candidate，可用于同组验证 |
| 159558.SZ | 半导体设备ETF易方达 | operation_validator_etf | 半导体 / 科创芯片 / 半导体设备 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 159516同类设备验证；不得用于补159516；不作为当前candidate |
| 515050.SH | 通信ETF华夏 | operation_validator_etf | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 同组验证；若明显强于515880且同组共振，才作为候选；不默认买 |
| 159994.SZ | 通信ETF银华 | operation_validator_etf | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | scan candidate; fund name should be validated by provider; 同组验证；若明显强于515880且同组共振，才作为候选；不默认买 |
| 688256.SH | 寒武纪 | scan_candidate_stock | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | single-stock scan candidate; not ETF; do not compare raw volume/amount directly with ETFs |
| 300308.SZ | 中际旭创 | scan_candidate_stock | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | single-stock scan candidate; not ETF; do not compare raw volume/amount directly with ETFs |
| 300502.SZ | 新易盛 | scan_candidate_stock | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | single-stock scan candidate; not ETF; do not compare raw volume/amount directly with ETFs |
| 513180.SH | 恒生科技指数ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK tech scan candidate; premium module not yet available |
| 513130.SH | 恒生科技相关ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK tech scan candidate; fund name should be validated by provider |
| 513020.SH | 港股科技互联网相关ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK tech scan candidate; fund name should be validated by provider |
| 513150.SH | 港股互联网ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK internet scan candidate; premium module not yet available |
| 513320.SH | 港股科技互联网相关ETF | scan_candidate_qdii_etf | 港股科技 / 中韩半导体 / 港股互联网 |  | mock |  | development | False | False | True |  | check_required | cross-border/HK tech scan candidate; fund name should be validated by provider |
| 002463.SZ | 沪电股份 | event_watch_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | operation-fly review observation only; not candidate by default; requires user authorization and event-position state machine; now user-selected operation_candidate; event_stock_candidate_warning; requires event state-machine review; policy override is user-driven, not operation guidance |
| 002938.SZ | 鹏鼎控股 | scan_candidate_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | PCB/server chain scan only; not candidate by default; now user-selected operation_candidate/watchlist; PCB/server chain strength verification; policy warning only |
| 600183.SH | 生益科技 | event_watch_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | AI PCB/materials event-watch candidate; policy warning only; not default operation guidance; now user-selected operation_candidate/watchlist; AI PCB/materials event-watch candidate; policy warning only |
| 603228.SH | 景旺电子 | scan_candidate_stock | AI PCB / 服务器链 |  | mock |  | development | False | False | True |  | check_required | PCB scan only; not candidate by default |
| 002281.SZ | 光迅科技 | event_watch_stock | 通信 / CPO / 光模块 |  | mock |  | development | False | False | True |  | check_required | CPO/optical module event-watch candidate; policy warning only; not default operation guidance; now user-selected operation_candidate/watchlist; CPO/optical module strength verification; policy warning only |
| 515000.SH | 科技ETF华宝 | candidate_tech_etf | 科技宽基 / AI / 算力扩散 |  | mock |  | development | False | False | True |  | check_required | broad technology ETF watch/scan candidate; not operation-grade |
| 512930.SH | AI人工智能ETF平安 | candidate_tech_etf | AI / 算力 / 科创AI / 云计算 |  | mock |  | development | False | False | True |  | check_required | AI artificial intelligence ETF watch/scan candidate; not operation-grade |

## Watchlist Review Priority
| priority | symbol | name | score | status | last | chg% | base | provider | note |
|---|---|---|---:|---|---:|---:|---|---|---|
| not_rankable | 002281.SZ | 光迅科技 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 002463.SZ | 沪电股份 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 002938.SZ | 鹏鼎控股 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 159516.SZ | 半导体设备ETF | — | development_only | 0.756 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 159558.SZ | 半导体设备ETF易方达 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 159632.SZ | 纳指相关ETF | — | development_only | 1.432 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 159819.SZ | 人工智能ETF | — | development_only | 0.921 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 159994.SZ | 通信ETF银华 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 159995.SZ | 芯片ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 300308.SZ | 中际旭创 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 300502.SZ | 新易盛 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 512480.SH | 半导体ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 512930.SH | AI人工智能ETF平安 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 513020.SH | 港股科技互联网相关ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 513130.SH | 恒生科技相关ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 513150.SH | 港股互联网ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 513180.SH | 恒生科技指数ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 513300.SH | 纳指ETF | — | development_only | 1.671 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 513320.SH | 港股科技互联网相关ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 515000.SH | 科技ETF华宝 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 515050.SH | 通信ETF华夏 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 515880.SH | 通信ETF | — | development_only | 1.084 | — | price_only | mock | development_only,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 588170.SH | 科创半导体ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 588200.SH | 科创芯片ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 588890.SH | 科创芯片相关ETF | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 600183.SH | 生益科技 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 603228.SH | 景旺电子 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |
| not_rankable | 688256.SH | 寒武纪 | — | provider_issue | — | — | missing | mock | provider_error,amount_not_comparable,volume_not_comparable,missing_price_change_pct |

## Compact Base Quote Table
| symbol | name | last | chg% | high | low | amount | base | data_status | provider | required_for_operation |
|---|---|---:|---:|---:|---:|---:|---|---|---|---|
| 159632.SZ | 纳指相关ETF | 1.432 | — | — | — | — | price_only | price_only | mock | False |
| 513300.SH | 纳指ETF | 1.671 | — | — | — | — | price_only | price_only | mock | False |
| 159819.SZ | 人工智能ETF | 0.921 | — | — | — | — | price_only | price_only | mock | False |
| 515880.SH | 通信ETF | 1.084 | — | — | — | — | price_only | price_only | mock | False |
| 159516.SZ | 半导体设备ETF | 0.756 | — | — | — | — | price_only | price_only | mock | False |
| 159995.SZ | 芯片ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 588200.SH | 科创芯片ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 512480.SH | 半导体ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 588890.SH | 科创芯片相关ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 588170.SH | 科创半导体ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 159558.SZ | 半导体设备ETF易方达 | — | — | — | — | — | missing | provider_error | mock | False |
| 515050.SH | 通信ETF华夏 | — | — | — | — | — | missing | provider_error | mock | False |
| 159994.SZ | 通信ETF银华 | — | — | — | — | — | missing | provider_error | mock | False |
| 688256.SH | 寒武纪 | — | — | — | — | — | missing | provider_error | mock | False |
| 300308.SZ | 中际旭创 | — | — | — | — | — | missing | provider_error | mock | False |
| 300502.SZ | 新易盛 | — | — | — | — | — | missing | provider_error | mock | False |
| 513180.SH | 恒生科技指数ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 513130.SH | 恒生科技相关ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 513020.SH | 港股科技互联网相关ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 513150.SH | 港股互联网ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 513320.SH | 港股科技互联网相关ETF | — | — | — | — | — | missing | provider_error | mock | False |
| 002463.SZ | 沪电股份 | — | — | — | — | — | missing | provider_error | mock | False |
| 002938.SZ | 鹏鼎控股 | — | — | — | — | — | missing | provider_error | mock | False |
| 600183.SH | 生益科技 | — | — | — | — | — | missing | provider_error | mock | False |
| 603228.SH | 景旺电子 | — | — | — | — | — | missing | provider_error | mock | False |
| 002281.SZ | 光迅科技 | — | — | — | — | — | missing | provider_error | mock | False |
| 515000.SH | 科技ETF华宝 | — | — | — | — | — | missing | provider_error | mock | False |
| 512930.SH | AI人工智能ETF平安 | — | — | — | — | — | missing | provider_error | mock | False |

## Base Quote Summary
- base_quote_completeness counts:
- missing: 23
- price_only: 5
- missing fields top: amount:28, high_price:28, low_price:28, open_price:28, prev_close:28, volume:28, last_price:23
- base quote fields are auxiliary diagnostics; missing fields do not change existing strict in this version.

| symbol | base_quote_completeness | available | missing | missing_fields |
|---|---|---:|---:|---|
| 159632.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 513300.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159819.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 515880.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159516.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159995.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588200.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512480.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588890.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588170.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159558.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515050.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159994.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 688256.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300308.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300502.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513180.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513130.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513020.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513150.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513320.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002463.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002938.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600183.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603228.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002281.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515000.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512930.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |

## Provider Coverage / Failure Reasons
| symbol | registry_found | provider_attempted | provider_status | data_status | likely_reason | suggested_next_step |
|---|---|---|---|---|---|---|
| 159632.SZ | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 513300.SH | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 159819.SZ | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 515880.SH | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 159516.SZ | True | mock | success | price_only | mock/development only | keep as candidate; does not affect core strict |
| 159995.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 588200.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 512480.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 588890.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 588170.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 159558.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 515050.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 159994.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 688256.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 300308.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 300502.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513180.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513130.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513020.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513150.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 513320.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002463.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002938.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 600183.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 603228.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 002281.SZ | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 515000.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |
| 512930.SH | True | mock | provider_error,skipped_by_provider_circuit | provider_error | endpoint_failed | keep as candidate; review provider_health/debug details |

## Safety Notes

- Scan ranking is not operation guidance.
- Reference-only does not mean operation-ready.
- Operation decisions require operation-grade guard output.
- Candidate/watchlist/scan records do not affect core strict.
- volume/amount unit normalization is not complete.
- minute bars / VWAP / QDII premium are not implemented.

## Universe isolation
- universe_name: tech_watchlist
- universe_type: candidate_watchlist
- core strict pollution isolation: enabled
- this universe is not used for core operation strict blocking.
- not usable for concrete operation recommendations.

## Reference / Operation 使用提示
- 本轮为快速参考模式。
- 可以用于快速参考。
- 不可用于具体操作建议。
- 不可给出具体执行动作、盘中高频判断或执行参数参数。
- 如需具体操作，请运行 operation 输出或补充有效盘口信息。

## Debug 提示
- 如出现 strict=2、blocking records、provider_error、quote_time_missing、invalid_price、stale、selected_provider=mock、fallback_used 异常、run_time_budget_exceeded、slow_provider_attempts、quote_time 可疑或报告冲突，请补充 debug_bundle.md。
- 本上传包只汇总数据状态、可用性和阻断原因。
