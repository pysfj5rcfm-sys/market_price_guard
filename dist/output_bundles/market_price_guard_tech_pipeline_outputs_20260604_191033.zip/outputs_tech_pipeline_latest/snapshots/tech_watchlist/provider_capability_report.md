# Provider Capability Report

Provider capability data is diagnostic only. It does not upgrade trust tier, change strict, or provide operation guidance.

## Runtime Context
- generated_at: 2026-06-04T11:10:15.520291+00:00
- profile: tech
- provider_mode: live
- provider_policy: fast
- quote_purpose: reference
- universe_name: tech_watchlist
- universe_type: candidate_watchlist

## Provider Capability Summary
| provider | function_name | asset_type | base_price_fields | volume_amount_status | bid_ask_status | turnover_status | minute_status | operation_fit | notes |
|---|---|---|---|---|---|---|---|---|---|
| akshare | fund_etf_spot_em | ETF, QDII_ETF, A_SHARE_ETF | supported_or_calculable | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | Operation fit still depends on quote_trust_tier, strict, freshness, and provider health. |
| akshare | stock_spot_em | A_SHARE, HK_STOCK | mixed:missing,supported | volume=supported_raw_unit; amount=supported_unit_unknown | bid1=not_validated; ask1=not_validated | not_validated | not_implemented | conditional | A/H stock endpoint availability is environment-dependent. |
| akshare | fund_etf_hist_min_em | ETF, QDII_ETF, A_SHARE_ETF | missing | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | supported_if_endpoint_succeeds | diagnostic_only | ETF minute bars probe via AKShare; does not upgrade operation readiness. |
| eastmoney_direct | stock_get | ETF, A_SHARE_ETF, A_SHARE | mixed:calculable,supported_when_endpoint_succeeds | volume=supported_raw_unit; amount=supported_raw_unit | bid1=not_validated; ask1=not_validated | not_validated | attempted_provider_dependent | False | Reference / operation-candidate only; endpoint stability is not guaranteed. |
| yfinance | ticker_quote | ETF, HK_STOCK, A_SHARE, A_SHARE_ETF, INDEX | mixed:missing,provider_dependent,supported | volume=supported_raw_unit; amount=missing | bid1=missing_or_not_validated; ask1=missing_or_not_validated | missing | attempted_reference_fallback | reference_only | Open-source Yahoo Finance wrapper; not an official exchange feed. |
| manual | manual_price | MANUAL, GOLD | mixed:missing,supported | volume=missing; amount=missing | bid1=missing; ask1=missing | missing | not_supported | conditional | Manual reference price; no market depth fields. |
| mock | mock_quote | TEST | mixed:missing,supported_for_tests | volume=supported_for_tests; amount=supported_for_tests | bid1=not_applicable; ask1=not_applicable | not_applicable | supported_for_tests | False | Development/testing only. |

## Field Capability Matrix By Provider
| provider | function_name | field | status | unit | unit_confidence | comparable_across_providers | operation_fit | reference_fit | notes |
|---|---|---|---|---|---|---|---|---|---|
| akshare | fund_etf_spot_em | amount | supported_unit_unknown | unit_unknown | unknown | False | diagnostic_only | True |  |
| akshare | fund_etf_spot_em | amplitude_pct | calculable | percent_value | medium | True | diagnostic_only | True |  |
| akshare | fund_etf_spot_em | ask1_price | not_validated | price | unknown | False | False | False |  |
| akshare | fund_etf_spot_em | bid1_price | not_validated | price | unknown | False | False | False |  |
| akshare | fund_etf_spot_em | high_price | supported | price | medium | True | conditional | True |  |
| akshare | fund_etf_spot_em | intraday_vwap | not_implemented | not_applicable | not_applicable | False | False | False |  |
| akshare | fund_etf_spot_em | iopv | missing | price | unknown | False | False | False |  |
| akshare | fund_etf_spot_em | last_price | supported | price | high | True | conditional | True |  |
| akshare | fund_etf_spot_em | low_price | supported | price | medium | True | conditional | True |  |
| akshare | fund_etf_spot_em | minute_bars | not_implemented | not_applicable | not_applicable | False | False | False |  |
| akshare | fund_etf_spot_em | open_price | supported | price | medium | True | conditional | True |  |
| akshare | fund_etf_spot_em | premium_pct | missing | percent_value | unknown | False | False | False |  |
| akshare | fund_etf_spot_em | prev_close | supported | price | medium | True | conditional | True |  |
| akshare | fund_etf_spot_em | price_change | supported_or_calculable | price | medium | True | diagnostic_only | True |  |
| akshare | fund_etf_spot_em | price_change_pct | supported_or_calculable | percent_value | medium | True | diagnostic_only | True |  |
| akshare | fund_etf_spot_em | turnover_rate | not_validated | percent_value | unknown | False | False | False |  |
| akshare | fund_etf_spot_em | volume | supported_raw_unit | raw_provider_unit | low | False | diagnostic_only | True |  |
| akshare | stock_spot_em | amount | supported_unit_unknown | unit_unknown | unknown | False | diagnostic_only | True |  |
| akshare | stock_spot_em | ask1_price | not_validated |  |  |  | False | False |  |
| akshare | stock_spot_em | bid1_price | not_validated |  |  |  | False | False |  |
| akshare | stock_spot_em | last_price | supported | price | medium | True | conditional | True |  |
| akshare | stock_spot_em | minute_bars | not_implemented |  |  |  | False | False |  |
| akshare | stock_spot_em | turnover_rate | not_validated |  |  |  | False | False |  |
| akshare | stock_spot_em | volume | supported_raw_unit | raw_provider_unit | low | False | diagnostic_only | True |  |
| akshare | fund_etf_hist_min_em | intraday_vwap | not_implemented |  |  |  | False | False |  |
| akshare | fund_etf_hist_min_em | minute_bar_interval | supported_if_endpoint_succeeds | not_applicable |  |  | diagnostic_only | True |  |
| akshare | fund_etf_hist_min_em | minute_bars | supported_if_endpoint_succeeds | raw_provider_unit | low | False | diagnostic_only | True |  |
| eastmoney_direct | stock_get | amount | supported_raw_unit | raw_provider_unit | low | False | False | True |  |
| eastmoney_direct | stock_get | amplitude_pct | calculable | percent_value | medium | True | False | True |  |
| eastmoney_direct | stock_get | ask1_price | not_validated |  |  |  | False | False |  |
| eastmoney_direct | stock_get | bid1_price | not_validated |  |  |  | False | False |  |
| eastmoney_direct | stock_get | high_price | supported_when_endpoint_succeeds | price | medium | True | False | True |  |
| eastmoney_direct | stock_get | intraday_vwap | not_implemented |  |  |  | False | False |  |
| eastmoney_direct | stock_get | iopv | missing |  |  |  | False | False |  |
| eastmoney_direct | stock_get | last_price | supported_when_endpoint_succeeds | price | medium | True | False | True |  |
| eastmoney_direct | stock_get | low_price | supported_when_endpoint_succeeds | price | medium | True | False | True |  |
| eastmoney_direct | stock_get | minute_bar_interval | supported_if_endpoint_succeeds |  |  |  | False | True |  |
| eastmoney_direct | stock_get | minute_bars | attempted_provider_dependent | raw_provider_unit | low | False | False | True |  |
| eastmoney_direct | stock_get | open_price | supported_when_endpoint_succeeds | price | medium | True | False | True |  |
| eastmoney_direct | stock_get | premium_pct | missing |  |  |  | False | False |  |
| eastmoney_direct | stock_get | prev_close | supported_when_endpoint_succeeds | price | medium | True | False | True |  |
| eastmoney_direct | stock_get | price_change | supported_when_endpoint_succeeds | price | medium | True | False | True |  |
| eastmoney_direct | stock_get | price_change_pct | supported_when_endpoint_succeeds | percent_value | medium | True | False | True |  |
| eastmoney_direct | stock_get | turnover_rate | not_validated |  |  |  | False | False |  |
| eastmoney_direct | stock_get | volume | supported_raw_unit | raw_provider_unit | low | False | False | True |  |
| yfinance | ticker_quote | amount | missing | not_applicable | not_applicable | False | False | False |  |
| yfinance | ticker_quote | ask1_price | missing_or_not_validated |  |  |  | False | False |  |
| yfinance | ticker_quote | bid1_price | missing_or_not_validated |  |  |  | False | False |  |
| yfinance | ticker_quote | high_price | provider_dependent | price | medium | True | reference_only | True |  |
| yfinance | ticker_quote | intraday_vwap | not_implemented |  |  |  | False | False |  |
| yfinance | ticker_quote | iopv | missing |  |  |  | False | False |  |
| yfinance | ticker_quote | last_price | supported | price | medium | True | reference_only | True |  |
| yfinance | ticker_quote | low_price | provider_dependent | price | medium | True | reference_only | True |  |
| yfinance | ticker_quote | minute_bars | attempted_reference_fallback | raw_provider_unit | low | False | False | True | YFinance intraday bars are attempted only as reference fallback after AKShare and Eastmoney minute probes fail; ranges are limited and do not upgrade operation. |
| yfinance | ticker_quote | open_price | provider_dependent | price | medium | True | reference_only | True |  |
| yfinance | ticker_quote | premium_pct | missing |  |  |  | False | False |  |
| yfinance | ticker_quote | prev_close | provider_dependent | price | medium | True | reference_only | True |  |
| yfinance | ticker_quote | turnover_rate | missing |  |  |  | False | False |  |
| yfinance | ticker_quote | volume | supported_raw_unit | raw_provider_unit | low | False | reference_only | True |  |
| manual | manual_price | amount | missing |  |  |  | False | False |  |
| manual | manual_price | high_price | missing |  |  |  | False | False |  |
| manual | manual_price | last_price | supported | price | high | False | conditional | True |  |
| manual | manual_price | low_price | missing |  |  |  | False | False |  |
| manual | manual_price | minute_bars | not_supported |  |  |  | False | False |  |
| manual | manual_price | open_price | missing |  |  |  | False | False |  |
| manual | manual_price | prev_close | missing |  |  |  | False | False |  |
| manual | manual_price | volume | missing |  |  |  | False | False |  |
| mock | mock_quote | amount | supported_for_tests | test_unit | test_unit | False | False | False |  |
| mock | mock_quote | ask1_price | not_applicable |  |  |  | False | False |  |
| mock | mock_quote | bid1_price | not_applicable |  |  |  | False | False |  |
| mock | mock_quote | last_price | supported_for_tests | price | test_unit | False | False | False |  |
| mock | mock_quote | minute_bars | supported_for_tests | test_unit | test_unit | False | False | False |  |
| mock | mock_quote | turnover_rate | not_applicable |  |  |  | False | False |  |
| mock | mock_quote | volume | supported_for_tests | test_unit | test_unit | False | False | False |  |

## Symbol Field Quality
| symbol | name | provider | base | volume_unit | amount_unit | volume_comparable | amount_comparable | field_validation_status | notes |
|---|---|---|---|---|---|---|---|---|---|
| 159632.SZ | 纳指相关ETF | mock | price_only | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 513300.SH | 纳指ETF | mock | price_only | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 159819.SZ | 人工智能ETF | mock | price_only | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 515880.SH | 通信ETF | mock | price_only | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 159516.SZ | 半导体设备ETF | mock | price_only | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 159995.SZ | 芯片ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 588200.SH | 科创芯片ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 512480.SH | 半导体ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 588890.SH | 科创芯片相关ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 588170.SH | 科创半导体ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 159558.SZ | 半导体设备ETF易方达 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 515050.SH | 通信ETF华夏 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 159994.SZ | 通信ETF银华 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 688256.SH | 寒武纪 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 300308.SZ | 中际旭创 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 300502.SZ | 新易盛 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 513180.SH | 恒生科技指数ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 513130.SH | 恒生科技相关ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 513020.SH | 港股科技互联网相关ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 513150.SH | 港股互联网ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 513320.SH | 港股科技互联网相关ETF | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 002463.SZ | 沪电股份 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 002938.SZ | 鹏鼎控股 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 600183.SH | 生益科技 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 603228.SH | 景旺电子 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 002281.SZ | 光迅科技 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 515000.SH | 科技ETF华宝 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |
| 512930.SH | AI人工智能ETF平安 | mock | missing | not_applicable | not_applicable | False | False | development_only | mock data is development/testing only |

## Minute Bars Capability
- include_minute_bars: False
- akshare: ETF minute bars attempted through fund_etf_hist_min_em when --include-minute-bars is enabled.
- eastmoney_direct: minute bars attempted as diagnostic fallback; provider_dependent and not operation-grade.
- yfinance: attempted_reference_fallback / provider_dependent_reference after AKShare and Eastmoney fail; not operation-grade.
- diagnostic_only in provider capability is a capability label only; actual fallback behavior is controlled by minute_mode.
- manual: not_supported.
- mock: supported_for_tests when --include-minute-bars is used with provider-mode=mock.
- include_minute_bars: False
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- minute_bars_available count: 0
- operation_candidate_symbols_count: 0
- operation_candidate_minute_available_count: 0
- operation_candidate_minute_missing_count: 0
- unavailable count: 0
- not_supported count: 0
- provider_error count: 0
- symbol_not_found count: 0
- stale count: 0
- akshare_attempted_count: 0
- akshare_success_count: 0
- akshare_error_count: 0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_empty_response_count: 0
- yfinance_parse_error_count: 0
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- fallback_skipped_yfinance_circuit_open_count: 0
- yfinance_last_error: 
- eastmoney_attempted_count: 0
- eastmoney_success_count: 0
- eastmoney_error_count: 0
- eastmoney_empty_response_count: 0
- eastmoney_parse_error_count: 0
- empty_response count: 0
- after_close_possible_count: 0
- retry_during_trading_hours_count: 0
- current session summary: missing:28
- upload bundle uses compact minute notes; full provider diagnostics remain in debug_bundle.md.
- status counts:
  - not_attempted: 28
- by provider:
  - missing: 28
- minute bars missing does not change existing strict in v0.7.3.
- Eastmoney minute bars are diagnostic/reference only.
- minute fallback behavior depends on minute_mode; balanced skips Eastmoney minute fallback by default.
- minute bars are diagnostic only.

## Safe Usage Notes
- Provider capability report is diagnostic only.
- Field capability does not upgrade trust tier.
- Field completeness does not imply operation-grade.
- volume/amount must not be compared across providers until unit validation is high.
- bid/ask and turnover are not validated in this guard version.
- diagnostic_only in provider capability means capability label only; actual fallback behavior is controlled by minute_mode.
- minute bars are reference-only and do not upgrade operation readiness; QDII premium remains not implemented.
- This report is not operation guidance.
