# 数据完整度报告

quote_purpose: reference
reconcile_mode: default
可用于具体操作建议：否

本工具不做自动交易，不输出具体操作建议，只输出价格事实、数据源、时间戳、市场状态和数据完整度。

行情源健康状态详见 provider_health_report.md。

## Config Source / Layer Manifest
- layer_name: tech_watchlist
- config_source_path: config/universes/tech_watchlist.yaml
- config_source_hash_sha256: 409e0b30b112
- configured_symbol_count: 28
- loaded_symbol_count: 28
- config_mismatch: false
- missing_from_loaded: none
- extra_loaded_symbols: none
- legacy_fallback_used: false
- hardcoded_default_used: false

## Strict blocking records

## Reference mode warning
- 本轮为 reference 模式，可用于快速参考，不可用于具体操作建议。
- operation confirmation required: 如需具体执行动作或盘中价位，必须运行 operation-grade / strict 输出。
- 无

## Provider diagnostics
- 无 AKShare 记录

## Provider routing notes
- 159632.SZ: provider_policy=fast
- 159632.SZ: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 159632.SZ: mock fallback 不可用于具体操作建议
- 513300.SH: provider_policy=fast
- 513300.SH: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 513300.SH: mock fallback 不可用于具体操作建议
- 159819.SZ: provider_policy=fast
- 159819.SZ: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 159819.SZ: mock fallback 不可用于具体操作建议
- 515880.SH: provider_policy=fast
- 515880.SH: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 515880.SH: mock fallback 不可用于具体操作建议
- 159516.SZ: provider_policy=fast
- 159516.SZ: primary failed but fallback selected; selected_provider=mock; selection_reason=mock_fallback_not_allowed_for_operation
- 159516.SZ: mock fallback 不可用于具体操作建议
- 159995.SZ: provider_policy=fast
- 588200.SH: provider_policy=fast
- 512480.SH: provider_policy=fast
- 588890.SH: provider_policy=fast
- 588170.SH: provider_policy=fast
- 159558.SZ: provider_policy=fast
- 515050.SH: provider_policy=fast
- 159994.SZ: provider_policy=fast
- 688256.SH: provider_policy=fast
- 300308.SZ: provider_policy=fast
- 300502.SZ: provider_policy=fast
- 513180.SH: provider_policy=fast
- 513130.SH: provider_policy=fast
- 513020.SH: provider_policy=fast
- 513150.SH: provider_policy=fast
- 513320.SH: provider_policy=fast
- 002463.SZ: provider_policy=fast
- 002938.SZ: provider_policy=fast
- 600183.SH: provider_policy=fast
- 603228.SH: provider_policy=fast
- 002281.SZ: provider_policy=fast
- 515000.SH: provider_policy=fast
- 512930.SH: provider_policy=fast

## Quote trust tier diagnostics
- quote_purpose: reference
- quote_trust_tier summary: operation=0, reference=0, development=28
- operation-grade records: 
- reference-grade records: 
- development-grade records: 159632.SZ, 513300.SH, 159819.SZ, 515880.SH, 159516.SZ, 159995.SZ, 588200.SH, 512480.SH, 588890.SH, 588170.SH, 159558.SZ, 515050.SH, 159994.SZ, 688256.SH, 300308.SZ, 300502.SZ, 513180.SH, 513130.SH, 513020.SH, 513150.SH, 513320.SH, 002463.SZ, 002938.SZ, 600183.SH, 603228.SH, 002281.SZ, 515000.SH, 512930.SH
- confirmation_required records: 159632.SZ, 513300.SH, 159819.SZ, 515880.SH, 159516.SZ, 159995.SZ, 588200.SH, 512480.SH, 588890.SH, 588170.SH, 159558.SZ, 515050.SH, 159994.SZ, 688256.SH, 300308.SZ, 300502.SZ, 513180.SH, 513130.SH, 513020.SH, 513150.SH, 513320.SH, 002463.SZ, 002938.SZ, 600183.SH, 603228.SH, 002281.SZ, 515000.SH, 512930.SH
- operation confirmation required: reference-grade records are not operation-grade permission.

## Source agreement diagnostics
- full report: price_reconciliation_report.md
- 159632.SZ: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 513300.SH: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 159819.SZ: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes
- 515880.SH: compared_sources=akshare, eastmoney_direct, source_agreement_status=provider_error, price_diff_pct=, quote_time_gap_seconds=, operation_candidate_agreed=False, note=no comparable real provider quotes

## Base quote completeness summary
- base_quote_completeness counts:
- missing: 23
- price_only: 5
- missing fields top: amount:28, high_price:28, low_price:28, open_price:28, prev_close:28, volume:28, last_price:23
- base quote fields are auxiliary diagnostics; missing fields do not change existing strict in this version.

| symbol | base_quote_completeness | available | missing | missing_fields |
|---|---|---:|---:|---|
| 159632.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 513300.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159819.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 515880.SH | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159516.SZ | price_only | 1 | 6 | prev_close,open_price,high_price,low_price,volume,amount |
| 159995.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588200.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512480.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588890.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 588170.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159558.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515050.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 159994.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 688256.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300308.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 300502.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513180.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513130.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513020.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513150.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 513320.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002463.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002938.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 600183.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 603228.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 002281.SZ | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 515000.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |
| 512930.SH | missing | 0 | 7 | last_price,prev_close,open_price,high_price,low_price,volume,amount |

### Base quote caveats
- volume/amount follow provider raw units unless unit normalization is explicitly available.
- cross-provider volume/amount comparison is not reliable until provider field validation is completed.
- base quote missing does not change existing strict; base quote and field capability issues do not change existing strict in v0.7.1.6.
- operation still depends on quote_trust_tier / usable_for_operation / strict / freshness.
- field completeness is a diagnostic aid, not operation guidance.

## Field Quality / Provider Capability
- volume_comparable_across_providers=true records: 0
- amount_comparable_across_providers=true records: 0
- unit_unknown records: 0
- raw_provider_unit records: 0
- field_validation_status counts: development_only:28
- not_validated fields: bid1_price, ask1_price, turnover_rate
- not_implemented fields: minute_bars, intraday_vwap, iopv, premium_pct
- field validation issues do not change existing strict in v0.7.1.6.
- operation still depends on quote_trust_tier / usable_for_operation / strict / freshness.
- capability data is diagnostic, not operation guidance.

## Minute Bars Completeness
- include_minute_bars: False
- minute_mode: balanced
- minute_workers: 3
- parallel_enabled: False
- parallel_note: workers parameter parsed, execution remains serial in this version
- minute_bars_available count: 0
- operation_candidate_symbols_count: 0
- operation_candidate_minute_available_count: 0
- operation_candidate_minute_missing_count: 0
- unavailable count: 0
- not_supported count: 0
- provider_error count: 0
- symbol_not_found count: 0
- stale count: 0
- akshare_attempted_count: 0
- akshare_success_count: 0
- akshare_error_count: 0
- yfinance_attempted_count: 0
- yfinance_success_count: 0
- yfinance_error_count: 0
- yfinance_empty_response_count: 0
- yfinance_parse_error_count: 0
- yfinance_fallback_policy: enabled_until_circuit_open
- yfinance_circuit_open: False
- yfinance_circuit_reason: 
- yfinance_circuit_scope: run_only
- yfinance_timeout_count: 0
- yfinance_rate_limited_count: 0
- yfinance_skipped_by_circuit_count: 0
- fallback_skipped_yfinance_circuit_open_count: 0
- yfinance_last_error: 
- eastmoney_attempted_count: 0
- eastmoney_success_count: 0
- eastmoney_error_count: 0
- eastmoney_empty_response_count: 0
- eastmoney_parse_error_count: 0
- empty_response count: 0
- after_close_possible_count: 0
- retry_during_trading_hours_count: 0
- current session summary: missing:28
- upload bundle uses compact minute notes; full provider diagnostics remain in debug_bundle.md.
- status counts:
  - not_attempted: 28
- by provider:
  - missing: 28
- minute bars missing does not change existing strict in v0.7.3.
- Eastmoney minute bars are diagnostic/reference only.
- minute fallback behavior depends on minute_mode; balanced skips Eastmoney minute fallback by default.
- minute bars are diagnostic only.

## Scan Ranking Summary
- total_symbols: 28
- rankable_count: 0
- not_rankable_count: 28
- high_priority_count: 0
- medium_priority_count: 0
- low_priority_count: 0
- symbol_not_found_count: 0
- provider_issue_count: 23
- data_insufficient_count: 0
- exclusion reasons: development_only:5, provider_error:23
- ranking does not affect strict.
- See price_reconciliation_report.md for full multi-source comparison details.

## Runtime freshness diagnostics
- 详见 runtime_diagnostics.md
- provider_policy: fast
- total_elapsed_seconds: 0.051
- run_time_budget_exceeded: False
- max_quote_lag_seconds: 1319115.52
- max_data_lag_seconds: 300.0

## AKShare price records
- 无

## AKShare quote freshness details
- 无

## AKShare / 数据质量问题
- 无

## 黄金手工价说明
黄金持仓参考价为用户手工录入价，不等同于国际现货金价；用于科技账户防守仓/潜在转科技资金的参考，实际操作前需核对账户内可卖价、手续费、点差和到账规则。

## 如果为否，原因
- 存在价格缺失
- 存在 stale 价格
- 存在 quote_time_missing，无法证明价格新鲜

## 缺失价格列表
- tech 159995.SZ 芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 588200.SH 科创芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 512480.SH 半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 588890.SH 科创芯片相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 588170.SH 科创半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 159558.SZ 半导体设备ETF易方达: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 515050.SH 通信ETF华夏: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 159994.SZ 通信ETF银华: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 688256.SH 寒武纪: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 300308.SZ 中际旭创: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 300502.SZ 新易盛: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513180.SH 恒生科技指数ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513130.SH 恒生科技相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513020.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513150.SH 港股互联网ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513320.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 002463.SZ 沪电股份: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 002938.SZ 鹏鼎控股: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 600183.SH 生益科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 603228.SH 景旺电子: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 002281.SZ 光迅科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 515000.SH 科技ETF华宝: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 512930.SH AI人工智能ETF平安: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

## stale 价格列表
- tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed

## quote_time 缺失列表
- quote_time_missing: tech 159995.SZ 芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588200.SH 科创芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 512480.SH 半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588890.SH 科创芯片相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 588170.SH 科创半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 159558.SZ 半导体设备ETF易方达: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 515050.SH 通信ETF华夏: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 159994.SZ 通信ETF银华: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 688256.SH 寒武纪: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 300308.SZ 中际旭创: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 300502.SZ 新易盛: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513180.SH 恒生科技指数ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513130.SH 恒生科技相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513020.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513150.SH 港股互联网ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 513320.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002463.SZ 沪电股份: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002938.SZ 鹏鼎控股: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 600183.SH 生益科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 603228.SH 景旺电子: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 002281.SZ 光迅科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 515000.SH 科技ETF华宝: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- quote_time_missing: tech 512930.SH AI人工智能ETF平安: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

## manual price records
- 无

## warning
- tech 159632.SZ 纳指相关ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 513300.SH 纳指ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159819.SZ 人工智能ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 515880.SH 通信ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159516.SZ 半导体设备ETF: mock_fallback_not_allowed: mock fallback 不可用于具体操作建议；mock_fallback_not_allowed
- tech 159995.SZ 芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 588200.SH 科创芯片ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 512480.SH 半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 588890.SH 科创芯片相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 588170.SH 科创半导体ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 159558.SZ 半导体设备ETF易方达: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 515050.SH 通信ETF华夏: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 159994.SZ 通信ETF银华: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 688256.SH 寒武纪: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 300308.SZ 中际旭创: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 300502.SZ 新易盛: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513180.SH 恒生科技指数ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513130.SH 恒生科技相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513020.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513150.SH 港股互联网ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 513320.SH 港股科技互联网相关ETF: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 002463.SZ 沪电股份: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 002938.SZ 鹏鼎控股: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 600183.SH 生益科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 603228.SH 景旺电子: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 002281.SZ 光迅科技: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 515000.SH 科技ETF华宝: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit
- tech 512930.SH AI人工智能ETF平安: provider_error: 行情源调用失败，不可用于具体操作建议；provider_error, skipped_by_provider_circuit

## 不确定性
- 手续费、点差、赎回到账规则未自动计算。
- GOLD_CNY 需以后续实际账户可卖价为准。

## 允许使用范围
- 可用于价格事实同步、数据源核对、时间戳核对、市场状态核对和数据完整度检查。
- 收盘后价格仅可作为收盘/最后成交参考。
- GOLD_CNY 仅可作为科技账户防守仓/潜在转科技资金参考。

## 禁止使用范围
- 不可用于自动交易。
- 不输出具体操作建议。
- 若 required_for_operation 指标缺失、stale、quote_time 缺失或无效，不可用于具体操作建议。
- 收盘/最后成交参考价不可用于盘中盘中高频判断。
