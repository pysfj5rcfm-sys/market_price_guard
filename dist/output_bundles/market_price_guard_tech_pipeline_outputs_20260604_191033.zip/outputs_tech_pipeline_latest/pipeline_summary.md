# Tech Research Pipeline Summary

- generated_at: 2026-06-04T11:10:09.6909510Z
- pipeline_run_id: 20a7fc10-9c27-4af0-a34e-34018b463ebc
- source_run_id: 20a7fc10-9c27-4af0-a34e-34018b463ebc
- pipeline_name: tech_research_pipeline
- use_run_cache: true
- scan_mode: fast
- minute_mode: balanced
- minute_workers: 3
- cache_dir: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_cache_latest
- total_steps: 6
- run_steps: 6
- skipped_steps: 0
- passed: 5
- strict_blocked_but_reported: 1
- failed: 0
- runtime_warnings: 1
- total_elapsed_seconds: 12.518
- runtime_warning_policy: runtime_info, runtime_warning, soft_budget_exceeded, hard_timeout, provider_timeout, provider_circuit_open, strict_blocked_but_reported, failed
- runtime_warnings_do_not_equal_failed: true

## Steps

| step | status | exit_code | elapsed_seconds | runtime_warning_level | output_dir | snapshot_dir | generated_at | source_run_id | layer_manifest_hash | prices_snapshot_hash | upload_bundle_hash |
|---|---|---:|---:|---|---|---|---|---|---|---|---|
| tech_scan_ai | passed | 0 | 5.509 | provider_circuit_open | outputs_tech_scan_ai_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_scan_ai | 2026-06-04T11:10:15.2093000Z | 20a7fc10-9c27-4af0-a34e-34018b463ebc | 82a6aa72a6c98eae4fe3d4aa8edfa91d9aa90eebf0e9a3f757e8597bc2263c7c | 863b876b34b3859b9b16f53bc881e0b455507c712b4e4237e3f2fbdcdc13ba1b | 8c2b46cc3ca4d35755a64a4dbd00088fed3b956de6ac9c8df0fdcad571ebb3de |
| tech_watchlist | passed | 0 | 0.359 | runtime_info | outputs_tech_watchlist_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_watchlist | 2026-06-04T11:10:15.6116870Z | 20a7fc10-9c27-4af0-a34e-34018b463ebc | 5a3345cf544cc4627d105bcc67ddf1a3fa3771fe3f22b46d2a941b30aaafb9f0 | bfa828286f683f00b93d12ed3a70a0ea8b2d5c79447c3eb06da81c9e0588862d | e4326e76ec355ee0fa16b5a764b98d11fc9edb1e977475c73901b89a3c8b153a |
| tech_operation_candidates | passed | 0 | 0.355 | runtime_info | outputs_tech_operation_candidates_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_operation_candidates | 2026-06-04T11:10:15.9750770Z | 20a7fc10-9c27-4af0-a34e-34018b463ebc | 7772204683d712c06416d545a29f155dfa2ce48e2658aac01a56b33f83c36856 | 1dcfe87e363be28bde9241ab4c05fd0a608457e38de0802df7f197b37bbd6fa7 | 3fe41b00ae4b52377cef491130ddc2f8c129302419dc78b03a22c822db296b12 |
| tech_fast_strict | strict_blocked_but_reported | 2 | 5.27 | strict_blocked_but_reported | outputs_tech_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_fast_strict | 2026-06-04T11:10:21.2509800Z | 20a7fc10-9c27-4af0-a34e-34018b463ebc | 40066fdba512e560e6b566217a422532ff67c951549d5aacbee1f303111177de | df828f06c781880f527c051de0e1de0e617beab416520251a3ba8e2af7d3002e | 3424f43200581fe6758319efde002caa5e7751193a4c7d1b02e121e32b351209 |
| tech_minute_probe | passed | 0 | 0.595 | runtime_info | outputs_tech_minute_probe_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_minute_probe | 2026-06-04T11:10:21.8505440Z | 20a7fc10-9c27-4af0-a34e-34018b463ebc | 53c38dc6eceab81cf009e21659736df25907a2585624d12b1aecaf33e03c2736 | 4b08655d4159b11ae1b11eb86ec8c06a548f1338650ebb51c875698bb5e5c96f | dd44064b345a4a5065d31929707ee5fdcc1e8d42fe0b598d508f804b423fb509 |
| tech_intraday_metrics | passed | 0 | 0.351 | runtime_info | outputs_tech_intraday_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_intraday_metrics | 2026-06-04T11:10:22.2052360Z | 20a7fc10-9c27-4af0-a34e-34018b463ebc | 16affdc3f849fc6262d46e5220f61b9c0892f721aa639c2dc27486743047c0a6 |  | fbc1cf30c142227cea3876b8372c5d6123f9850caa06063f17a8bd9c3304e3ee |

## Pipeline Output Snapshots

- snapshots_root: /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots
- snapshots are copied during this pipeline run and are not affected by later standalone layer runs.

| step_name | account | output_dir | snapshot_dir | snapshot_metadata | layer_manifest_path | manifest_hash | source_run_id |
|---|---|---|---|---|---|---|---|
| tech_scan_ai | tech | outputs_tech_scan_ai_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_scan_ai | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_scan_ai/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_scan_ai/layer_manifest.json | 82a6aa72a6c98eae4fe3d4aa8edfa91d9aa90eebf0e9a3f757e8597bc2263c7c | 20a7fc10-9c27-4af0-a34e-34018b463ebc |
| tech_watchlist | tech | outputs_tech_watchlist_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_watchlist | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_watchlist/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_watchlist/layer_manifest.json | 5a3345cf544cc4627d105bcc67ddf1a3fa3771fe3f22b46d2a941b30aaafb9f0 | 20a7fc10-9c27-4af0-a34e-34018b463ebc |
| tech_operation_candidates | tech | outputs_tech_operation_candidates_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_operation_candidates | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_operation_candidates/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_operation_candidates/layer_manifest.json | 7772204683d712c06416d545a29f155dfa2ce48e2658aac01a56b33f83c36856 | 20a7fc10-9c27-4af0-a34e-34018b463ebc |
| tech_fast_strict | tech | outputs_tech_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_fast_strict | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_fast_strict/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_fast_strict/layer_manifest.json | 40066fdba512e560e6b566217a422532ff67c951549d5aacbee1f303111177de | 20a7fc10-9c27-4af0-a34e-34018b463ebc |
| tech_minute_probe | tech | outputs_tech_minute_probe_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_minute_probe | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_minute_probe/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_minute_probe/layer_manifest.json | 53c38dc6eceab81cf009e21659736df25907a2585624d12b1aecaf33e03c2736 | 20a7fc10-9c27-4af0-a34e-34018b463ebc |
| tech_intraday_metrics | tech | outputs_tech_intraday_latest | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_intraday_metrics | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_intraday_metrics/snapshot_metadata.json | /Users/chenyulin/Documents/AIProjects/market_price_guard/outputs_tech_pipeline_latest/snapshots/tech_intraday_metrics/layer_manifest.json | 16affdc3f849fc6262d46e5220f61b9c0892f721aa639c2dc27486743047c0a6 | 20a7fc10-9c27-4af0-a34e-34018b463ebc |

## Cache Summary

- cache_enabled_functions: akshare.fund_etf_spot_em
- run_cache_hit_count: 1
- run_cache_miss_count: 1
- run_cache_bypass_count: 0
- run_cache_error_count: 0
- item_cache_status: not_collected
- item_cache_note: see run-level cache summary

## Cache / Reuse Summary

- quote_cache_hit_count: 70
- quote_cache_miss_count: 47
- quote_cache_failure_hit_count: 55
- quote_cache_success_hit_count: 15
- batch_cache_hit_count: 1
- batch_cache_miss_count: 1
- repeated_provider_call_prevented_count: 70
- repeated_batch_call_prevented_count: 1
- cache_hit_by_layer: see step runtime_diagnostics.md
- cache_hit_by_provider: see step runtime_diagnostics.md

## Layer Config Summary

CONFIG_MISMATCH: true

| layer | config_source_path | configured | loaded | mismatch | missing | extra |
|---|---|---:|---:|---|---|---|
| tech_scan_ai | config/universes/tech_scan_ai.yaml | 40 | 40 | false | none | none |
| tech_watchlist | config/universes/tech_watchlist.yaml | 28 | 28 | false | none | none |
| tech_operation_candidates | config/universes/tech_operation_candidates.yaml | 19 | 19 | false | none | none |
| tech_core | config/universes/tech_core.yaml | 8 | 7 | true | 159995.SZ | none |
| tech_minute_probe | config/universes/tech_core.yaml+config/universes/tech_operation_candidates.yaml | 23 | 23 | false | none | none |
| tech_intraday_metrics | derived_from_outputs_tech_minute_probe_latest | 23 | 27 | false | none | none |

## Output Dirs Generated
- outputs_tech_scan_ai_latest
- outputs_tech_watchlist_latest
- outputs_tech_operation_candidates_latest
- outputs_tech_latest
- outputs_tech_minute_probe_latest
- outputs_tech_intraday_latest

## Slow Steps / Runtime Warnings
- none

## Runtime Budget Summary

| step | runtime_warning_level | runtime_warning_reason | run_time_budget_exceeded | provider_timeout_count | skipped_by_runtime_budget | circuit_open_count |
|---|---|---|---|---:|---:|---:|
| tech_scan_ai | provider_circuit_open | provider_circuit_open_reported | false | 3 | 0 | 94 |
| tech_watchlist | runtime_info | within_runtime_policy | false | 0 | 0 | 0 |
| tech_operation_candidates | runtime_info | within_runtime_policy | false | 0 | 0 | 0 |
| tech_fast_strict | strict_blocked_but_reported | strict_blocked_with_reports | false | 0 | 0 | 4 |
| tech_minute_probe | runtime_info | within_runtime_policy | false | 0 | 0 | 0 |
| tech_intraday_metrics | runtime_info | within_runtime_policy | unknown | 0 | 0 | 0 |

## Provider Health Summary

| step | provider_health_report | planned_actual_summary |
|---|---|---|
| tech_scan_ai | true | available |
| tech_watchlist | true | available |
| tech_operation_candidates | true | available |
| tech_fast_strict | true | available |
| tech_minute_probe | true | available |
| tech_intraday_metrics | true | legacy_format |

## Safety Note
This pipeline generates data outputs only. It does not modify config, does not promote symbols, and does not generate trading advice.
Data-only pipeline: no config changes, no automatic symbol promotion, no trading advice.
