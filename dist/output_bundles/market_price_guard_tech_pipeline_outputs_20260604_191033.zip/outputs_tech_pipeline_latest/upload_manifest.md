# Tech Research Pipeline Upload Manifest

## Core Trading State
- outputs_tech_latest/0_upload_bundle.md

## Full Research Chain
- outputs_tech_pipeline_latest/pipeline_summary.md
- outputs_tech_scan_ai_latest/0_upload_bundle.md
- outputs_tech_scan_ai_latest/scan_universe_report.md
- outputs_tech_watchlist_latest/0_upload_bundle.md
- outputs_tech_watchlist_latest/candidate_watchlist_report.md
- outputs_tech_operation_candidates_latest/0_upload_bundle.md
- outputs_tech_operation_candidates_latest/operation_candidate_report.md
- outputs_tech_latest/0_upload_bundle.md
- outputs_tech_minute_probe_latest/0_upload_bundle.md
- outputs_tech_intraday_latest/0_upload_bundle.md
- outputs_tech_intraday_latest/reference_vwap_report.md

## Compact Upload
- outputs_tech_pipeline_latest/pipeline_summary.md
- outputs_tech_latest/0_upload_bundle.md
- outputs_tech_operation_candidates_latest/0_upload_bundle.md
- outputs_tech_intraday_latest/0_upload_bundle.md

## VWAP / Intraday Position
- outputs_tech_intraday_latest/0_upload_bundle.md
- outputs_tech_intraday_latest/reference_vwap_report.md

## Runtime Debug
- outputs_tech_pipeline_latest/pipeline_summary.md
- corresponding step runtime_diagnostics.md

## Notes
- GOLD_CNY is manual price only and does not support reference VWAP / intraday metrics.
- This manifest is for data review only and does not provide trading advice.
